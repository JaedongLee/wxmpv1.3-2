

--
--exec uspUpdateRequestByLogonID N'<parameters><LogonID>charles_cp</LogonID><Content>Hello</Content></parameters>'
--


CREATE procedure [dbo].[uspUpdateRequestByLogonID]
@xmlparm xml
as
BEGIN
	declare @logonID nvarchar(200), @orderID nvarchar(200), @content nvarchar(max), @userID int;
	select
	@logonID = tbl.users.value('LogonID[1]', 'nvarchar(200)'), 
	@orderID = tbl.users.value('OrderID[1]', 'nvarchar(200)'),
	@content = tbl.users.value('Content[1]', 'nvarchar(max)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	select @userID = ID from [User] where LogonID = @logonID;

	update ebtRequest
	set Content = @content, ModificationTime = getdate()
	where OwnerID = @userID
	and OrderID = @orderID;
END;


GO
