--
-- select dbo.udfUserRegion('cli.lynda')
--
 create function [dbo].[udfUserRegion](@logonID nvarchar(200))
  returns nvarchar(100)
  as
  begin
  	declare @region nvarchar(100);

	select @region = r.Name 
	from UserRegion ur
	join [User] u on u.ID = ur.UserID
	join Region2 r on r.ID = ur.RegionID
	where u.LogonID = @logonID;

	return @region;
  end;


GO
