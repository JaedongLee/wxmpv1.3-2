--
-- execute uspArchiveLiveOrderbyDay '<parameters><day>0</day></parameters>'
--
CREATE procedure [dbo].[uspArchiveLiveOrderbyDay]
@xmlparm xml
as
begin
	declare @day int;
	declare @ErrorNumber int, @ErrorSeverity int, @ErrorState int, @ErrorProcedure nvarchar(100), @ErrorLine int, @ErrorMessage varchar(500);

	select
    @day = tbl.d.value('.', 'int')
	from @xmlparm.nodes('/parameters/day') AS tbl(d);

	begin tran
	begin try
		insert into LiveOrderHistory
		(ID, Content, CreationTime, CreationLogonID, ModificationTime, ModificationLogonID)
		select ID, Content, CreationTime, CreationLogonID, ModificationTime, ModificationLogonID 
		from LiveOrder 
		where CreationTime <= DateAdd(DD, -@day, getdate());

		delete LiveOrder where CreationTime <= DateAdd(DD, -@day, getdate());
	end try
	begin catch
		if @@TRANCOUNT > 0 rollback tran;
			SELECT @ErrorNumber = ERROR_NUMBER()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE()
			,@ErrorProcedure = ERROR_PROCEDURE()
			,@ErrorLine = ERROR_LINE()
			,@ErrorMessage = ERROR_MESSAGE();
		throw 500000, @ErrorMessage, @ErrorState;
	end catch;
	if @@TRANCOUNT > 0 commit tran; 
end;


GO
