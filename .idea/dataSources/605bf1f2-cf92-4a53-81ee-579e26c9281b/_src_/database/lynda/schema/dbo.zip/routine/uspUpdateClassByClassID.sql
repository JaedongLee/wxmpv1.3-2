
--
--exec uspUpdateClassByClassID N'<parameters><ClassID>234</ClassID><Name></Name><Description>1</Description><Location></Location><StartTime></StartTime><EndTime></EndTime><ClassSize>16</ClassSize><RegisteredSize></RegisteredSize><Grade>2</Grade><TeacherLogonID>Hello</TeacherLogonID></parameters>'
--

CREATE procedure [dbo].[uspUpdateClassByClassID]
@xmlparm xml
as
BEGIN

	begin tran

		update hxgnyClass
		set 
		Name = @xmlparm.value('(/parameters/Name)[1]', 'nvarchar(100)' ),
		Description = @xmlparm.value('(/parameters/Description)[1]', 'nvarchar(500)' ), 
		Location = @xmlparm.value('(/parameters/Location)[1]', 'nvarchar(500)' ), 
		StartTime = @xmlparm.value('(/parameters/StartTime)[1]', 'nvarchar(20)' ), 
		EndTime = @xmlparm.value('(/parameters/EndTime)[1]', 'nvarchar(20)' ), 
		ClassSize = @xmlparm.value('(/parameters/ClassSize)[1]', 'int' ), 
		RegisteredSize = @xmlparm.value('(/parameters/RegisteredSize)[1]', 'int' ), 
		Grade = @xmlparm.value('(/parameters/Grade)[1]', 'int' ),
		ModificationTime = getdate()
		where ID = @xmlparm.value('(/parameters/ClassID)[1]', 'int' );


		declare @userID int;
		select @userID = ID from [User] where LogonID = @xmlparm.value('(/parameters/TeacherLogonID)[1]', 'nvarchar(200)' );
		
		if @userID is not null
		begin
			update hxgnyUserClass
			set UserID = @userID
			where ClassID = @xmlparm.value('(/parameters/ClassID)[1]', 'int' );
		end 

	commit tran

END;
GO
