--
-- execute uspGetBusinessTypeByAppName N'<parameters><AppName>ebarter</AppName></parameters>'
--
CREATE procedure [dbo].[uspGetBusinessTypeByAppName]
@xmlparm xml
as
begin
	select bt.Name as BusinessType
	from AppBusinessType abt
	join App a on a.ID = abt.AppID
	join BusinessType bt on bt.ID = abt.BusinessTypeID
	where a.Name = @xmlparm.value('(/parameters/AppName)[1]', 'nvarchar(100)' )
end;
GO
