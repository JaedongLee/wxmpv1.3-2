--
-- execute uspGetNodesByAreaIDRegionNumber '<parameters><areaID>1</areaID><regionNumber>22563</regionNumber></parameters>'
--
CREATE procedure [dbo].[uspGetNodesByAreaIDRegionNumber]
@xmlparm xml
as
begin
	declare @areaID int, @regionNumber int, @columnNumber int, @Nsw int;
	
	select
	@areaID = tbl.d.value('areaID[1]', 'int'),
	@regionNumber = tbl.d.value('regionNumber[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(d);

	select @columnNumber = ColumnNumber from Area where ID = @areaID;
	select @Nsw = @regionNumber + (@regionNumber - 1)/(@columnNumber - 1)
	--select @Nsw as Nsw, @Nsw + @columnNumber as Nnw, @Nsw + 1 as Nse, @Nsw + @columnNumber + 1 as Nne;

	select a.longtitude, a.latitude, a.NodeNumber, a.NodeName into #N
	from
	(select n.longtitude,n.latitude, an.NodeNumber, 'Nsw' as NodeName
	from Node2 n
	join AreaNode an on an.NodeID = n.ID
	where an.NodeNumber = @Nsw and an.AreaID = @areaID
	union
	select n.longtitude,n.latitude, an.NodeNumber, 'Nnw' as NodeName
	from Node2 n
	join AreaNode an on an.NodeID = n.ID
	where an.NodeNumber = @Nsw + @columnNumber and an.AreaID = @areaID
	union
	select n.longtitude,n.latitude, an.NodeNumber, 'Nse' as NodeName
	from Node2 n
	join AreaNode an on an.NodeID = n.ID
	where an.NodeNumber = @Nsw + 1 and an.AreaID = @areaID
	union
	select n.longtitude,n.latitude, an.NodeNumber, 'Nne' as NodeName
	from Node2 n
	join AreaNode an on an.NodeID = n.ID
	where an.NodeNumber = @Nsw + @columnNumber + 1 and an.AreaID = @areaID) a;

	declare @nodes varchar(1000) = '<parameters>';

	select @nodes = @nodes + '<sw><lo>' + cast(longtitude as varchar(20)) + '</lo><la>' + cast(latitude as varchar(20)) + '</la></sw>' 
	from #N where NodeName = 'Nsw';
	select @nodes = @nodes + '<se><lo>' + cast(longtitude as varchar(20)) + '</lo><la>' + cast(latitude as varchar(20)) + '</la></se>' 
	from #N where NodeName = 'Nse';
	select @nodes = @nodes + '<ne><lo>' + cast(longtitude as varchar(20)) + '</lo><la>' + cast(latitude as varchar(20)) + '</la></ne>' 
	from #N where NodeName = 'Nne';
	select @nodes = @nodes + '<nw><lo>' + cast(longtitude as varchar(20)) + '</lo><la>' + cast(latitude as varchar(20)) + '</la></nw></parameters>' 
	from #N where NodeName = 'Nnw';

	select cast(@nodes as xml);

end;


GO
