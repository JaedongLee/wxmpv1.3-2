
--
--exec uspGetCourseIDByCourseName N'<parameters><CourseName>南京3</CourseName></parameters>'
--

CREATE procedure [dbo].[uspGetCourseIDByCourseName]
@xmlparm xml
as
BEGIN
	declare @courseName nvarchar(100);

	select
	@courseName = tbl.users.value('CourseName[1]', 'nvarchar(100)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	select ID as CourseID from hxgnyCourse where Name = @courseName;
END;
GO
