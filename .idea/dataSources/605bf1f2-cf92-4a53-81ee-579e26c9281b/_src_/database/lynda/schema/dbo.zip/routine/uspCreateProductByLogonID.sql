




--
--exec uspCreateProductByLogonID N'<parameters><LogonID>charles_cp</LogonID><Content>1</Content></parameters>'
--


CREATE procedure [dbo].[uspCreateProductByLogonID]
@xmlparm xml
as
BEGIN
	declare @logonID nvarchar(200), @orderID nvarchar(200), @content nvarchar(max), @userID int;
	select
	@logonID = tbl.users.value('LogonID[1]', 'nvarchar(200)'), 
	@orderID = tbl.users.value('OrderID[1]', 'nvarchar(200)'), 
	@content = tbl.users.value('Content[1]', 'nvarchar(max)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	select @userID = ID from [User] where LogonID = @logonID;

	insert into ebtProduct (OwnerID, OrderID, Content) values (@userID, @orderID, @content);
END;


GO
