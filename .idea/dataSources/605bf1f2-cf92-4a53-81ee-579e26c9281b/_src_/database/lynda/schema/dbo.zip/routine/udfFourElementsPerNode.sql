--
-- select dbo.[udfFourElementsPerNode] (19,7)
-- select dbo.[udfFourElementsPerNode] (440,7)
--
CREATE function [dbo].[udfFourElementsPerNode](@Node int, @regionID int)
returns xml
as
begin
	--Find elements for a given area node
	declare @fourElements varchar(200);
	declare @Enw int, @Ene int, @Esw int, @Ese int;
	declare @RegionRow int, @RegionColumn int;

	select @RegionRow = RowNumber, @RegionColumn = ColumnNumber 
	from Region2 where ID = @regionID;

	--Inner nodes
	if exists (select 1 where @Node in (
	select NodeNumber from RegionNode 
	where NodeNumber > @RegionColumn 
	and NodeNumber <= (@RegionColumn-1)*(@RegionRow - 1)
	and NodeNumber not in (select NodeNumber from RegionNode where NodeNumber%@RegionColumn = 0 union select NodeNumber + 1 from RegionNode where NodeNumber%@RegionColumn = 0)))
	begin
		select @Ene = @Node - (@Node - 1)/@RegionColumn; 
		select @Enw = @Ene - 1;
		select @Esw = @Node - (@Node - 1)/@RegionColumn - @RegionColumn; 
		select @Ese = @Esw + 1;
	end;
	--s border
	if (@node < @RegionColumn and @node > 1)
	begin
		select @Esw = NULL, @Ese = NULL, @Ene = @node, @Enw = @node - 1;
	end;
	--n border
	if (@node > @RegionColumn*(@RegionRow - 1) + 1 and @node < @RegionColumn*@RegionRow)
	begin
		select @Esw = @Node - (@Node - 1)/@RegionColumn - @RegionColumn, @Ene = null, @Enw = null;
		select @Ese = @Esw + 1;
	end;
	--sw corner
	if @node = 1
	begin
		select @Esw = NULL, @Ese = NULL, @Ene = @node, @Enw = null;
	end;
	--se corner
	if @node = @RegionColumn
	begin
		select @Esw = NULL, @Ese = NULL, @Ene = NULL, @Enw = @Node - 1;
	end;
	--ne corner
	if @node = @RegionColumn*@RegionRow
	begin
		select @Esw = @Node - (@Node - 1)/@RegionColumn - @RegionColumn, @Ese = NULL, @Ene = NULL, @Enw = NULL;
	end;
	--nw corner
	else if @Node = @RegionColumn*(@RegionRow - 1) + 1
	begin
		select @Esw = NULL, @Ese = @Node + 1 - @Node/@RegionColumn - @RegionColumn, @Ene = NULL, @Enw = NULL;
	end;
	--e border
	if exists (select 1 where @node in (select NodeNumber from RegionNode where NodeNumber%@RegionColumn = 0 and NodeNumber not in (@RegionColumn, @RegionColumn*@RegionRow)))
	begin
		select @Esw = @Node - (@Node - 1)/@RegionColumn - @RegionColumn, @Ese = NULL, @Ene = NULL, @Enw = @Node - 1 - (@Node - 1 - 1)/@RegionColumn;
	end;
	--w border
	if (exists (select 1 where @node in (select NodeNumber + 1 from RegionNode where NodeNumber%@RegionColumn = 0)) and (@node <> @RegionColumn*(@RegionRow-1) + 1)) 
	begin
		select @Esw = null, @Ese = @node + 1 - @node/@RegionColumn - @RegionColumn, @Ene = @Node - (@Node - 1)/@RegionColumn, @Enw = null;
	end;
	select @fourElements = '<parameters><sw>' + isnull(cast(@Esw as varchar),'') + '</sw><se>'+ isnull(cast(@Ese as varchar),'') + '</se><ne>'+ isnull(cast(@Ene as varchar),'') +'</ne><nw>'+ isnull(cast(@Enw as varchar),'') + '</nw></parameters>';
	return @fourElements;
end;


GO
