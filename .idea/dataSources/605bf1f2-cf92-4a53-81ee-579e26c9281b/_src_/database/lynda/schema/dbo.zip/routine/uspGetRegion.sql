CREATE procedure [dbo].[uspGetRegion]
as
begin
	select distinct Name as Region from Region2 order by Name;
end;


GO
