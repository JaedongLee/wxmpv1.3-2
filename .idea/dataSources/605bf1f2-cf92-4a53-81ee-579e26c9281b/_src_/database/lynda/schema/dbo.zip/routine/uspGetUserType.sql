CREATE procedure [dbo].[uspGetUserType]
as
begin
	select distinct u.UserType
	from [User] u
	order by UserType
end;


GO
