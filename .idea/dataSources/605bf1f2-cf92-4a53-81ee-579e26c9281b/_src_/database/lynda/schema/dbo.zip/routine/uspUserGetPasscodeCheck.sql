--
-- uspUserGetPasscodeCheck N'<parameters><logonid>cli</logonid></parameters>'
--
create procedure [dbo].[uspUserGetPasscodeCheck]
@xmlparm xml
as
begin
	declare @logonID nvarchar(200);
	select @logonID = tbl.users.value('logonid[1]', 'nvarchar(200)') from @xmlparm.nodes('/parameters') AS tbl(users);

	select upc.PasscodeCheck from UserPasscodeCheck upc
	join [User] u on u.ID = upc.UserID
	where u.LogonID = @logonID;
end;

GO
