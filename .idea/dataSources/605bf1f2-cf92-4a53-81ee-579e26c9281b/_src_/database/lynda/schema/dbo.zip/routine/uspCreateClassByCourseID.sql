


--
--exec uspCreateClassByCourseID N'<parameters><CourseID>123</CourseID><Name></Name><Description>1</Description><Location></Location><StartTime></StartTime><EndTime></EndTime><ClassSize>16</ClassSize><RegisteredSize></RegisteredSize><Grade>2</Grade></parameters>'
--


CREATE procedure [dbo].[uspCreateClassByCourseID]
@xmlparm xml
as
BEGIN
	declare @courseID nvarchar(200), @grade int, @name nvarchar(100), @description nvarchar(500), @location nvarchar(500), @startTime nvarchar(500), @endTime nvarchar(500), @classSize int, @registeredSize int;
	select
	@courseID = tbl.users.value('CourseID[1]', 'int'), 
	@name = tbl.users.value('Name[1]', 'nvarchar(100)'), 
	@description = tbl.users.value('Description[1]', 'nvarchar(500)'), 
	@startTime = tbl.users.value('StartTime[1]', 'nvarchar(20)'),
	@endTime= tbl.users.value('EndTime[1]', 'nvarchar(20)'),
	@classSize = tbl.users.value('ClassSize[1]', 'int'),
	@registeredSize = tbl.users.value('RegisteredSize[1]', 'int'),
	@grade = tbl.users.value('Grade[1]', 'int'),
	@location = tbl.users.value('Location[1]', 'nvarchar(500)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	insert into hxgnyClass 
	(Name, Description, Location, StartTime, EndTime, ClassSize, RegisteredSize, CourseID, Grade) 
	values 
	(@name, @description, @location, @startTime, @endTime, @classSize, @registeredSize, @courseID, @grade);
END;


GO
