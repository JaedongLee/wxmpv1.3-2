
--
-- uspAddTransaction N'<parameters><tradeid>123</tradeid><transtype>1</transtype><amount>50000.123</amount></parameters>'
--
CREATE procedure [dbo].[uspAddTransaction]
@xmlparm xml
as
begin
	declare @tradeID int, @transtype int, @amount numeric(12,3);
	
	select
	@tradeID = tbl.users.value('tradeid[1]', 'int'), 
	@transtype = tbl.users.value('transtype[1]', 'int'),
	@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	insert into ebtTransaction
	(TransactionTypeID, TradeID, Amount)
	select @transtype, @tradeID, @amount 
end;

GO
