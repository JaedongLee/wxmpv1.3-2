
--
--exec uspUpdateCourseByCourseID N'<parameters><CourseID>234</CourseID><OwnerID>123</OwnerID><Name>Hello</Name><Description>Hi</Description><Type>Chinese</Type><Price>500</Price><URL></URL><GradeSize>1</GradeSize><MaterialPrice>200</MaterialPrice></parameters>'
--

CREATE procedure [dbo].[uspUpdateCourseByCourseID]
@xmlparm xml
as
BEGIN
	update hxgnyCourse
	set 
	Name = @xmlparm.value('(/parameters/Name)[1]', 'nvarchar(100)' ),
	Description = @xmlparm.value('(/parameters/Description)[1]', 'nvarchar(500)' ), 
	Type = @xmlparm.value('(/parameters/Type)[1]', 'nvarchar(50)' ), 
	OwnerID = @xmlparm.value('(/parameters/OwnerID)[1]', 'int' ), 
	Price = @xmlparm.value('(/parameters/Price)[1]', 'numeric(12,3)' ), 
	URL = @xmlparm.value('(/parameters/URL)[1]', 'nvarchar(max)' ), 
	GradeSize = @xmlparm.value('(/parameters/GradeSize)[1]', 'int' ), 
	MaterialPrice = @xmlparm.value('(/parameters/MaterialPrice)[1]', 'numeric(12,3)' )
	where ID = @xmlparm.value('(/parameters/CourseID)[1]', 'int' );
END;
GO
