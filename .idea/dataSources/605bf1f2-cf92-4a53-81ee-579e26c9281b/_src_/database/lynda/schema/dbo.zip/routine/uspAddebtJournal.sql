
--
-- uspAddebtJournal N'<parameters><tradeid>1</tradeid><transactionid>1</transactionid><description>Charles Account</description><fromaccountID>10</fromaccountID><toaccountID>20</toaccountID><amount>150000.123</amount></parameters>'
--
CREATE procedure [dbo].[uspAddebtJournal]
@xmlparm xml
as
begin
	declare @tradeid int, @transactionid int, @description nvarchar(500), @fromaccountID int, @toaccountID int, @amount numeric(12,3);
	
	select
	@tradeid = tbl.users.value('tradeid[1]', 'int'), 
	@transactionid = tbl.users.value('transactionid[1]', 'int'), 
	@description = tbl.users.value('description[1]', 'nvarchar(500)'),
	@fromaccountID = tbl.users.value('fromaccountID[1]', 'int'), 
	@toaccountID = tbl.users.value('toaccountID[1]', 'int'), 
	@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	insert into ebtJournal
	(TradeID, TransactionID, Description, FromAccountID, ToAccountID, Amount)
	select @tradeid, @transactionid, @description, @fromaccountid, @toaccountID, @amount 
end;

GO
