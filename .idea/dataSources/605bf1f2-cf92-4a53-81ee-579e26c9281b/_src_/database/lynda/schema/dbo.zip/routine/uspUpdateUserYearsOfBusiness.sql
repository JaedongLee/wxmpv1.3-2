--
-- execute uspUpdateUserYearsOfBusiness N'<parameters><logonid>cli</logonid><yearsofbusiness>20</yearsofbusiness></parameters>'
--
CREATE procedure [dbo].[uspUpdateUserYearsOfBusiness]
@xmlparm xml
as
begin
	declare @LogonID nvarchar(200), @YearsOfBusiness int, @UserID int;

	select
    @LogonID = tbl.users.value('logonid[1]', 'nvarchar(200)'),
    @YearsOfBusiness = tbl.users.value('yearsofbusiness[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	select @UserID = ID from [User] where LogonID = @LogonID; 

	begin tran

	begin try
		--update user password
		update [User]
		set YearsOfBusiness = @YearsOfBusiness 
		where LogonID = @LogonID;

		delete UserRating where UserID=@UserID and Comments = 'initial rating';

		insert into UserRating
		(UserID, RatedUserID, Rate, Comments)
		select 
		@UserID, 
		@UserID, 
		case 
			when @yearsOfBusiness = 1 then 1
			when @yearsOfBusiness = 2 then 2
			when @yearsOfBusiness >= 3 and @yearsOfBusiness <= 5 then 3
			when @yearsOfBusiness >= 6 and @yearsOfBusiness <= 10 then 4
			when @yearsOfBusiness >= 11 and @yearsOfBusiness <= 20 then 5
			else 6 
		end,  
		'initial rating';
	end try
	begin catch
		declare @ErrorNumber int, @ErrorSeverity int, @ErrorState int, @ErrorProcedure nvarchar(100), @ErrorLine int, @ErrorMessage varchar(500);
		if @@TRANCOUNT > 0 rollback tran;
			SELECT @ErrorNumber = ERROR_NUMBER()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE()
			,@ErrorProcedure = ERROR_PROCEDURE()
			,@ErrorLine = ERROR_LINE()
			,@ErrorMessage = ERROR_MESSAGE();
		throw 500000, @ErrorMessage, @ErrorState;
	end catch;
	if @@TRANCOUNT > 0 commit tran;
end;


GO
