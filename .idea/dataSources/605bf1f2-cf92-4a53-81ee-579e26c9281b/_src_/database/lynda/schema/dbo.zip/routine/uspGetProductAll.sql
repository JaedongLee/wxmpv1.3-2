

--
--exec uspGetProductAll ''
--

CREATE procedure [dbo].[uspGetProductAll]
@appName nvarchar(200)
as
BEGIN
	select Content, LogonID 
	from ebtProduct p
	join [User] u on u.ID = p.OwnerID;
END;


GO
