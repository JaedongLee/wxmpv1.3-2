CREATE function [dbo].[udfFourCorners](@longtitude float, @latitude float, @radius float)
returns xml
as
begin
	declare @clat varchar(10) = cast(@latitude as varchar), @clong varchar(10) = cast(@longtitude as varchar);
	declare @clongE varchar(10) = cast((@longtitude + 1.0) as varchar(10));
	declare @clatN varchar(10) = cast((@latitude + 1.0) as varchar(10));

	declare @fourCorners varchar(500);
	declare @center geography= geography::STGeomFromText('POINT(' + @clong +' '+ @clat +')', 4326)
	declare @ce geography= geography::STGeomFromText('POINT(' + @clongE +' '+ @clat +')', 4326)
	declare @cn geography= geography::STGeomFromText('POINT(' + @clong +' '+ @clatN +')', 4326)

	declare @longEast float, @latNorth float;
	select @longEast = @radius/@center.STDistance(@ce), @latNorth = @radius/@center.STDistance(@cn);

	select @fourCorners =   '<parameters><sw><lo>' + cast((@clong - @longEast) as varchar(10)) + '</lo><la>' + cast((@clat - @latNorth) as varchar(10)) + '</la></sw>' +
							'<se><lo>' + cast((@clong + @longEast) as varchar(10)) + '</lo><la>' + cast((@clat - @latNorth) as varchar(10)) + '</la></se>' +
							'<ne><lo>' + cast((@clong + @longEast) as varchar(10)) + '</lo><la>' + cast((@clat + @latNorth) as varchar(10)) + '</la></ne>' +
							'<nw><lo>' + cast((@clong - @longEast) as varchar(10)) + '</lo><la>' + cast((@clat + @latNorth) as varchar(10)) + '</la></nw></parameters>';
	return @fourCorners;
end;


GO
