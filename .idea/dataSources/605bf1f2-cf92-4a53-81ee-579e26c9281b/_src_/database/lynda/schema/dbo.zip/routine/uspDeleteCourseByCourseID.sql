


--
--exec uspDeleteCourseByCourseID N'<parameters><CourseID>charles_cp</CourseID></parameters>'
--

CREATE procedure [dbo].[uspDeleteCourseByCourseID]
@xmlparm xml
as
BEGIN
	declare @courseID int;
	select 
	@courseID = tbl.users.value('CourseID[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	delete hxgnyCourse 
	where ID = @courseID;
END;


GO
