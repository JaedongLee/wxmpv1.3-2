

--
--exec uspUpdateUserClassByOldClassIDNewClassIDLogonID N'<parameters><OldClassID>123</NewClassID><OldClassID>345</NewClassID><LogonID>charles_cp</LogonID></parameters>'
--

create procedure [dbo].[uspUpdateUserClassByOldClassIDNewClassIDLogonID]
@xmlparm xml
as
BEGIN
	declare @logonID nvarchar(200), @newClassID int, @oldClassID int;
	select 
	@logonID = tbl.users.value('LogonID[1]', 'nvarchar(200)'),
	@oldClassID = tbl.users.value('OldClassID[1]', 'int'),
	@newClassID = tbl.users.value('NewClassID[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	update hxgnyUserClass
	set ClassID = @newClassID 
	where ClassID =  @oldClassID 
	and UserID = (select ID from [User] where LogonID = @logonID);

END;

GO
