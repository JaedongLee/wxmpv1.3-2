



--
-- execute uspCreateUser N'<parameters><user><logonid>cli30</logonid><password>cli32345</password><referencecode></referencecode><usertype>SUPPLIER</usertype><email>charles.li@hotmail.com</email><wechat>a1234567</wechat><yearsofbusiness>9999</yearsofbusiness><phone>123456789</phone><ext>789</ext><firstname>Charles</firstname><lastname>Li</lastname><long>-73.99946</long><lat>41.373839</lat><street>3 Time Square</street><city>Cross River</city><state>New York</state><country>USA</country><zipcode>10518</zipcode><businesstype>Fashion_Clothing</businesstype><businesstype>Appliance_Grocery_Dining</businesstype><RoleName>hxgnyTeacher</RoleName><AppName>ebarter</AppName><DOB>01-12-1981</DOB><description>This is for description of a teacher</description></user></parameters>'
-- execute uspCreateUser N'<parameters><user><logonid>hxgnylb40</logonid><password>96e79218965eb72c92a549dd5a330112</password><poll>0</poll><referencecode>null</referencecode><usertype>BUYER</usertype><email>999@163.com</email><wechat>null</wechat><yearsofbusiness>0</yearsofbusiness><phone>null</phone><ext>null</ext><firstname>null</firstname><lastname>null</lastname><long>0.0</long><lat>0.0</lat><street>null</street><city>null</city><state>null</state><country>null</country><zipcode>null</zipcode><AppName>HXGNY</AppName><RoleName>hxgnyTeacher</RoleName><DOB>01/12/1981</DOB><description>教师详情描述</description></user></parameters>'
--
CREATE procedure [dbo].[uspCreateUser]
@xmlparm xml
as
begin

	declare @BusinessType table (Name nvarchar(100));
	declare @maxID int;
	declare @longtitude float, @latitude float;
	declare @appName nvarchar(100);
	declare @roleName nvarchar(100);

	declare @regionID int, @regionName nvarchar(100);
	declare @E float, @W float, @S float, @N float;

	declare @ErrorNumber int, @ErrorSeverity int, @ErrorState int, @ErrorProcedure nvarchar(100), @ErrorLine int, @ErrorMessage varchar(500);

	declare @phoneList table (id int identity, phone nvarchar(20))
	declare @extList table (id int identity, ext nvarchar(10))
	declare @phonewithExtList table (id int identity, phone nvarchar(20), ext nvarchar(10))

	declare @yearsOfBusiness int;

	select 
	@longtitude = tbl.users.value('long[1]', 'varchar(10)'),
	@latitude = tbl.users.value('lat[1]', 'varchar(10)'),
	@appName = tbl.users.value('AppName[1]', 'nvarchar(100)'),
	@roleName = tbl.users.value('RoleName[1]', 'nvarchar(100)')
	from @xmlparm.nodes('/parameters/user') AS tbl(users);

	insert into @BusinessType
	select tbl.users.value('.', 'nvarchar(100)') from @xmlparm.nodes('/parameters/user/businesstype') AS tbl(users);

	select @regionName = dbo.udfRegion(@longtitude,@latitude)

	select 
	@E = Coordinate.value('(/parameters/ne/lo)[1]','float'), 
	@W = Coordinate.value('(/parameters/sw/lo)[1]','float'),
	@N = Coordinate.value('(/parameters/ne/la)[1]','float'),
	@S = Coordinate.value('(/parameters/sw/la)[1]','float'),
	@regionID = ID
	from Region2 r
	where Name = @regionName;

	if exists(select 1 from @BusinessType)
	begin
		begin tran

		begin try
			insert into [User]
			(LogonID, Password, ReferenceCode, Email, WeChat, YearsOfBusiness, FirstName, MiddleName, LastName, Longtitude, Latitude, Street, City, State, Country,Zipcode, UserType,DOB, [Description])
			select
			tbl.users.value('logonid[1]', 'nvarchar(200)') as LogonID,
			tbl.users.value('password[1]', 'nvarchar(100)') as Password,
			rtrim(tbl.users.value('referencecode[1]', 'nvarchar(200)')) as ReferenceCode,
			rtrim(tbl.users.value('email[1]', 'nvarchar(100)')) as Email,
			rtrim(tbl.users.value('wechat[1]', 'nvarchar(100)')) as WeChat,
			tbl.users.value('yearsofbusiness[1]', 'int') as YearsOfBusiness,
			tbl.users.value('firstname[1]', 'nvarchar(100)') as FirstName,
			tbl.users.value('middlename[1]', 'nvarchar(100)') as MiddleName,
			replace(tbl.users.value('lastname[1]', 'nvarchar(100)'),'and','&') as LastName,
			tbl.users.value('long[1]', 'varchar(10)') as Longtitude,
			tbl.users.value('lat[1]', 'varchar(10)') as Latitude,
			tbl.users.value('street[1]', 'nvarchar(500)') as Street,
			tbl.users.value('city[1]', 'nvarchar(200)') as City,
			tbl.users.value('state[1]', 'nvarchar(200)') as State,
			tbl.users.value('country[1]', 'nvarchar(100)') as Country,
			tbl.users.value('zipcode[1]', 'nvarchar(20)') as Zipcode,
			lower(tbl.users.value('usertype[1]', 'nvarchar(30)')) as UserType,
			cast(tbl.users.value('DOB[1]', 'date') as date),
			tbl.users.value('description[1]', 'nvarchar(1024)') as Description
			from @xmlparm.nodes('/parameters/user') AS tbl(users)

			select @maxID =  max(ID) from [User]

			select @yearsOfBusiness = tbl.users.value('yearsofbusiness[1]', 'int')
			from @xmlparm.nodes('/parameters/user') AS tbl(users);


			--Add user BusinessType
			insert into UserBusinessType
			(UserID, BusinessTypeID, Active)
			select @maxID, ID, 'A' from BusinessType a join @BusinessType b on a.Name = b.Name;


			--Add initial rating
			if (@yearsOfBusiness <> 9999)
			begin
				insert into UserRating
				(UserID, RatedUserID, Rate, Comments)
				select 
				@maxID, 
				@maxID, 
				case 
					when @yearsOfBusiness = 1 then 1
					when @yearsOfBusiness = 2 then 2
					when @yearsOfBusiness >= 3 and @yearsOfBusiness <= 5 then 3
					when @yearsOfBusiness >= 6 and @yearsOfBusiness <= 10 then 4
					when @yearsOfBusiness >= 11 and @yearsOfBusiness <= 20 then 5
					else 6 
				end,  
				'initial rating';
			end;

			--Add User Phone
			insert into @phoneList
			select tbl.users.value('.', 'nvarchar(20)') from @xmlparm.nodes('/parameters/user/phone') AS tbl(users);
			delete @phoneList where ltrim(rtrim(isnull(phone,''))) ='';
			--select * from @phoneList

			insert into @extList
			select tbl.users.value('.', 'nvarchar(10)') from @xmlparm.nodes('/parameters/user/ext') AS tbl(users);
			--select * from @extList

			insert into @phonewithExtList
			select p.phone, e.ext from @phoneList p left join @extList e on e.id = p.id 

			insert Phone (Phone, Ext, Type) 
			select pl.phone, pl.ext, '' 
			from @phonewithExtList pl
			where not exists (select 1 from Phone p where p.Phone = pl.phone and p.Ext=pl.ext);

			insert UserPhone (UserID, PhoneID, FirstPhone) 
			select @maxID, p.ID, case when pl.ID = 1 then 1 else 0 end   
			from Phone p 
			join @phonewithExtList pl on pl.phone = p.Phone and pl.ext = p.Ext; 

			--Add User Region
			insert into UserRegion
			(UserID, RegionID)
			select @maxID, (select ID from Region2 where Name = @regionName);

			--Add User App
			insert into UserApp
			(UserID, AppID)
			select @maxID, (select ID from App where Name = @appName);

			--Add User Role
			insert into UserRole
			(UserID, RoleID)
			select @maxID, (select ID from [Role] where Name = @roleName);
		

			--Add User PasscodeCheck
			insert into UserPasscodeCheck
			(UserID, PasscodeCheck)
			select @maxID, 1;
		

			--Add User Region Element
			if(@E = @longtitude and @N = @latitude)
			--NE corner
			begin
				print 'NE corner';
				insert into UserRegionElement
				(UserID, RegionElementID)
				select @maxID, max(re.ID) 
				from RegionElement re
				where re.RegionID = @regionID;
			end;
			else
			--E, N border and inner points
			begin
				insert into UserRegionElement
				(UserID, RegionElementID)
				select @maxID, re.ID 
				from RegionElement re
				join (select a.NodeNumber - r.ColumnNumber - (a.NodeNumber - 1)/r.ColumnNumber as ElementNumber, r.ID 
				from Region2 r
				join (select  min(rn.NodeNumber) as NodeNumber, r.ID
				from Region2 r
				join RegionNode rn on rn.RegionID = r.ID
				join Node1 n on rn.NodeID = n.ID
				where n.Latitude >= @latitude and n.Longtitude >= @longtitude and r.Name = @regionName
				group by r.ID) a on a.ID = r.ID) b on re.ElementNumber = b.ElementNumber and b.ID = re.RegionID;
			end;

			--Add poll voter
			declare @poll int
			select @poll = tbl.users.value('poll[1]', 'int') from @xmlparm.nodes('/parameters/user') AS tbl(users);
			if(1 = @poll)
			begin
				insert into UserPoll
				(UserID)
				select @maxID;
			end;

		end try
		begin catch
		    if @@TRANCOUNT > 0 rollback tran;
			    SELECT @ErrorNumber = ERROR_NUMBER()
				,@ErrorSeverity = ERROR_SEVERITY()
				,@ErrorState = ERROR_STATE()
				,@ErrorProcedure = ERROR_PROCEDURE()
				,@ErrorLine = ERROR_LINE()
				,@ErrorMessage = ERROR_MESSAGE();

			throw 500000, @ErrorMessage, @ErrorState;
		end catch;
		if @@TRANCOUNT > 0 commit tran;
	end;
	else
	begin
		begin tran
		begin try
			insert into [User]
			(LogonID, Password, ReferenceCode, Email, WeChat, FirstName,MiddleName,LastName, Longtitude, Latitude, Street, City, State, Country,Zipcode, UserType, DOB, [Description])
			select
			tbl.users.value('logonid[1]', 'nvarchar(200)') as LogonID,
			tbl.users.value('password[1]', 'nvarchar(100)') as Password,
			rtrim(tbl.users.value('referencecode[1]', 'nvarchar(200)')) as ReferenceCode,
			rtrim(tbl.users.value('email[1]', 'nvarchar(100)')) as Email,
			rtrim(tbl.users.value('wechat[1]', 'nvarchar(100)')) as WeChat,
			tbl.users.value('firstname[1]', 'nvarchar(100)') as FirstName,
			tbl.users.value('middlename[1]', 'nvarchar(100)') as MiddleName,
			replace(tbl.users.value('lastname[1]', 'nvarchar(100)'),'and','&') as LastName,
			tbl.users.value('long[1]', 'varchar(10)') as Longtitude,
			tbl.users.value('lat[1]', 'varchar(10)') as Latitude,
			tbl.users.value('street[1]', 'nvarchar(500)') as Street,
			tbl.users.value('city[1]', 'nvarchar(200)') as City,
			tbl.users.value('state[1]', 'nvarchar(200)') as State,
			tbl.users.value('country[1]', 'nvarchar(100)') as Country,
			tbl.users.value('zipcode[1]', 'nvarchar(20)') as Zipcode,
			lower(tbl.users.value('usertype[1]', 'nvarchar(30)')) as UserType,
			cast(tbl.users.value('DOB[1]', 'date') as date),
			tbl.users.value('description[1]', 'nvarchar(1024)') as Description
			from @xmlparm.nodes('/parameters/user') AS tbl(users)

			select @maxID =  max(ID) from [User];

			--Add User Phone
			insert into @phoneList
			select tbl.users.value('.', 'nvarchar(20)') from @xmlparm.nodes('/parameters/user/phone') AS tbl(users);
			delete @phoneList where ltrim(rtrim(isnull(phone,''))) ='';
			--select * from @phoneList

			insert into @extList
			select tbl.users.value('.', 'nvarchar(10)') from @xmlparm.nodes('/parameters/user/ext') AS tbl(users);
			--select * from @extList

			insert into @phonewithExtList
			select p.phone, e.ext from @phoneList p left join @extList e on e.id = p.id 

			insert Phone (Phone, Ext, Type) 
			select pl.phone, pl.ext, '' 
			from @phonewithExtList pl
			where not exists (select 1 from Phone p where p.Phone = pl.phone and p.Ext=pl.ext);

			insert UserPhone (UserID, PhoneID, FirstPhone) 
			select @maxID, p.ID, case when pl.ID = 1 then 1 else 0 end   
			from Phone p 
			join @phonewithExtList pl on pl.phone = p.Phone and pl.ext = p.Ext; 

			--Add User Region
			select top 1 count(isnull(ur.UserID,0)) as LestUsercnt, r.ID as RegionID
			into #selectedRegion
			from Region2 r 
			left join UserRegion ur on r.ID = ur.RegionID
			where r.AreaID = 2
			group by r.ID
			order by 1,2

			insert into UserRegion
			(UserID, RegionID)
			select @maxID, (select RegionID from #selectedRegion);

			--Add User App
			insert into UserApp
			(UserID, AppID)
			select @maxID, (select ID from App where Name = @appName);

			--Add User Role
			insert into UserRole
			(UserID, RoleID)
			select @maxID, (select ID from [Role] where Name = @roleName);

			--Add User PasscodeCheck
			insert into UserPasscodeCheck
			(UserID, PasscodeCheck)
			select @maxID, 1;

		end try
		begin catch
		    if @@TRANCOUNT > 0 rollback tran;
			    SELECT @ErrorNumber = ERROR_NUMBER()
				,@ErrorSeverity = ERROR_SEVERITY()
				,@ErrorState = ERROR_STATE()
				,@ErrorProcedure = ERROR_PROCEDURE()
				,@ErrorLine = ERROR_LINE()
				,@ErrorMessage = ERROR_MESSAGE();
			throw 500000, @ErrorMessage, @ErrorState;
		end catch;
		if @@TRANCOUNT > 0 commit tran;

	end;

end;


GO
