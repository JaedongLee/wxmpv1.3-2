--
-- execute uspGetRegionByLogonID N'<parameters><user><logonid>zou</logonid><password>zou</password></user></parameters>'
--
CREATE procedure [dbo].[uspGetRegionByLogonID]
@xmlparm xml
as
begin
	declare @logonID nvarchar(200);
	select @logonID = tbl.d.value('logonid[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters/user') AS tbl(d);

	select 
	r.Name as Region,
	cast(Datediff(s, '1970-01-01', DATEADD(dd, 0, DATEDIFF(dd, 0, u.ModificationTime))) AS bigint)*1000 + cast(Datediff(MS, DATEADD(dd, 0, DATEDIFF(dd, 0, u.ModificationTime)), u.ModificationTime) AS bigint) as ModificationTime,
	u.ID
	from [User] u
	left join  UserRegion ur on u.ID = ur.UserID
	left join Region2 r on ur.RegionID = r.ID
	where u.LogonID = @logonID
end;


GO
