--
-- execute uspGetTemplateByName '<parameters><name>Restaurant</name></parameters>'
--
CREATE procedure [dbo].[uspGetTemplateByName]
@xmlparm xml
as
begin
	declare @name nvarchar(100);
	select
    @name = tbl.d.value('.', 'nvarchar(100)')
	from @xmlparm.nodes('/parameters/name') AS tbl(d);
	
	select Template from Template 
	where Name = @name 
end;


GO
