create procedure [dbo].[uspUpdatePoll]
@xmlparm xml
as
begin

	declare @latitude float, @longtitude float, @distance float;
	declare @total int, @yes int, @no int, @starttime int, @endtime int, @lasttime int, @status int, @pollid nvarchar(200); 
	declare @picturelink nvarchar(300), @name nvarchar(200), @description nvarchar(max), @usekm bit;

	select 
	@pollid = tbl.d.value('pollid[1]', 'nvarchar(200)'),
	@name = tbl.d.value('name[1]', 'nvarchar(100)'),
	@description = tbl.d.value('description[1]', 'nvarchar(max)'),
	@latitude = tbl.d.value('latitude[1]', 'float'),
	@longtitude = tbl.d.value('longtitude[1]', 'float'),
	@picturelink = tbl.d.value('picturelink[1]', 'nvarchar(300)'),
	@starttime = tbl.d.value('starttime[1]', 'int'),
	@endtime = tbl.d.value('endtime[1]', 'int'),
	@lasttime = tbl.d.value('lasttime[1]', 'int'),
	@distance = tbl.d.value('distance[1]', 'float'),
	@status = tbl.d.value('status[1]', 'int'),
	@usekm = tbl.d.value('usekm[1]', 'bit'),
	@yes = tbl.d.value('yes[1]', 'int'),
	@no = tbl.d.value('no[1]', 'int'),
	@total = tbl.d.value('total[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(d);

	--select @latitude, @longtitude, @distance, @total, @yes, @no, @starttime, @endtime, @lasttime, @status, @pollid, @picturelink, @name, @description, @usekm;

	MERGE INTO Poll AS Target
	USING (values ( @latitude, @longtitude, @distance, @total, @yes, @no, @starttime, @endtime, @lasttime, @status, @pollid, @picturelink, @name, @description, @usekm))
		   AS Source (Latitude, longtitude, Distance, TotalVote, YesVote, NoVote, StartTime, EndTime, LastTime, Status, PollID, PictureLink, Name, Description, UseKM)
	ON Target.PollID = Source.PollID
	WHEN MATCHED THEN
	UPDATE SET Target.[Name] = Source.Name
		  ,Target.[Description] = Source.Description
		  ,Target.[TotalVote] = Source.TotalVote
		  ,Target.[YesVote] = Source.YesVote
		  ,Target.[NoVote] = Source.NoVote
		  ,Target.[StartTime] = Source.StartTime
		  ,Target.[EndTime] = Source.EndTime
		  ,Target.[LastTime] = Source.LastTime
		  ,Target.[Latitude] = Source.Latitude
		  ,Target.[Longtitude] = Source.Longtitude
		  ,Target.[PictureLink] = Source.PictureLink
		  ,Target.[Distance] = Source.Distance
		  ,Target.[UseKM] = Source.UseKM
		  ,Target.[Status] = Source.Status
		  ,Target.[ModificationTime] = getdate()
	WHEN NOT MATCHED BY TARGET THEN
	INSERT ([PollID],[Name]
			   ,[Description]
			   ,[TotalVote]
			   ,[YesVote]
			   ,[NoVote]
			   ,[StartTime]
			   ,[EndTime]
			   ,[LastTime]
			   ,[Latitude]
			   ,[Longtitude]
			   ,[PictureLink]
			   ,[Distance]
			   ,[UseKM]
			   ,[Status])
	values
	(PollID, Name, Description, TotalVote, YesVote, NoVote, StartTime, EndTime, LastTime, Latitude, longtitude, PictureLink, Distance, UseKM, Status);
end;
GO
