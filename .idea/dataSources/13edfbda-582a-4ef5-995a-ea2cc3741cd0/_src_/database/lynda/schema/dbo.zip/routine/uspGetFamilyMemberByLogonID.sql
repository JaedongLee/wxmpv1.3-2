

--
-- uspGetFamilyMemberByLogonID N'<parameters><LogonID>hxgnylb51</LogonID></parameters>'
--
CREATE procedure [dbo].[uspGetFamilyMemberByLogonID]
@xmlparm xml
as
begin
	declare @logonID nvarchar(200), @userID int;
	
	select
	@logonID = tbl.users.value('LogonID[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	select @userID = ID from [User] where LogonID = @logonID;

	select u.ID as UserID, u.LogonID, u.DOB, r.Name as RoleName 
	from [User] u 
	join UserRole ur on ur.UserID = u.ID
	join Role r on r.ID = ur.RoleID
	where ReferenceCode = cast(@userID as nvarchar(20)) or LogonID = @logonID

end;
GO
