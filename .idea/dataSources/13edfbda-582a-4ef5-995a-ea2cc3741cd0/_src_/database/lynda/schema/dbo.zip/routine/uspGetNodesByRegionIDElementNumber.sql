--
-- execute uspGetNodesByRegionIDElementNumber '<parameters><regionID>1</regionID><elementNumber>22</elementNumber></parameters>'
-- execute uspGetNodesByRegionIDElementNumber '<parameters><regionID>9</regionID><elementNumber>18</elementNumber></parameters>'
CREATE procedure [dbo].[uspGetNodesByRegionIDElementNumber]
@xmlparm xml
as
begin
	declare @regionID int, @elementNumber int, @columnNumber int, @Nsw int;
	
	select
	@regionID = tbl.d.value('regionID[1]', 'int'),
	@elementNumber = tbl.d.value('elementNumber[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(d);

	select @columnNumber = ColumnNumber from Region2 where ID = @regionID;
	select @Nsw = @elementNumber + (@elementNumber - 1)/(@columnNumber - 1)

	select a.longtitude, a.latitude, a.NodeNumber, a.NodeName into #N
	from
	(select n.longtitude,n.latitude, rn.NodeNumber, 'Nsw' as NodeName
	from Node1 n
	join RegionNode rn on rn.NodeID = n.ID
	where rn.NodeNumber = @Nsw and rn.RegionID = @regionID
	union
	select n.longtitude,n.latitude, rn.NodeNumber, 'Nnw' as NodeName
	from Node1 n
	join RegionNode rn on rn.NodeID = n.ID
	where rn.NodeNumber = @Nsw + @columnNumber and rn.RegionID = @regionID
	union
	select n.longtitude,n.latitude, rn.NodeNumber, 'Nse' as NodeName
	from Node1 n
	join RegionNode rn on rn.NodeID = n.ID
	where rn.NodeNumber = @Nsw + 1 and rn.RegionID = @regionID
	union
	select n.longtitude,n.latitude, rn.NodeNumber, 'Nne' as NodeName
	from Node1 n
	join RegionNode rn on rn.NodeID = n.ID 
	where rn.NodeNumber = @Nsw + @columnNumber + 1 and rn.RegionID = @regionID) a

	declare @nodes varchar(max) = '<parameters>';

	select @nodes = @nodes + '<sw><lo>' + cast(longtitude as varchar(20)) + '</lo><la>' + cast(latitude as varchar(20)) + '</la></sw>' 
	from #N where NodeName = 'Nsw';
	select @nodes = @nodes + '<se><lo>' + cast(longtitude as varchar(20)) + '</lo><la>' + cast(latitude as varchar(20)) + '</la></se>' 
	from #N where NodeName = 'Nse';
	select @nodes = @nodes + '<ne><lo>' + cast(longtitude as varchar(20)) + '</lo><la>' + cast(latitude as varchar(20)) + '</la></ne>' 
	from #N where NodeName = 'Nne';
	select @nodes = @nodes + '<nw><lo>' + cast(longtitude as varchar(20)) + '</lo><la>' + cast(latitude as varchar(20)) + '</la></nw></parameters>' 
	from #N where NodeName = 'Nnw';

	select cast(@nodes as xml);

end;


GO
