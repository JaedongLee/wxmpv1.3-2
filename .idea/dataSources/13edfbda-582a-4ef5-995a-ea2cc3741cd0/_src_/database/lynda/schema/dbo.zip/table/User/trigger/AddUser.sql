
CREATE TRIGGER [dbo].[AddUser] ON [dbo].[User]
AFTER INSERT
AS
begin
insert into lyndaadmin.dbo.AspNetUsers
(Id, Email, EmailConfirmed, PasswordHash, SecurityStamp, PhoneNumberConfirmed,TwoFactorEnabled,LockoutEnabled, AccessFailedCount,UserName)
select i.ID, isnull(i.Email,''), 0, i.Password,'', 0, 0, 0, 0, i.LogonID from inserted i
where not exists (select * FROM lyndaadmin.dbo.AspNetUsers AS u 
				JOIN inserted AS i 
				ON u.UserName = i.LogonID) 
end;

GO
