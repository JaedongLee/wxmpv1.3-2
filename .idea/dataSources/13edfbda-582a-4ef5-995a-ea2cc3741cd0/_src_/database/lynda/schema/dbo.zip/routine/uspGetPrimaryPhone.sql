--
-- execute [uspGetPrimaryPhone]
--
CREATE procedure [dbo].[uspGetPrimaryPhone]
as
begin
	select Phone, Ext 
	from Phone p
	join UserPhone up on up.phoneID = p.ID where up.FirstPhone = 1 
end;


GO
