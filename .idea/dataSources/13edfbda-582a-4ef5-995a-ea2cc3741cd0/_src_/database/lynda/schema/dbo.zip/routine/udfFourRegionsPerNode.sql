--
-- select dbo.[udfFourRegionsPerNode] (365,1)
-- select dbo.[udfFourRegionsPerNode] (243,1)
--
CREATE function [dbo].[udfFourRegionsPerNode](@Node int, @areaID int)
returns xml
as
begin
	--Find regions for a given area node
	declare @fourRegions varchar(200);
	declare @Rnw int, @Rne int, @Rsw int, @Rse int;
	declare @AreaRow int, @AreaColumn int;

	select @AreaRow = RowNumber, @AreaColumn = ColumnNumber 
	from Area where ID = @areaID;

	--Inner nodes
	if exists (select 1 where @Node in (
	select NodeNumber from AreaNode 
	where NodeNumber > @AreaColumn 
	and NodeNumber < (@AreaColumn -1)*(@AreaRow - 1)
	and NodeNumber not in (select NodeNumber from AreaNode where NodeNumber%@AreaColumn = 0 union select NodeNumber + 1 from AreaNode where NodeNumber%@AreaColumn = 0)))
	begin
		select @Rne = @Node - (@Node - 1)/@AreaColumn; 
		select @Rnw = @Rne - 1;
		select @Rsw = @Node - (@Node - 1)/@AreaColumn - @AreaColumn; 
		select @Rse = @Rsw + 1;
	end;
	--s border
	else if (@Node < @AreaColumn and @Node > 1)
	begin
		select @Rsw = NULL, @Rse = NULL, @Rne = @Node, @Rnw = @Node - 1;
	end;
	--n border
	if (@Node > @AreaColumn*(@AreaRow - 1) + 1 and @node < @AreaColumn*@AreaRow)
	begin
		select @Rsw = @Node - (@Node - 1)/@AreaColumn - @AreaColumn, @Rne = null, @Rnw = null;
		select @Rse = @Rsw + 1;
	end;
	--sw corner
	else if @Node = 1
	begin
		select @Rsw = NULL, @Rse = NULL, @Rne = @Node, @Rnw = null;
	end;
	--se corner
	else if @Node = @AreaColumn
	begin
		select @Rsw = NULL, @Rse = NULL, @Rne = NULL, @Rnw = @Node - 1;
	end;
	--ne corner
	else if @Node = @AreaColumn*@AreaRow
	begin
		select @Rsw = @Node - (@Node - 1)/@AreaColumn - @AreaColumn, @Rse = NULL, @Rne = NULL, @Rnw = NULL;
	end;
	--nw corner
	else if @Node = @AreaColumn*(@AreaRow - 1) + 1
	begin
		select @Rsw = NULL, @Rse = @Node + 1 - @Node/@AreaColumn - @AreaColumn, @Rne = NULL, @Rnw = NULL;
	end;

	--e border
	else if exists (select 1 where @node in (select NodeNumber from AreaNode where NodeNumber%@AreaColumn = 0 and NodeNumber not in (@AreaColumn, @AreaColumn*@AreaRow)))
	begin
		select @Rsw = @Node - (@Node - 1)/@AreaColumn - @AreaColumn, @Rse = NULL, @Rne = NULL, @Rnw = @Node - 1 - (@Node - 1 - 1)/@AreaColumn;
	end;
	--w border
	else if (exists (select 1 where @node in (select NodeNumber + 1 from AreaNode where NodeNumber%@AreaColumn = 0)) and (@node <> @AreaColumn*(@AreaRow-1) + 1)) 
	begin
		select @Rsw = null, @Rse = @node + 1 - @node/@AreaColumn - @AreaColumn, @Rne = @Node - (@Node - 1)/@AreaColumn, @Rnw = null;
	end;
	select @fourRegions = '<parameters><sw>' + isnull(cast(@Rsw as varchar),'') + '</sw><se>'+ isnull(cast(@Rse as varchar),'') + '</se><ne>'+ isnull(cast(@Rne as varchar),'') +'</ne><nw>'+ isnull(cast(@Rnw as varchar),'') + '</nw></parameters>';
	return @fourRegions;
end;


GO
