--
-- execute uspUpdateUserAddress N'<parameters><logonid>cli</logonid><firstname>Charles</firstname><lastname>Li</lastname><gps>1</gps><long>-73.61946</long><lat>41.273839</lat><street>20A Gideon Reynolds Rd</street><city>Cross River</city><state>NY</state><country>USA</country><zipcode>10518</zipcode><phone>19140010001</phone><phone>19140010003</phone><ext>123</ext><ext></ext><email>charles.li.wccc@gmail.com</email><wechat>a123456</wechat></parameters>'
--
CREATE procedure [dbo].[uspUpdateUserAddress]
@xmlparm xml
as
begin
	declare @LogonID nvarchar(200), @firstName nvarchar(100), @middleName nvarchar(100), @lastName nvarchar(100), @gps int, @longtitude nvarchar(10), @latitude nvarchar(10), @street nvarchar(500), @city nvarchar(200), @state nvarchar(200), @country nvarchar(100), @zipcode nvarchar(20), @email nvarchar(200), @wechat nvarchar(100), @regionName nvarchar(100);
	declare @phoneList table (id int identity, phone nvarchar(20))
	declare @extList table (id int identity, ext nvarchar(10))
	declare @phonewithExtList table (id int identity, phone nvarchar(20), ext nvarchar(10))

	select
    @LogonID = tbl.users.value('logonid[1]', 'nvarchar(200)'),
	@firstName = tbl.users.value('firstname[1]', 'nvarchar(100)'),
	@middleName = tbl.users.value('middlename[1]', 'nvarchar(100)'),
	@lastName =	tbl.users.value('lastname[1]', 'nvarchar(100)'),
	@gps = tbl.users.value('gps[1]', 'int'),
	@longtitude = tbl.users.value('long[1]', 'nvarchar(10)'),
	@latitude = tbl.users.value('lat[1]', 'nvarchar(10)'),
	@street = tbl.users.value('street[1]', 'nvarchar(500)'),
	@city =	tbl.users.value('city[1]', 'nvarchar(200)'),
	@state = tbl.users.value('state[1]', 'nvarchar(200)'),
	@country = tbl.users.value('country[1]', 'nvarchar(100)'),
	@zipcode =	tbl.users.value('zipcode[1]', 'nvarchar(20)'),
	@email = tbl.users.value('email[1]', 'nvarchar(200)'),
	@wechat = tbl.users.value('wechat[1]', 'nvarchar(100)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	select @regionName = dbo.udfRegion(@longtitude,@latitude)

	insert into @phoneList
	select tbl.users.value('.', 'nvarchar(20)') from @xmlparm.nodes('/parameters/phone') AS tbl(users);
	delete @phoneList where ltrim(rtrim(isnull(phone,''))) ='';
	--select * from @phoneList

	insert into @extList
	select tbl.users.value('.', 'nvarchar(10)') from @xmlparm.nodes('/parameters/ext') AS tbl(users);
	--select * from @extList

	insert into @phonewithExtList
	select p.phone, e.ext from @phoneList p left join @extList e on e.id = p.id 

	begin tran

	begin try
		--update user info
		update [User]
		set FirstName = @firstName, 
		MiddleName = @middleName, 
		LastName = @lastName, 
		Longtitude = @longtitude, 
		Latitude = @latitude, 
		Street = @street,
		City = @city,
		State = @state,
		Country = @country,
		Zipcode = @zipcode,
		email = @email,
		wechat = @wechat
		where LogonID = @LogonID;

		declare @userID int = (select ID from [User] where LogonID = @LogonID);

		--update user region
		delete UserRegion where UserID = @userID;
		insert into UserRegion
		(UserID, RegionID)
		select @userID, (select ID from Region2 where Name = @regionName);

		--update user phone info
		delete UserPhone where UserID = @userID; 

		insert Phone (Phone, Ext, Type) 
		select pl.phone, pl.ext, '' 
		from @phonewithExtList pl
		where not exists (select 1 from Phone p where p.Phone = pl.phone and p.Ext=pl.ext);

		insert UserPhone (UserID, PhoneID, FirstPhone) 
		select @userID, p.ID, case when pl.ID = 1 then 1 else 0 end   
		from Phone p 
		join @phonewithExtList pl on pl.phone = p.Phone and pl.ext = p.Ext; 

		if (@gps = 1)
		begin
			print 'Adjust RegionElement for user gps change';

			declare @regionID int;
			declare @E float, @N float;

			select 
			@E = Coordinate.value('(/parameters/ne/lo)[1]','float'), 
			@N = Coordinate.value('(/parameters/ne/la)[1]','float'),
			@regionID = ID
			from Region2 r
			where Name = @regionName;

			delete UserRegionElement where UserID = @userID;

			if(@E = @longtitude and @N = @latitude)
			--NE corner
			begin
				print 'NE corner';
				insert into UserRegionElement
				(UserID, RegionElementID)
				select @userID, max(re.ID) 
				from RegionElement re
				where re.RegionID = @regionID;
			end;
			else
			--E, N border and inner points
			begin
				insert into UserRegionElement
				(UserID, RegionElementID)
				select @userID, re.ID 
				from RegionElement re
				join (select a.NodeNumber - r.ColumnNumber - (a.NodeNumber - 1)/r.ColumnNumber as ElementNumber, r.ID 
				from Region2 r
				join (select  min(rn.NodeNumber) as NodeNumber, r.ID
				from Region2 r
				join RegionNode rn on rn.RegionID = r.ID
				join Node1 n on rn.NodeID = n.ID
				where n.Latitude >= @latitude and n.Longtitude >= @longtitude and r.Name = @regionName
				group by r.ID) a on a.ID = r.ID) b on re.ElementNumber = b.ElementNumber and b.ID = re.RegionID;
			end;
		end;

	end try
	begin catch
		declare @ErrorNumber int, @ErrorSeverity int, @ErrorState int, @ErrorProcedure nvarchar(100), @ErrorLine int, @ErrorMessage varchar(500);
		if @@TRANCOUNT > 0 rollback tran;
			SELECT @ErrorNumber = ERROR_NUMBER()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE()
			,@ErrorProcedure = ERROR_PROCEDURE()
			,@ErrorLine = ERROR_LINE()
			,@ErrorMessage = ERROR_MESSAGE();
		throw 500000, @ErrorMessage, @ErrorState;
	end catch;
	if @@TRANCOUNT > 0 commit tran;
end;


GO
