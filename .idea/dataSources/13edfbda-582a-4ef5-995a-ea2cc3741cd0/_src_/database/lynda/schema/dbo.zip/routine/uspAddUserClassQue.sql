


--
-- uspAddUserClassQue N'<parameters><Class><ClassName>语言课班级1</ClassName><UserLogon>hxgnylb25Student3</UserLogon></Class><Class><ClassName>文体课班级1</ClassName><UserLogon>hxgnylb25Student4</UserLogon></Class></parameters>'
-- uspAddUserClassQue N'<parameters><Class><ClassName>哇哇的班级</ClassName><UserLogon>hxgnylb25</UserLogon></Class></parameters>'
-- uspAddUserClassQue N'<parameters><Class><ClassName>测试1班</ClassName><UserLogon>hxgnylb25</UserLogon></Class></parameters>'
--
CREATE procedure [dbo].[uspAddUserClassQue]
@xmlparm xml
as
begin

	declare @ErrorNumber int, @ErrorSeverity int, @ErrorState int, @ErrorProcedure nvarchar(100), @ErrorLine int, @ErrorMessage varchar(500);
	declare @userID int;

	select
	tbl.users.value('ClassName[1]', 'nvarchar(100)') as ClassName, 
	tbl.users.value('UserLogon[1]', 'nvarchar(200)') as UserLogon
	into #UserClass
	from @xmlparm.nodes('/parameters/Class') AS tbl(users);

	select c.ID ClassID, u.ID UserID
	into #UserClass1
	from #UserClass uc
	join [User] u on uc.UserLogon = u.LogonID
	join [hxgnyClass] c on c.Name = uc.ClassName


	begin tran

	begin try
		insert into hxgnyUserClassQue
		(UserID, ClassID, [Order])
		select uc.UserID, uc.ClassID, isnull(max(cq.[Order]),0) + 1 
		from #UserClass1 uc
		left outer join hxgnyUserClassQue cq on cq.ClassID = uc.ClassID
		group by uc.UserID, uc.ClassID;


		DECLARE User_cursor CURSOR FOR   
		SELECT UserID FROM #UserClass1  

		OPEN User_cursor  
		FETCH NEXT FROM User_cursor INTO @userID  
		WHILE @@FETCH_STATUS = 0  
		BEGIN  
			if exists(select 1 from hxgnyUserQued where UserID = @userID)
				update hxgnyUserQued set Qued = Qued + 1;
			else
				insert into hxgnyUserQued (UserID, Qued) values (@userID, 1)

			FETCH NEXT FROM User_cursor INTO @userID  
		END  
		CLOSE User_cursor;  
		DEALLOCATE User_cursor;  

	end try
		begin catch
		    if @@TRANCOUNT > 0 rollback tran;
			    SELECT @ErrorNumber = ERROR_NUMBER()
				,@ErrorSeverity = ERROR_SEVERITY()
				,@ErrorState = ERROR_STATE()
				,@ErrorProcedure = ERROR_PROCEDURE()
				,@ErrorLine = ERROR_LINE()
				,@ErrorMessage = ERROR_MESSAGE();

			throw 500000, @ErrorMessage, @ErrorState;
		end catch;
	
	if @@TRANCOUNT > 0 commit tran;

end;


GO
