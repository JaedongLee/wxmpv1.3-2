

--
-- uspAddebtTradeTransaction N'<parameters><orderid>123456789012345678901234567890</orderid><tradename>Regular</tradename><transactiontype>Initial</transactiontype><description>Regular Trade</description><fromOwnerID>25349</fromOwnerID><toOwnerID>25353</toOwnerID><amount>100</amount></parameters>'
-- uspAddebtTradeTransaction N'<parameters><orderid>123456789012345678901234567890</orderid><tradename>Regular</tradename><transactiontype>ActionAfterComfirmedFundingAndSales</transactiontype><description>Regular Trade</description><fromOwnerID>25349</fromOwnerID><toOwnerID>25353</toOwnerID><amount>100</amount></parameters>'
-- uspAddebtTradeTransaction N'<parameters><orderid>123456789012345678901234567890</orderid><tradename>Regular</tradename><transactiontype>ActionAfterRejectedFundingOrSales</transactiontype><description>Regular Trade</description><fromOwnerID>25349</fromOwnerID><toOwnerID>25353</toOwnerID><amount>100</amount></parameters>'
-- uspAddebtTradeTransaction N'<parameters><orderid>123456789012345678901234567891</orderid><tradename>Recharge</tradename><transactiontype>Recharge</transactiontype><description>Recharge Account</description><fromOwnerID>25349</fromOwnerID><toOwnerID>25349</toOwnerID><amount>10000</amount></parameters>'
-- uspAddebtTradeTransaction N'<parameters><orderid>123456789012345678901234567892</orderid><tradename>Cashout</tradename><transactiontype>Cashout</transactiontype><description>Cashout</description><fromOwnerID>25349</fromOwnerID><toOwnerID>25349</toOwnerID><amount>10000</amount></parameters>'
-- uspAddebtTradeTransaction N'<parameters><orderid>123456789012345678901234567893</orderid><tradename>BorrowQuota</tradename><transactiontype>BorrowQuota</transactiontype><description>BorrowQuota</description><fromOwnerID>25215</fromOwnerID><toOwnerID>25349</toOwnerID><amount>1000000</amount></parameters>'
-- uspAddebtTradeTransaction N'<parameters><orderid>123456789012345678901234567893</orderid><tradename>ReturnQuota</tradename><transactiontype>ReturnQuota</transactiontype><description>ReturnQuota</description><fromOwnerID>25349</fromOwnerID><toOwnerID>25215</toOwnerID><amount>1000000</amount></parameters>'
-- uspAddebtTradeTransaction N'<parameters><orderid>123456789012345678901234567894</orderid><tradename>MembershipFee</tradename><transactiontype>MembershipFee</transactiontype><description>MembershipFee</description><fromOwnerID>25349</fromOwnerID><toOwnerID>25215</toOwnerID><amount>600</amount></parameters>'
-- uspAddebtTradeTransaction N'<parameters><orderid>123456789012345678901234567895</orderid><tradename>MembershipFee</tradename><transactiontype>MembershipFeeC</transactiontype><description>MembershipFee Cash</description><fromOwnerID>25349</fromOwnerID><toOwnerID>25215</toOwnerID><amount>400</amount></parameters>'
--
CREATE procedure [dbo].[uspAddebtTradeTransaction]
@xmlparm xml
as
begin
	SET  XACT_ABORT, NOCOUNT ON;


	declare @tradename nvarchar(100), @transactiontypename nvarchar(100), @tradeid int, @transactionid int, @transactiontypeid int, @orderid nvarchar(100);
	declare @description nvarchar(300), @amount numeric(12,3);
	declare @deduct varchar(2);
	declare @fromaccountid int, @toaccountid int, @fromownerid int, @toownerid int, @amount90 numeric(12,3), @amount10 numeric(12,3);
	declare @msg nvarchar(2048)

	select
	@orderid = tbl.users.value('orderid[1]', 'nvarchar(100)'), 
	@tradename = tbl.users.value('tradename[1]', 'nvarchar(100)'), 
	@transactiontypename = tbl.users.value('transactiontype[1]', 'nvarchar(100)'),
	@amount = tbl.users.value('amount[1]', 'numeric(12,3)'), 
	@amount90 = tbl.users.value('amount[1]', 'numeric(12,3)')*0.9, 
	@amount10 = tbl.users.value('amount[1]', 'numeric(12,3)')*0.1,
	@fromownerid = tbl.users.value('fromOwnerID[1]', 'int'),
	@toownerid = tbl.users.value('toOwnerID[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	select @transactiontypeid = ID 
	from ebtTransactionType 
	where Name = @transactiontypename;


	if @tradename = 'Regular'
	begin
		begin tran
		if @transactiontypename = 'Initial'
		begin try
			--exec uspAddebtTrade @xmlparm;
			select
			@orderid = tbl.users.value('orderid[1]', 'nvarchar(100)'), 
			@tradename = tbl.users.value('tradename[1]', 'nvarchar(100)'), 
			@description = tbl.users.value('description[1]', 'nvarchar(300)'),
			@fromownerid = tbl.users.value('fromOwnerID[1]', 'int'), 
			@toownerid = tbl.users.value('toOwnerID[1]', 'int'),
			@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
			from @xmlparm.nodes('/parameters') AS tbl(users)

			insert into ebtTrade
			(Name, Description, FromOwnerID, ToOwnerID, Amount, OrderID)
			select @tradename, @description, @fromOwnerID, @toOwnerID, @amount, @orderid 

			select @tradeid = ID from ebtTrade where OrderID = @orderid;

			set @xmlparm.modify('insert (<tradeid>{sql:variable("@tradeid")}</tradeid>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<transtype>{sql:variable("@transactiontypeid")}</transtype>) before (/parameters[1]/tradename[1])')
			exec uspAddebtTransaction @xmlparm;
			select @transactionid = max(ID) from [ebtTransaction];
			set @xmlparm.modify('insert (<transactionid>{sql:variable("@transactionid")}</transactionid>) before (/parameters[1]/tradename[1])')

			--from buyer account to transient account
			select
			@fromownerid = tbl.users.value('fromOwnerID[1]', 'int'), 
			@toownerid = tbl.users.value('toOwnerID[1]', 'int') 
			from @xmlparm.nodes('/parameters') AS tbl(users);

			select @fromaccountid = ID from ebtAccount where Type = 'Member' and OwnerID = @fromownerid;
			select @toaccountid = ID from ebtAccount where Type = 'Transient' and OwnerID = 25215 --eBoss;
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('replace value of (/parameters/amount/text())[1] with (/parameters/amount)[1]*0.9')

			--exec uspAddebtJournal @xmlparm;
			select
			@tradeid = tbl.users.value('tradeid[1]', 'int'), 
			@transactionid = tbl.users.value('transactionid[1]', 'int'), 
			@description = tbl.users.value('description[1]', 'nvarchar(500)'),
			@fromaccountID = tbl.users.value('fromaccountID[1]', 'int'), 
			@toaccountID = tbl.users.value('toaccountID[1]', 'int'), 
			@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
			from @xmlparm.nodes('/parameters') AS tbl(users)

			insert into ebtJournal
			(TradeID, TransactionID, Description, FromAccountID, ToAccountID, Amount)
			select @tradeid, @transactionid, @description, @fromaccountid, @toaccountID, @amount 

			--exec uspUpdateebtAccount @xmlparm;
			select
			@fromaccountid = tbl.users.value('fromaccountID[1]', 'int'), 
			@toaccountid = tbl.users.value('toaccountID[1]', 'int'), 
			@deduct = tbl.users.value('deduct[1]', 'varchar(2)'), 
			@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
			from @xmlparm.nodes('/parameters') AS tbl(users)

			if @deduct = 'no'
			begin
				print 'no deduct';
			end;
			else
			begin
				update ebtAccount
				set Balance = Balance - @amount
				where ID = @fromaccountid
			end;

			update ebtAccount
			set Balance = Balance + @amount
			where ID = @toaccountid


			--from buyer PayPal account to transient PayPal account
			select @fromaccountid = ID from ebtAccount where Type= 'MemberP' and OwnerID = @fromownerid;
			select @toaccountid = ID from ebtAccount where Type = 'TransientP' and OwnerID = 25215 --eBoss;

			set @xmlparm.modify('delete (/parameters/fromaccountID)[1]')
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/toaccountID)[1]')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/amount)[1]')
			set @xmlparm.modify('insert (<amount>{sql:variable("@amount10")}</amount>) after (/parameters[1]/toOwnerID[1])')
			
			--exec uspAddebtJournal @xmlparm;
			select
			@tradeid = tbl.users.value('tradeid[1]', 'int'), 
			@transactionid = tbl.users.value('transactionid[1]', 'int'), 
			@description = tbl.users.value('description[1]', 'nvarchar(500)'),
			@fromaccountID = tbl.users.value('fromaccountID[1]', 'int'), 
			@toaccountID = tbl.users.value('toaccountID[1]', 'int'), 
			@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
			from @xmlparm.nodes('/parameters') AS tbl(users)

			insert into ebtJournal
			(TradeID, TransactionID, Description, FromAccountID, ToAccountID, Amount)
			select @tradeid, @transactionid, @description, @fromaccountid, @toaccountID, @amount 

			--exec uspUpdateebtAccount @xmlparm;
			select
			@fromaccountid = tbl.users.value('fromaccountID[1]', 'int'), 
			@toaccountid = tbl.users.value('toaccountID[1]', 'int'), 
			@deduct = tbl.users.value('deduct[1]', 'varchar(2)'), 
			@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
			from @xmlparm.nodes('/parameters') AS tbl(users)

			if @deduct = 'no'
			begin
				print 'no deduct';
			end;
			else
			begin
				update ebtAccount
				set Balance = Balance - @amount
				where ID = @fromaccountid
			end;

			update ebtAccount
			set Balance = Balance + @amount
			where ID = @toaccountid


			--from transient PayPal account to CVT account
			select @fromaccountid = ID from ebtAccount where Type= 'TransientP' and OwnerID = 25215;
			select @toaccountid = ID from ebtAccount where Type = 'CVT' and OwnerID = 25215 --eBoss;

			set @xmlparm.modify('delete (/parameters/fromaccountID)[1]')
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/toaccountID)[1]')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')

			--exec uspAddebtJournal @xmlparm;
			select
			@tradeid = tbl.users.value('tradeid[1]', 'int'), 
			@transactionid = tbl.users.value('transactionid[1]', 'int'), 
			@description = tbl.users.value('description[1]', 'nvarchar(500)'),
			@fromaccountID = tbl.users.value('fromaccountID[1]', 'int'), 
			@toaccountID = tbl.users.value('toaccountID[1]', 'int'), 
			@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
			from @xmlparm.nodes('/parameters') AS tbl(users)

			insert into ebtJournal
			(TradeID, TransactionID, Description, FromAccountID, ToAccountID, Amount)
			select @tradeid, @transactionid, @description, @fromaccountid, @toaccountID, @amount 

			--exec uspUpdateebtAccount @xmlparm;
			select
			@fromaccountid = tbl.users.value('fromaccountID[1]', 'int'), 
			@toaccountid = tbl.users.value('toaccountID[1]', 'int'), 
			@deduct = tbl.users.value('deduct[1]', 'varchar(2)'), 
			@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
			from @xmlparm.nodes('/parameters') AS tbl(users)

			if @deduct = 'no'
			begin
				print 'no deduct';
			end;
			else
			begin
				update ebtAccount
				set Balance = Balance - @amount
				where ID = @fromaccountid
			end;

			update ebtAccount
			set Balance = Balance + @amount
			where ID = @toaccountid

			--from CVT account to transient account
			select @fromaccountid = ID from ebtAccount where Type= 'CVT' and OwnerID = 25215;
			select @toaccountid = ID from ebtAccount where Type = 'Transient' and OwnerID = 25215 --eBoss;

			set @xmlparm.modify('delete (/parameters/fromaccountID)[1]')
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/toaccountID)[1]')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')

			--exec uspAddebtJournal @xmlparm;
			select
			@tradeid = tbl.users.value('tradeid[1]', 'int'), 
			@transactionid = tbl.users.value('transactionid[1]', 'int'), 
			@description = tbl.users.value('description[1]', 'nvarchar(500)'),
			@fromaccountID = tbl.users.value('fromaccountID[1]', 'int'), 
			@toaccountID = tbl.users.value('toaccountID[1]', 'int'), 
			@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
			from @xmlparm.nodes('/parameters') AS tbl(users)

			insert into ebtJournal
			(TradeID, TransactionID, Description, FromAccountID, ToAccountID, Amount)
			select @tradeid, @transactionid, @description, @fromaccountid, @toaccountID, @amount 

			set @xmlparm.modify('insert (<deduct>no</deduct>) before (/parameters[1]/tradename[1])')

			--exec uspUpdateebtAccount @xmlparm;
			select
			@fromaccountid = tbl.users.value('fromaccountID[1]', 'int'), 
			@toaccountid = tbl.users.value('toaccountID[1]', 'int'), 
			@deduct = tbl.users.value('deduct[1]', 'varchar(2)'), 
			@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
			from @xmlparm.nodes('/parameters') AS tbl(users)

			if @deduct = 'no'
			begin
				print 'no deduct';
			end;
			else
			begin
				update ebtAccount
				set Balance = Balance - @amount
				where ID = @fromaccountid
			end;

			update ebtAccount
			set Balance = Balance + @amount
			where ID = @toaccountid

			commit tran;
		end try
		begin catch
			if @@trancount > 0 rollback tran;
			set @msg = error_message()  
			raiserror (@msg, 16, 1);
			return 55555;
		end catch

		else if @transactiontypename = 'ActionAfterComfirmedFundingAndSales'
		begin try
			select
			@orderid = tbl.users.value('orderid[1]', 'nvarchar(100)') 
			from @xmlparm.nodes('/parameters') AS tbl(users)

			select @tradeid = ID from ebtTrade where OrderID = @orderid;

			set @xmlparm.modify('insert (<tradeid>{sql:variable("@tradeid")}</tradeid>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<transtype>{sql:variable("@transactiontypeid")}</transtype>) before (/parameters[1]/tradename[1])')

			exec uspAddebtTransaction @xmlparm;
			select @transactionid = max(ID) from [ebtTransaction];
			set @xmlparm.modify('insert (<transactionid>{sql:variable("@transactionid")}</transactionid>) before (/parameters[1]/tradename[1])')

			declare @amount5 numeric(12,3);

			select
			@fromownerid = tbl.users.value('fromOwnerID[1]', 'int'), 
			@toownerid = tbl.users.value('toOwnerID[1]', 'int'),
			@amount5 = tbl.users.value('amount[1]', 'numeric(12,3)')*0.05
			from @xmlparm.nodes('/parameters') AS tbl(users);

			--from transient account to seller account
			select @fromaccountid = ID from ebtAccount where Type = 'Transient' and OwnerID = 25215 --eBoss;
			select @toaccountid = ID from ebtAccount where Type = 'Member' and OwnerID = @toownerid;

			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('replace value of (/parameters/amount/text())[1] with (/parameters/amount)[1]*0.95')
			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			
			--from transient account to commission account
			select @fromaccountid = ID from ebtAccount where Type= 'Transient' and OwnerID = 25215;
			select @toaccountid = ID from ebtAccount where Type = 'Commission' and OwnerID = 25215 --eBoss;

			set @xmlparm.modify('delete (/parameters/fromaccountID)[1]')
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/toaccountID)[1]')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/amount)[1]')
			set @xmlparm.modify('insert (<amount>{sql:variable("@amount5")}</amount>) after (/parameters[1]/toOwnerID[1])')
			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			commit tran;
		end try
		begin catch
			if @@trancount > 0 rollback tran;
			set @msg = error_message()  
			raiserror (@msg, 16, 1);
			return 55555;
		end catch

		else if @transactiontypename = 'ActionAfterRejectedFundingOrSales'
		begin try
			select
			@orderid = tbl.users.value('orderid[1]', 'nvarchar(100)') 
			from @xmlparm.nodes('/parameters') AS tbl(users)

			select @tradeid = ID from ebtTrade where OrderID = @orderid;

			set @xmlparm.modify('insert (<tradeid>{sql:variable("@tradeid")}</tradeid>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<transtype>{sql:variable("@transactiontypeid")}</transtype>) before (/parameters[1]/tradename[1])')

			exec uspAddebtTransaction @xmlparm;
			select @transactionid = max(ID) from [ebtTransaction];
			set @xmlparm.modify('insert (<transactionid>{sql:variable("@transactionid")}</transactionid>) before (/parameters[1]/tradename[1])')


			--from Transient account to CVT account
			select @fromaccountid = ID from ebtAccount where Type = 'Transient' and OwnerID = 25215 --eBoss;
			select @toaccountid = ID from ebtAccount where Type = 'CVT' and OwnerID = 25215 --eBoss;

			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('replace value of (/parameters/amount/text())[1] with (/parameters/amount)[1]*0.1')
			set @xmlparm.modify('insert (<increase>no</increase>) before (/parameters[1]/tradename[1])')
			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			--from CVT accoount to Transient PayPal account
			select @fromaccountid = ID from ebtAccount where  Type = 'CVT' and OwnerID = 25215 --eBoss;
			select @toaccountid = ID from ebtAccount where Type = 'TransientP' and OwnerID = 25215 --eBoss;

			set @xmlparm.modify('delete (/parameters/fromaccountID)[1]')
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/toaccountID)[1]')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/increase)[1]')
			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			--from Transient PayPal account to Memeber PayPal account
			select @fromaccountid = ID from ebtAccount where  Type = 'TransientP' and OwnerID = 25215 --eBoss;
			select @toaccountid = ID from ebtAccount where Type = 'MemberP' and OwnerID = @fromownerid;

			set @xmlparm.modify('delete (/parameters/fromaccountID)[1]')
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/toaccountID)[1]')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')
			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			--from Transient account to Member account
			select @fromaccountid = ID from ebtAccount where  Type = 'Transient' and OwnerID = 25215 --eBoss;
			select @toaccountid = ID from ebtAccount where Type = 'Member' and OwnerID = @fromownerid;

			set @xmlparm.modify('delete (/parameters/fromaccountID)[1]')
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/toaccountID)[1]')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/amount)[1]')
			set @xmlparm.modify('insert (<amount>{sql:variable("@amount90")}</amount>) after (/parameters[1]/toOwnerID[1])')
			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			commit tran;
		end try
		begin catch
			if @@trancount > 0 rollback tran;
			set @msg = error_message()  
			raiserror (@msg, 16, 1);
			return 55555;
		end catch
	end
	else if @tradename = 'Recharge' and @transactiontypename = 'Recharge'
	begin
		begin tran
		begin try
			exec uspAddebtTrade @xmlparm;

			select @tradeid = ID from ebtTrade where OrderID = @orderid;
			set @xmlparm.modify('insert (<tradeid>{sql:variable("@tradeid")}</tradeid>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<transtype>{sql:variable("@transactiontypeid")}</transtype>) before (/parameters[1]/tradename[1])')

			exec uspAddebtTransaction @xmlparm;

			select @transactionid = max(ID) from [ebtTransaction];
			set @xmlparm.modify('insert (<transactionid>{sql:variable("@transactionid")}</transactionid>) before (/parameters[1]/tradename[1])')

			--from member PayPal account to ebarter PayPal transient account
			select @fromaccountid = ID from ebtAccount where Type= 'MemberP' and OwnerID = @fromownerid;
			select @toaccountid = ID from ebtAccount where Type = 'TransientP' and OwnerID = 25215 --eBoss;

			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')

			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;
			
			--from ebarter PayPal transient account to recharge account
			select @fromaccountid = ID from ebtAccount where Type = 'TransientP' and OwnerID = 25215 --eBoss;
			select @toaccountid = ID from ebtAccount where Type= 'Recharge' and OwnerID = 25215;

			set @xmlparm.modify('delete (/parameters/fromaccountID)[1]')
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/toaccountID)[1]')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')

			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			--from recharge account to member account
			select @fromaccountid = ID from ebtAccount where Type= 'Recharge' and OwnerID = 25215; --eBoss; 
			select @toaccountid = ID from ebtAccount where Type = 'Member' and OwnerID = @fromownerid 

			set @xmlparm.modify('delete (/parameters/fromaccountID)[1]')
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/toaccountID)[1]')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<deduct>no</deduct>) before (/parameters[1]/tradename[1])')

			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			commit tran;
		end try
		begin catch
			if @@trancount > 0 rollback tran;
			set @msg = error_message()  
			raiserror (@msg, 16, 1);
			return 55555;
		end catch
	end
	else if @tradename = 'Cashout' and @transactiontypename = 'Cashout'
	begin
		begin tran
		begin try
			exec uspAddebtTrade @xmlparm;

			select @tradeid = ID from ebtTrade where OrderID = @orderid;
			set @xmlparm.modify('insert (<tradeid>{sql:variable("@tradeid")}</tradeid>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<transtype>{sql:variable("@transactiontypeid")}</transtype>) before (/parameters[1]/tradename[1])')

			exec uspAddebtTransaction @xmlparm;

			select @transactionid = max(ID) from [ebtTransaction];
			set @xmlparm.modify('insert (<transactionid>{sql:variable("@transactionid")}</transactionid>) before (/parameters[1]/tradename[1])')

			--from Member account to Recharge account
			select @fromaccountid = ID from ebtAccount where Type= 'Member' and OwnerID = @fromownerid;
			select @toaccountid = ID from ebtAccount where Type = 'Recharge' and OwnerID = 25215 --eBoss;

			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<increase>no</increase>) before (/parameters[1]/tradename[1])')

			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			--from Recharge account to PayPal transient
			select @fromaccountid = ID from ebtAccount where Type = 'Recharge' and OwnerID = 25215 --eBoss;
			select @toaccountid = ID from ebtAccount where Type= 'TransientP' and OwnerID =  25215 --eBoss;

			set @xmlparm.modify('delete (/parameters/fromaccountID)[1]')
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/toaccountID)[1]')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/increase)[1]')

			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			--from PayPal transient to Member PayPal
			select @fromaccountid = ID from ebtAccount where Type = 'TransientP' and OwnerID = 25215 --eBoss;
			select @toaccountid = ID from ebtAccount where Type= 'MemberP' and OwnerID = @fromownerid;

			set @xmlparm.modify('delete (/parameters/fromaccountID)[1]')
			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('delete (/parameters/toaccountID)[1]')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')

			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			commit tran;
		end try
		begin catch
			if @@trancount > 0 rollback tran;
			set @msg = error_message()  
			raiserror (@msg, 16, 1);
			return 55555;
		end catch
	end
	else if @tradename = 'BorrowQuota' and @transactiontypename = 'BorrowQuota'
	begin
		begin tran
		begin try
			exec uspAddebtTrade @xmlparm;

			select @tradeid = ID from ebtTrade where OrderID = @orderid;
			set @xmlparm.modify('insert (<tradeid>{sql:variable("@tradeid")}</tradeid>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<transtype>{sql:variable("@transactiontypeid")}</transtype>) before (/parameters[1]/tradename[1])')

			exec uspAddebtTransaction @xmlparm;

			select @transactionid = max(ID) from [ebtTransaction];
			set @xmlparm.modify('insert (<transactionid>{sql:variable("@transactionid")}</transactionid>) before (/parameters[1]/tradename[1])')

			--from Pool account to Member account
			select @fromaccountid = ID from ebtAccount where Type = 'Pool' and OwnerID = 25215 --eBoss;
			select @toaccountid = ID from ebtAccount where Type= 'Member' and OwnerID = @toownerid;

			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')

			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			commit tran;
		end try
		begin catch
			if @@trancount > 0 rollback tran;
			set @msg = error_message()  
			raiserror (@msg, 16, 1);
			return 55555;
		end catch
	end
	else if @tradename = 'ReturnQuota' and @transactiontypename = 'ReturnQuota'
	begin
		begin tran
		begin try
			exec uspAddebtTrade @xmlparm;

			select @tradeid = ID from ebtTrade where OrderID = @orderid;
			set @xmlparm.modify('insert (<tradeid>{sql:variable("@tradeid")}</tradeid>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<transtype>{sql:variable("@transactiontypeid")}</transtype>) before (/parameters[1]/tradename[1])')

			exec uspAddebtTransaction @xmlparm;

			select @transactionid = max(ID) from [ebtTransaction];
			set @xmlparm.modify('insert (<transactionid>{sql:variable("@transactionid")}</transactionid>) before (/parameters[1]/tradename[1])')

			--from Member account to Pool account
			select @fromaccountid = ID from ebtAccount where Type= 'Member' and OwnerID = @fromownerid;
			select @toaccountid = ID from ebtAccount where Type = 'Pool' and OwnerID = 25215 --eBoss;

			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')

			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			commit tran;
		end try
		begin catch
			if @@trancount > 0 rollback tran;
			set @msg = error_message()  
			raiserror (@msg, 16, 1);
			return 55555;
		end catch
	end
	else if @tradename = 'MembershipFee' 
	begin
	begin tran
	if  @transactiontypename = 'MembershipFee'
	begin try
			exec uspAddebtTrade @xmlparm;

			select @tradeid = ID from ebtTrade where OrderID = @orderid;
			set @xmlparm.modify('insert (<tradeid>{sql:variable("@tradeid")}</tradeid>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<transtype>{sql:variable("@transactiontypeid")}</transtype>) before (/parameters[1]/tradename[1])')

			exec uspAddebtTransaction @xmlparm;

			select @transactionid = max(ID) from [ebtTransaction];
			set @xmlparm.modify('insert (<transactionid>{sql:variable("@transactionid")}</transactionid>) before (/parameters[1]/tradename[1])')

			--from Member account to MembershipFee account
			select @fromaccountid = ID from ebtAccount where Type= 'Member' and OwnerID = @fromownerid;
			select @toaccountid = ID from ebtAccount where Type = 'Membership' and OwnerID = 25215 --eBoss;

			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')

			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			commit tran;
		end try
		begin catch
			if @@trancount > 0 rollback tran;
			set @msg = error_message()  
			raiserror (@msg, 16, 1);
			return 55555;
		end catch
	else if @transactiontypename = 'MembershipFeeC'
	begin try
			exec uspAddebtTrade @xmlparm;

			select @tradeid = ID from ebtTrade where OrderID = @orderid;
			set @xmlparm.modify('insert (<tradeid>{sql:variable("@tradeid")}</tradeid>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<transtype>{sql:variable("@transactiontypeid")}</transtype>) before (/parameters[1]/tradename[1])')

			exec uspAddebtTransaction @xmlparm;

			select @transactionid = max(ID) from [ebtTransaction];
			set @xmlparm.modify('insert (<transactionid>{sql:variable("@transactionid")}</transactionid>) before (/parameters[1]/tradename[1])')

			--from Member PayPal account to MembershipFeeC account
			select @fromaccountid = ID from ebtAccount where Type= 'MemberP' and OwnerID = @fromownerid;
			select @toaccountid = ID from ebtAccount where Type = 'MembershipC' and OwnerID = 25215 --eBoss;

			set @xmlparm.modify('insert (<fromaccountID>{sql:variable("@fromaccountid")}</fromaccountID>) before (/parameters[1]/tradename[1])')
			set @xmlparm.modify('insert (<toaccountID>{sql:variable("@toaccountid")}</toaccountID>) before (/parameters[1]/tradename[1])')

			exec uspAddebtJournal @xmlparm;
			exec uspUpdateebtAccount @xmlparm;

			commit tran;
		end try
		begin catch
			if @@trancount > 0 rollback tran;
			set @msg = error_message()  
			raiserror (@msg, 16, 1);
			return 55555;
		end catch
	end
end
GO
