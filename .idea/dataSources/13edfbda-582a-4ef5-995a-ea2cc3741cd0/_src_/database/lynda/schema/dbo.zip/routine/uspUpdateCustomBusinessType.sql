--
-- uspUpdateCustomBusinessType N'<parameters><businessType>cli-poll01</businessType><location>t;a;p</location><owner>cli.su</owner></parameters>'
--
CREATE procedure [dbo].[uspUpdateCustomBusinessType]
@xmlparm xml
as
begin
	declare @businessType nvarchar(200), @location nvarchar(10), @owner nvarchar(200), @type nvarchar(3);

	select
	@businessType = tbl.users.value('businessType[1]', 'nvarchar(200)'), 
	@location = tbl.users.value('location[1]', 'nvarchar(10)'),
	@type = tbl.users.value('type[1]', 'nvarchar(3)'),
	@owner = tbl.users.value('owner[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	update BusinessType
	set Location = @location, Type = @type
	where Name = @businessType and TypeOwnerID = (select ID from [User] where LogonID = @owner);  

end;
GO
