
--
-- uspAddebtAccount N'<parameters><name>Charles</name><description>Charles Account</description><type>Memeber</type><ownerID>10</ownerID><balance>150000.123</balance></parameters>'
--
CREATE procedure [dbo].[uspAddebtAccount]
@xmlparm xml
as
begin
	declare @name nvarchar(100), @description nvarchar(300), @type nvarchar(50), @ownerID int,  @balance numeric(12,3);
	
	select
	@name = tbl.users.value('name[1]', 'nvarchar(100)'), 
	@description = tbl.users.value('description[1]', 'nvarchar(300)'),
	@type = tbl.users.value('type[1]', 'nvarchar(50)'),
	@ownerID = tbl.users.value('ownerID[1]', 'int'), 
	@balance = tbl.users.value('balance[1]', 'numeric(12,3)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	insert into ebtAccount
	(Name, Description, Type, OwnerID, Balance)
	select @name, @description, @type, @ownerID, @balance 
end;

GO
