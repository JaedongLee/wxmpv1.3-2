
--
-- execute uspGetRegionByUserName N'<parameters><logonid>有方</logonid></parameters>'
--
CREATE procedure [dbo].[uspGetRegionByUserName]
@xmlparm xml
as
begin
	declare @logonID nvarchar(200);
	select @logonID = tbl.users.value('logonid[1]', 'nvarchar(200)') from @xmlparm.nodes('/parameters') AS tbl(users);
	 
	select distinct r.Name as Region
	from [User] u
	left join  UserRegion ur on u.ID = ur.UserID
	left join Region2 r on ur.RegionID = r.ID
	where u.LogonID = @logonID
end;


GO
