--
-- select dbo.udfUserFee('zous')
--
 create function [dbo].[udfUserFee](@logonID nvarchar(200))
  returns float
  as
  begin
	--determine region by region map and input location
	declare @fee float;
	
	select @fee = Fee 
	from UserFee uf
	join [User] u on u.ID = uf.UserID
	where u.LogonID = @logonID;

	return @fee;
  end;


GO
