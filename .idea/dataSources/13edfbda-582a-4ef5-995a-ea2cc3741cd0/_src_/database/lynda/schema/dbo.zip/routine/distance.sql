 CREATE function [dbo].[distance](@long2 float, @lat2 float, @long1 float, @lat1 float)
  returns float
  as
  begin
	declare @dlong float = (@long2 - @long1)*pi()/180, @dlat float = (@lat2-@lat1)*pi()/180;
	declare @a float = square(sin(@dlat/2)) + cos(@lat1)*cos(@lat2)*square(sin(@dlong/2));
	--declare @c float = 2*atn2(sqrt(@a), sqrt(1-@a));
	declare @c float = 2*asin(sqrt(@a));
	declare @R float = 6373;
	return @R*@c;
  end;


 GO
