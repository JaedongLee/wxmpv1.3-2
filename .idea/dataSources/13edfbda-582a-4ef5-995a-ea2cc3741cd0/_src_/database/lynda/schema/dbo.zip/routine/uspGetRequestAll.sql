

--
--exec uspGetRequestAll
--

CREATE procedure [dbo].[uspGetRequestAll]
@appName nvarchar(200)
as
BEGIN
	select Content, OwnerID as LogonID from ebtRequest;
END;


GO
