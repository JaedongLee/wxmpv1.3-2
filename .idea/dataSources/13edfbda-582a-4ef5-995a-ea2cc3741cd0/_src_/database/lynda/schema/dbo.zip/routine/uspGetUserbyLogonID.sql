--
-- execute uspGetUserbyLogonID N'<parameters><logonid>有方</logonid></parameters>'
--
CREATE procedure [dbo].[uspGetUserbyLogonID]
@xmlparm xml
as
begin
	declare @LogonID nvarchar(200);
	
	select
    @LogonID = tbl.d.value('logonid[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(d);


SELECT [ID]
      ,[LogonID]
      ,[Password]
      ,[FirstName]
      ,[MiddleName]
      ,[LastName]
      ,[Longtitude]
      ,[Latitude]
      ,[Street]
      ,[City]
      ,[State]
      ,[Country]
      ,[Zipcode]
      ,[UserType]
  FROM [dbo].[User]
  where LogonID = @LogonID;
end;


GO
