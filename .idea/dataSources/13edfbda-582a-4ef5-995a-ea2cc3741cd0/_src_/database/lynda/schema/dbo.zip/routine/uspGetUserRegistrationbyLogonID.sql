


--
-- execute uspGetUserRegistrationbyLogonID N'<parameters><logonid>cli.lynda</logonid></parameters>'
-- execute uspGetUserRegistrationbyLogonID N'<parameters><logonid>LBCS</logonid></parameters>'
--
CREATE procedure [dbo].[uspGetUserRegistrationbyLogonID]
@xmlparm xml
as
begin
	declare @LogonID nvarchar(200), @UserID int, @BusinessTypeDetial nvarchar(max);
	declare @final nvarchar(max);
	declare @ErrorNumber int, @ErrorSeverity int, @ErrorState int, @ErrorProcedure nvarchar(100), @ErrorLine int, @ErrorMessage varchar(500);
	declare @RoleName nvarchar(200), @AppName nvarchar(200);

	select
    @LogonID = tbl.d.value('logonid[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(d);
	--select @LogonID 

	select @UserID = ID from [User] where LogonID = @LogonID

	select @AppName = a.Name from UserApp ua join App a on a.ID = ua.AppID where ua.UserID = @UserID;
	select @RoleName = r.Name from UserRole ur join [Role] r on ur.RoleID = r.ID where ur.UserID = @UserID;   

	set @AppName = N'<AppName>' + isnull(@AppName,'') + N'</AppName>';
	set @RoleName = N'<RoleName>' + isNull(@RoleName,'') + N'</RoleName>';

	--Update UserPasscodeCheck if PasscodeCheck is 1
	if (exists (select 1 from UserPasscodeCheck where PasscodeCheck = 1 and UserID = @UserID))
	begin try
		begin tran
		update UserPasscodeCheck set PasscodeCheck = 0 where UserID =  @UserID;
		if @@TRANCOUNT > 0 commit tran;
	end try
	begin catch
	if @@TRANCOUNT > 0 rollback tran;
		SELECT @ErrorNumber = ERROR_NUMBER()
		,@ErrorSeverity = ERROR_SEVERITY()
		,@ErrorState = ERROR_STATE()
		,@ErrorProcedure = ERROR_PROCEDURE()
		,@ErrorLine = ERROR_LINE()
		,@ErrorMessage = ERROR_MESSAGE();
		throw 500000, @ErrorMessage, @ErrorState;
	end catch;

	--Prepare final result
	SELECT @final = N'<parameters><LogonID>' + [LogonID] + '</LogonID>' + 
      '<Password>' + [Password] + '</Password>' + 
      '<FirstName>' + isnull([FirstName],'') + '</FirstName>' +
      '<MiddleName>' + isnull([MiddleName],'') + '</MiddleName>' + 
      '<LastName>' + isnull([LastName],'') + '</LastName>' +
      '<Longtitude>' + cast(isnull([Longtitude], 0) as varchar(10)) + '</Longtitude>' +
      '<Latitude>' + cast(isnull([Latitude],0) as varchar(10)) + '</Latitude>' + 
      '<Street>' + isnull([Street],'') + '</Street>' + 
      '<City>' + isnull([City],'') + '</City>' +  
      '<State>' + isnull([State],'') + '</State>' +  
      '<Country>' + isnull([Country],'') + '</Country>' + 
      '<Zipcode>' + isnull([Zipcode],'') + '</Zipcode>' + 
      '<UserType>' + isnull([UserType],'') + '</UserType>' + 
      '<Email>' + isnull([Email],'') + '</Email>' + 
      '<WeChat>' + isnull([WeChat],'') + '</WeChat>' + 
      '<ReferenceCode>' + isnull([ReferenceCode],'') + '</ReferenceCode>' + 
	  '<Credit>' + cast(isnull(dbo.udfUserRating(@logonID),0) as varchar(2)) + '</Credit>' +
	  '<Fee>' + cast(isnull(dbo.udfUserFee(@logonID),0) as varchar(10)) + '</Fee>' +
	  '<yearsOfBusiness>' + cast(isnull(YearsOfBusiness,0) as varchar(10)) + '</yearsOfBusiness>' +
	  '<Region>' + isnull(dbo.udfUserRegion(@logonID),'') + '</Region>' +
	  '<Poll>' + cast(isnull(dbo.udfUserPoll(@logonID),'') as varchar(100)) + '</Poll>' +
	  '<LindaPoint>' + cast(isnull(dbo.udfUserLindaPoint(@logonID),0) as varchar(10)) + '</LindaPoint>' +
	  '<LastMTime>' + cast( cast(Datediff(s, '1970-01-01', DATEADD(dd, 0, DATEDIFF(dd, 0, ModificationTime))) AS bigint)*1000 + cast(Datediff(MS, DATEADD(dd, 0, DATEDIFF(dd, 0, ModificationTime)), ModificationTime) AS bigint) as varchar(30)) + '</LastMTime>' +
      '<ID>' + cast(ID as varchar(20)) + '</ID>' + 
	  '<DOB>' + isnull(cast(DOB as varchar(20)),'') + '</DOB>' + 
	  '<description>' + isnull(Description,'') + '</description>'
	FROM [dbo].[User]
	where LogonID = @LogonID;

	--select @final
	
	select @BusinessTypeDetial = BusinessTypeDetail 
	from [BusinessType]
	where TypeOwnerID = @UserID;
	set @BusinessTypeDetial = N'<BusinessTypeDetial>'+ isnull(@BusinessTypeDetial,'') + '</BusinessTypeDetial>';

	declare @BusenessTypeAll NVARCHAR(max)
	select @BusenessTypeAll = COALESCE(@BusenessTypeAll + N'</BusinessType><BusinessType>', '') + a.Name 
	from  
	(select distinct bt.Name
	from BusinessType bt
	join UserBusinessType ubt on ubt.BusinessTypeID = bt.ID
	join [User] u on u.ID = ubt.UserID 
	where u.LogonID = @LogonID and bt.Type is null) a;

	set @BusenessTypeAll = N'<BusinessType>' + @BusenessTypeAll + N'</BusinessType>'; 
	--select @BusenessTypeAll

	declare @cBusenessTypeAll NVARCHAR(max)
	select @cBusenessTypeAll = COALESCE(@cBusenessTypeAll + N'</cBusinessType><cBusinessType>', '') + a.Name 
	from
	(select distinct bt.Name
	from BusinessType bt
	join UserBusinessType ubt on ubt.BusinessTypeID = bt.ID
	join [User] u on u.ID = ubt.UserID 
	where u.LogonID = @LogonID and bt.Type like 'C%') a

	set @cBusenessTypeAll = N'<cBusinessType>' + @cBusenessTypeAll + N'</cBusinessType>'; 
	--select @cBusenessTypeAll

	declare @SpecialCategoryAll NVARCHAR(max)
	select @SpecialCategoryAll = COALESCE(@SpecialCategoryAll + N'</SpecialCategory><SpecialCategory>', '') + a.Name 
	from
	(select distinct bt.Name
	from BusinessType bt
	join UserBusinessType ubt on ubt.BusinessTypeID = bt.ID
	join [User] u on u.ID = ubt.UserID 
	where u.LogonID = @LogonID 
	and bt.Name not in (select Name from BusinessType where TypeOwnerID = @UserID union select 'StoreDiscount')) a

	set @SpecialCategoryAll = N'<SpecialCategory>' + isnull(@SpecialCategoryAll,'') + N'</SpecialCategory>'; 
	--select @SpecialCategoryAll

	declare @PhoneAll NVARCHAR(max), @ExtAll NVARCHAR(max); 
	select @PhoneAll = COALESCE(@PhoneAll + N'</Phone><Phone>', '') + p.Phone 
	from Phone p
	join UserPhone up on up.PhoneID = p.ID
	join [User] u on u.ID = up.UserID
	where u.LogonID = @LogonID and p.Phone <> ''
	order by up.FirstPhone desc;
	--select @PhoneAll

	select @ExtAll = COALESCE(@ExtAll + N'</Ext><Ext>', '') + p.Ext  
	from Phone p
	join UserPhone up on up.PhoneID = p.ID
	join [User] u on u.ID = up.UserID 
	where u.LogonID = @LogonID and p.Ext <>''
	order by up.FirstPhone desc;

	set @PhoneAll = N'<Phone>' + @PhoneAll + N'</Phone><Ext>' + isnull(@ExtAll,'') + N'</Ext>'; 
	--select @phoneAll;

	--Special workaround for JDBC
	declare @NodeList1 table (NodeNumber int);
	insert into @NodeList1 select 1;
	--End of special workaround

	set @final = @final + isNull(@BusenessTypeAll,'') + isNull(@cBusenessTypeAll,'') + isnull(@phoneAll,'')  + isnull(@SpecialCategoryAll,'') + isnull(@BusinessTypeDetial,'') + @AppName + @RoleName + N'</parameters>'; 
	select @final as Registration;
end;


GO
