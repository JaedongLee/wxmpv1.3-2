--
-- select dbo.udfRegionElementByLocation(120.949,31.5)
--
CREATE function [dbo].[udfRegionElementByLocation](@longtitude float, @latitude float)
  returns xml
  as
  begin
	declare @RegionElement varchar(200);
	select @RegionElement = '<parameters><regionID>' + cast(re.RegionID as varchar(20)) + '</regionID><elementNumber>' + cast(re.ElementNumber as varchar(20)) + '</elementNumber></parameters>'
	from RegionElement re
	join (select a.NodeNumber - r.ColumnNumber - (a.NodeNumber - 1)/r.ColumnNumber as ElementNumber, r.ID 
	from Region2 r
	join (select  min(rn.NodeNumber) as NodeNumber, r.ID
	from Region2 r
	join RegionNode rn on rn.RegionID = r.ID
	join Node1 n on rn.NodeID = n.ID
	where n.Latitude > @latitude and n.Longtitude > @longtitude and r.Name = dbo.udfRegion(@longtitude,@latitude)
	group by r.ID) a on a.ID = r.ID) b on re.ElementNumber = b.ElementNumber and b.ID = re.RegionID;

	return @RegionElement;
  end;


GO
