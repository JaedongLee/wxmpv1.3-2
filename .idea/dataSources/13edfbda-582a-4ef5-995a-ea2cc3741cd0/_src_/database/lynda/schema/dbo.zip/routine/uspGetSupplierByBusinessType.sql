--
-- execute uspGetSupplierByBusinessType N'<parameters><BusinessType>Blue Ginger</BusinessType></parameters>'
--
create procedure [dbo].[uspGetSupplierByBusinessType]
@xmlparm xml
as
begin
	declare @BusinessType nvarchar(100) = @xmlparm.value('(/parameters/BusinessType)[1]','nvarchar(100)');

	--find suppliers
	select u.LogonID as SupplierID, u.Latitude, u.Longtitude, c.Credit, r.Name as Region
	from [User] u
	join UserRegion ur on u.ID = ur.UserID
	join Region2 r on r.ID = ur.RegionID
	join UserBusinessType ubt on ubt.UserID = u.ID
	join BusinessType bt on bt.ID = ubt.BusinessTypeID
	left join UserCredit uc on uc.UserID = u.ID
	left join Credit c on c.ID = uc.CreditID
	where bt.Name = @BusinessType
	union
	select u.LogonID as SupplierID, u.Latitude, u.Longtitude, c.Credit, r.Name as Region
	from [User] u
	join UserRegion ur on u.ID = ur.UserID
	join Region2 r on r.ID = ur.RegionID
	join UserBusinessType ubt on ubt.UserID = u.ID
	join BusinessType bt on bt.ParentID = ubt.BusinessTypeID
	left join UserCredit uc on uc.UserID = u.ID
	left join Credit c on c.ID = uc.CreditID
	where bt.Name = @BusinessType;
end;
GO
