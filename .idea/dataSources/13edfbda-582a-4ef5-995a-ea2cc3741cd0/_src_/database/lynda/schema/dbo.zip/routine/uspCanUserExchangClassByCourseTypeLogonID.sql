

--
--exec uspCanUserExchangClassByCourseTypeLogonID N'<parameters><UserLogonID>hxgnylb25</UserLogonID><CourseType>Chinese</CourseType></parameters>'
--

create procedure [dbo].[uspCanUserExchangClassByCourseTypeLogonID]
@xmlparm xml
as
BEGIN
	declare @logonID nvarchar(200), @courseType nvarchar(50), @qued int, @exchangeThreshold int, @userID int;

	select @exchangeThreshold = 1

	select 
	@logonID = tbl.users.value('UserLogonID[1]', 'nvarchar(200)'),
	@courseType = tbl.users.value('CourseType[1]', 'nvarchar(50)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	select @userID = ID from [User] where LogonID = @logonID;
	select @qued = Qued from hxgnyUserCourseTypeQued where UserID = @userID and CourseType = @courseType;

	if  isnull(@qued,0) < @exchangeThreshold
		select 0 as Mode;
	else
		select -1 as Mode;		
END;
GO
