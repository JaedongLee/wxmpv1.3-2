





--
--exec uspGetCourseAll ''
--

CREATE procedure [dbo].[uspGetCourseAll]
@appName nvarchar(200)
as
BEGIN
	select ID CourseID, Name CourseName, Description, Type CourseType, OwnerID, Price, URL, GradeSize, MaterialPrice from hxgnyCourse;
END;


GO
