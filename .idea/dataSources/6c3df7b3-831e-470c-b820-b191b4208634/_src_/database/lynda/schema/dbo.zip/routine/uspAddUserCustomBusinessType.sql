--
-- uspAddUserCustomBusinessType N'<parameters><businessType>blue sky</businessType><logonID>cli.su</logonID></parameters>'
--
CREATE procedure [dbo].[uspAddUserCustomBusinessType]
@xmlparm xml
as
begin
	declare @businessType nvarchar(200), @logonID nvarchar(200);
	
	select
	@businessType = tbl.users.value('businessType[1]', 'nvarchar(200)'), 
	@logonID = tbl.users.value('logonID[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	insert into UserBusinessType
	(Active, BusinessTypeID, UserID)
	select 'A', bt.ID, bt.TypeOwnerID 
	from BusinessType bt
	join [User] u on u.ID = bt.TypeOwnerID
	where u.LogonID = @logonID
	and bt.Name = @businessType
	and not exists (select 1 from UserBusinessType where UserID = bt.TypeOwnerID and BusinessTypeID = bt.ID);
end;
GO
