

create TRIGGER [dbo].[DeleteUser] ON [dbo].[User]
AFTER DELETE 
AS
begin
delete lyndaadmin.dbo.AspNetUsers where UserName = ( select LogonID from deleted);
end;


GO
