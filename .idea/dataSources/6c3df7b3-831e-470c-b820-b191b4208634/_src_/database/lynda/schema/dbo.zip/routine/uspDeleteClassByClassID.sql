


--
--exec uspDeleteClassByClassID N'<parameters><ClassID>charles_cp</ClassID></parameters>'
--

CREATE procedure [dbo].[uspDeleteClassByClassID]
@xmlparm xml
as
BEGIN
	declare @classID int;
	select 
	@classID = tbl.users.value('ClassID[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	delete hxgnyClass 
	where ID = @classID;
END;


GO
