--
-- execute uspGetRegionByCoordinates '<parameters><longtitude>121.949</longtitude><latitude>31.5</latitude></parameters>'
--
CREATE procedure [dbo].[uspGetRegionByCoordinates]
@xmlparm xml
as
begin
	declare @long float, @lat float;

	select 
	@long = tbl.d.value('longtitude[1]', 'float'),
	@lat = tbl.d.value('latitude[1]', 'float')
	from @xmlparm.nodes('/parameters') AS tbl(d);

	select Name as Region from Region2
	where Coordinate.value('(/parameters/ne/lo)[1]','float') >= @long
	and Coordinate.value('(/parameters/sw/lo)[1]','float') < @long
	and Coordinate.value('(/parameters/ne/la)[1]','float') >= @lat
	and Coordinate.value('(/parameters/sw/la)[1]','float') < @lat
end;


GO
