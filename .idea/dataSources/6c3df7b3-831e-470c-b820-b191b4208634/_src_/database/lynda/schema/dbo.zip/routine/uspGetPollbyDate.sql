--
-- execute uspGetPollbyDate '<parameters><asofdate>02/17/2015</asofdate></parameters>'
--
CREATE procedure [dbo].[uspGetPollbyDate]
@xmlparm xml
as
begin
	declare @asofdate varchar(10);
	select
    @asofdate = tbl.d.value('.', 'varchar(30)')
	from @xmlparm.nodes('/parameters/asofdate') AS tbl(d);

	SELECT [PollID]
			,[Name]
			,[Description]
			,[TotalVote]
			,[YesVote]
			,[NoVote]
			,[StartTime]
			,[EndTime]
			,[LastTime]
			,[Latitude]
			,[Longtitude]
			,[PictureLink]
			,[Distance]
			,[UseKM]
			,[Status]
		FROM [dbo].[Poll]
	where ModificationTime > cast(@asofdate as datetime) 
	and ModificationTime < dateadd(dd, 1, cast(@asofdate as datetime));
end;


GO
