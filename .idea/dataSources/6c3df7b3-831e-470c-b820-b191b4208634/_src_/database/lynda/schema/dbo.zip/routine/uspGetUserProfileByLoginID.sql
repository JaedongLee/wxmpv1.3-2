--
-- execute uspGetUserByLoginID N'<parameters><user><logonid>cli.su</logonid></user></parameters>'
--
create procedure [dbo].[uspGetUserByLoginID]
@xmlparm xml
as
begin
	declare @LogonID nvarchar(200);

	select
    @LogonID = tbl.users.value('logonid[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters/user') AS tbl(users);

	select distinct
	u.UserType, 
	case when UserType = 'reroute' then u.LogonID else r.Name end as Region, 
	ISNULL(u.FirstName,'') as FirstName,
	ISNULL(u.LastName,'') as LastName,
	ISNULL(u.Street,'') as Street,
	ISNULL(u.City,'') as City,
	ISNULL(u.[State],'') as [State],
	ISNULL(u.Country,'') as Country, 
	ISNULL(u.Zipcode,'') as Zipcode, 
	ISNULL(p.Phone,'') + '-' + ISNULL(p.Ext,'') as Phone,
	cast(Datediff(s, '1970-01-01', DATEADD(dd, 0, DATEDIFF(dd, 0, u.ModificationTime))) AS bigint)*1000 + cast(Datediff(MS, DATEADD(dd, 0, DATEDIFF(dd, 0, u.ModificationTime)), u.ModificationTime) AS bigint) as ModificationTime
	from [User] u
	left join  UserRegion ur on u.ID = ur.UserID
	left join Region2 r on ur.RegionID = r.ID
	left join UserPhone up on up.UserID = u.ID
	left join Phone p on p.ID = up.PhoneID
	where LogonID = @LogonID and (up.FirstPhone = 1 or up.FirstPhone is null) and u.ID not in (select UserID from UserDeleted);
end;

GO
