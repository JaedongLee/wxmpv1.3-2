--
-- execute uspGetUrlByRegion N'<parameters><region>Beijing</region></parameters>'
--

CREATE procedure [dbo].[uspGetUrlByRegion]
@xmlparm xml
as
begin
	select Url,isnull(Password,'') as Password from Region2 where Name = (select tbl.d.value('.', 'varchar(100)') from @xmlparm.nodes('/parameters/region') as tbl(d));
end;


GO
