
--
-- uspGetClassByLogonID N'<parameters><LogonID>hxgnylb30</LogonID></parameters>'
--
CREATE procedure [dbo].[uspGetClassByLogonID]
@xmlparm xml
as
begin
	declare @logonID nvarchar(200);
	
	select
	@logonID = tbl.users.value('LogonID[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(users)


	select uc.ClassID, c.Name as ClassName, c.CourseID
	into #ClassInfo
	from hxgnyUserClass uc
	join hxgnyClass c on c.ID = uc.ClassID
	join [User] u on u.ID = uc.UserID
	where u.LogonID = @logonID

	select u.LogonID, u.ID  
	into #teacher
	from UserRole ur
	join [Role] r on r.ID = ur.RoleID
	join [User] u on u.ID = ur.UserID
	where r.Name = 'hxgnyTeacher';
	
	select ci.ClassID, ci.ClassName, ci.CourseID, lc.LogonID 
	from #ClassInfo ci
	left outer join (select t.LogonID, uc.ClassID 
					 from hxgnyUserClass uc 
					 join #Teacher t on t.ID = uc.UserID ) lc
	on lc.ClassID = ci.ClassID

end;
GO
