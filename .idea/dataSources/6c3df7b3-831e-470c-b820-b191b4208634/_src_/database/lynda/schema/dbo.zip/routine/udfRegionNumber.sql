--
-- select dbo.[udfRegionNumber] (116.40,39.90, 1)
--
 CREATE function [dbo].[udfRegionNumber](@longtitude float, @latitude float, @areaID int)
  returns int
  as
  begin
	--determine RegionNumber for given AreaID by a point belongs to
	declare @totalCol int = (select ColumnNumber from Area where ID = @areaID), @totalRow int = (select RowNumber from Area where ID = @areaID);
	declare @regionNumber int, @Nne int;

	select @Nne = min(NodeNumber)
	from AreaNode an
	join Node2 n on n.ID = an.NodeID
	where n.latitude >  @latitude
	and n.longtitude > @longtitude
	and an.AreaID = @areaID;

	declare @rowNum int = 1 + @Nne/@totalCol;

	select @regionNumber = @Nne - @totalCol - @rowNum + 1 
	
	return @regionNumber;
  end;


GO
