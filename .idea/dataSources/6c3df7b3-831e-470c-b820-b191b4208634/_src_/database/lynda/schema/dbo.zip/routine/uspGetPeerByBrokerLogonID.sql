
--
-- execute uspGetPeerByBrokerLogonID N'<parameters><user><logonid>testBroker02-1</logonid><cap>-43</cap></user></parameters>'
--
CREATE procedure [dbo].[uspGetPeerByBrokerLogonID]
@xmlparm xml
as
begin
	declare @logonID nvarchar(200), @cap int;
	select 
	@logonID = tbl.d.value('logonid[1]', 'nvarchar(200)'),
	@cap = tbl.d.value('cap[1]', 'int')
	from @xmlparm.nodes('/parameters/user') AS tbl(d);

	select 
	ID, 
	LogonID, 
	ReferenceCode, 
	case when YearsOfBusiness < 0 then 'broker' else 'member' end as UserType, 
	case when YearsOfBusiness < 0 then YearsOfBusiness else 0 end as hLevel
	from [User]
	where YearsOfBusiness >= (select YearsOfBusiness from [User] where LogonID = @logonID) 
	and YearsOfBusiness <= @cap 
	and UserType = 'supplier'
	and YearsOfBusiness < 0
end;

GO
