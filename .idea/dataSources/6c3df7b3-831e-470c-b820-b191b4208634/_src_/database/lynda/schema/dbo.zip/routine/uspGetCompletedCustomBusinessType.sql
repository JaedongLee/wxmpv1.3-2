--
--execute uspGetCompletedCustomBusinessType N''
--
CREATE procedure uspGetCompletedCustomBusinessType
@xmlparm xml
as
begin
	select BusinessType.Name as Name from BusinessType
	where TypeOwnerID in (select ID from [User] where YearsOfBusiness <> 9999)
	and Type like 'C%'
	order by BusinessType.Name
end;
GO
