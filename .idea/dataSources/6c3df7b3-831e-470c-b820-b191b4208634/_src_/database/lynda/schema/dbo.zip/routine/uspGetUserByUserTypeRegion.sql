--
-- execute uspGetUserByUserTypeRegion N'<parameters><UserType>supplier</UserType><Region>shanghai</Region></parameters>'
--
CREATE procedure [dbo].[uspGetUserByUserTypeRegion]
@xmlparm xml
as
begin
	declare @UserType nvarchar(100), @Region nvarchar(100)

	select
    @UserType = tbl.users.value('UserType[1]', 'nvarchar(200)'),
    @Region = tbl.users.value('Region[1]', 'nvarchar(100)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	if ltrim(rtrim(@region))<>''
	begin
		select 
		distinct
		u.LogonID, 
		u.[Password],
		r.Name Region, 
		ISNULL(u.FirstName,'') as FirstName,
		ISNULL(u.[MiddleName],'') as MiddleName,
		ISNULL(u.LastName,'') as LastName,
		u.[Longtitude],
		u.[Latitude],
		ISNULL(u.Street,'') as Street,
		ISNULL(u.City,'') as City,
		ISNULL(u.[State],'') as [State],
		ISNULL(u.Country,'') as Country, 
		ISNULL(u.Zipcode,'') as Zipcode, 
		u.UserType,
		ISNULL(p.Phone,'') as Phone,
		ISNULL(p.Ext, '') as Ext,
		ISNULL(u.Email,'') as Email,
		ISNULL(u.WeChat,'') as WeChat
		from [User] u
		left join  UserRegion ur on u.ID = ur.UserID
		left join Region2 r on ur.RegionID = r.ID
		left join UserPhone up on up.UserID = u.ID
		left join Phone p on p.ID = up.PhoneID
		where u.UserType = @UserType and r.Name = @Region and (up.FirstPhone = 1 or up.PhoneID is null);
	end;
	else
	begin
		select 
		distinct
		u.LogonID, 
		u.[Password],
		r.Name Region, 
		ISNULL(u.FirstName,'') as FirstName,
		ISNULL(u.[MiddleName],'') as MiddleName,
		ISNULL(u.LastName,'') as LastName,
		u.[Longtitude],
		u.[Latitude],
		ISNULL(u.Street,'') as Street,
		ISNULL(u.City,'') as City,
		ISNULL(u.[State],'') as [State],
		ISNULL(u.Country,'') as Country, 
		ISNULL(u.Zipcode,'') as Zipcode, 
		u.UserType,
		ISNULL(p.Phone,'') as Phone,
		ISNULL(p.Ext, '') as Ext,
		ISNULL(u.Email,'') as Email,
		ISNULL(u.WeChat,'') as WeChat
		from [User] u
		left join  UserRegion ur on u.ID = ur.UserID
		left join Region2 r on ur.RegionID = r.ID
		left join UserPhone up on up.UserID = u.ID
		left join Phone p on p.ID = up.PhoneID
		where u.UserType = @UserType and (up.FirstPhone = 1 or up.PhoneID is null);
	end;
end;


GO
