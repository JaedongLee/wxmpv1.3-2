

--
-- uspAddUserGroup N'<parameters><GroupName>laugh_01</GroupName><UserLogon>charles.su</UserLogon><GroupDescription>No</GroupDescription></parameters>'
-- uspAddUserGroup N'<parameters><GroupName>laugh_02</GroupName><UserLogon>charles.su</UserLogon><GroupDescription>No</GroupDescription></parameters>'
--
CREATE procedure [dbo].[uspAddUserGroup]
@xmlparm xml
as
begin
	declare @UserID int, @GroupID int, @GroupOwnerID int, @UserLogon nvarchar(200), @GroupName nvarchar(100), @GroupOwner nvarchar(200), @GroupDescription nvarchar(300);
	
	select
	@GroupName = tbl.users.value('GroupName[1]', 'nvarchar(100)'),
	@UserLogon = tbl.users.value('UserLogon[1]', 'nvarchar(100)'),
	@GroupDescription = tbl.users.value('GroupDescription[1]', 'nvarchar(300)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	select @GroupOwnerID = ID from [User] where logonID = @GroupOwner;
	select @UserID = ID from [User] where logonID = @UserLogon;
	select @GroupID = ID from [Group] where Name = @GroupName;


	begin tran
		if @GroupID is null
		begin
			insert into [Group]
			(Name,Description, GroupOwnerID, Active)
			values
			(@GroupName, @GroupDescription, @GroupOwnerID, 'A'); 

			select @GroupID = ID from [Group] where Name = @GroupName;
		end; 
		
		insert into UserGroup
		(UserID, GroupID)
		values
		(@UserID, @GroupID);
	commit tran
end;
GO
