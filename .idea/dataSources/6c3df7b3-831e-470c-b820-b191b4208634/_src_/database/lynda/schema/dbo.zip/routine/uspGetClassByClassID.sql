
--
--exec uspGetClassByClassID N'<parameters><ClassID>123</ClassID></parameters>'
--

CREATE procedure [dbo].[uspGetClassByClassID]
@xmlparm xml
as
BEGIN
	declare @classID int;

	select
	@classID = tbl.users.value('ClassID[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users);


	select 
	max([Order]) - min([Order]) + 1 as TotalInQue, 
	ClassID
	into #ClassQue 
	from hxgnyUserClassQue
	where ClassID = @classID
	group by ClassID

	select u.LogonID, u.ID  
	into #teacher
	from UserRole ur
	join [Role] r on r.ID = ur.RoleID
	join [User] u on u.ID = ur.UserID
	where r.Name = 'hxgnyTeacher';
	  
	select 
	cl.ID as ClassID, 
	cl.Name as ClassName, 
	cl.Description, 
	Location as ClassLocation, 
	StartTime, 
	EndTime, 
	ClassSize, 
	RegisteredSize, 
	Grade, 
	CourseID,  
	cr.Name as CourseName, 
	cr.Type as CourseType, 
	cr.GradeSize,
	isnull(TotalInQue, 0) as TotalInQue,
	cr.Price,
	cr.MaterialPrice,
	lc.LogonID as TeacherLogonID
	from hxgnyClass cl
	join hxgnyCourse cr on cl.CourseID = cr.ID
	left outer join #ClassQue cq on cq.ClassID = cl.ID 
	left outer join (select t.LogonID, uc.ClassID 
					 from hxgnyUserClass uc 
					 join #Teacher t on t.ID = uc.UserID ) lc
	on lc.ClassID = cl.ID
	where cl.ID = @classID

END;
GO
