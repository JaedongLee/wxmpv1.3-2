--
-- [uspDeleteUserImmediate] N'<parameters><logonid>cli</logonid></parameters>'
--
create procedure [dbo].[uspDeleteUserImmediate]
@xmlparm xml
as
begin
	declare @logonID nvarchar(200);
	select @logonID = tbl.users.value('logonid[1]', 'nvarchar(200)') from @xmlparm.nodes('/parameters') AS tbl(users);

	begin tran
	insert into UserHistory
	select * from [User] where LogonID = @logonID;

	delete [User] where LogonID = @logonID;
	commit tran
end;


GO
