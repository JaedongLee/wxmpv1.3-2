

--
--exec uspDeleteUserClassByClassIDLogonID N'<parameters><ClassID>123</ClassID><LogonID>charles_cp</LogonID></parameters>'
--

CREATE procedure [dbo].[uspDeleteUserClassByClassIDLogonID]
@xmlparm xml
as
BEGIN
	declare @logonID nvarchar(200), @classID int;
	select 
	@logonID = tbl.users.value('LogonID[1]', 'nvarchar(200)'),
	@classID = tbl.users.value('ClassID[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	delete hxgnyUserClass 
	where UserID = (select ID from [User] where LogonID = @logonID)
	and ClassID = @classID;

	if exists (select 1 from [User] where LogonID = @logonID and ID not in (select UserID from UserRole ur join Role r on r.ID = ur.RoleID where r.Name = 'hxgnyTeacher'))
	begin
		update hxgnyClass
		set RegisteredSize = RegisteredSize - 1
		where ID = @classID;
	end;
END;

GO
