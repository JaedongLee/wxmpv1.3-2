--
-- execute uspGetSupplierByLocation '<parameters><region>28673</region><sw><lo>116.475</lo><la>39.7664</la></sw><se><lo>116.485</lo><la>39.7664</la></se><ne><lo>116.485</lo><la>39.7736</la></ne><nw><lo>116.475</lo><la>39.7736</la></nw></parameters>'
--
CREATE procedure [dbo].[uspGetSupplierByLocation]
@xmlparm xml
as
begin
	declare @regionNum int, @E float, @W float, @N float, @S float;
	select  @regionNum = @xmlparm.value('(/parameters/region)[1]','int'),
			@E = @xmlparm.value('(/parameters/ne/lo)[1]','float'), 
			@W = @xmlparm.value('(/parameters/sw/lo)[1]','float'),
			@N = @xmlparm.value('(/parameters/ne/la)[1]','float'),
			@S = @xmlparm.value('(/parameters/sw/la)[1]','float');

	declare @elementTable table(ElementNumber int, nodeNum int);

	declare @NE int = dbo.udfRegionElementByLocation(@E,@N).value('(/parameters/elementNumber)[1]','int');
	declare @SW int = dbo.udfRegionElementByLocation(@W,@S).value('(/parameters/elementNumber)[1]','int');

	print @NE
	print @SW
	select @W, @E, @S, @N

	declare @regionID int = (select ID from Region2 where RegionNumber = @regionNum);

	if (dbo.udfRegionElementByLocation(@E,@N).value('(/parameters/elementNumber)[1]','int') <> dbo.udfRegionElementByLocation(@W,@S).value('(/parameters/elementNumber)[1]','int'))
	begin
		declare @elementList table (element xml, nodeNumber int);

		declare @nodeNumber int;
		declare node_cursor CURSOR FOR (select rn.NodeNumber from RegionNode rn
										join Node1 n on n.ID = rn.NodeID
										join Region2 r on r.ID = rn.RegionID
										where r.RegionNumber = @regionNum 
										and n.latitude <= @N 
										and n.latitude >= @S
										and n.longtitude >= @W
										and n.longtitude <= @E)

		OPEN node_cursor
		FETCH NEXT FROM node_cursor INTO @nodeNumber
		WHILE @@FETCH_STATUS = 0
		BEGIN
			insert into @elementList (element, nodeNumber) values (dbo.[udfFourElementsPerNode] (@nodeNumber, @regionID), @nodeNumber);
			FETCH NEXT FROM node_cursor INTO @nodeNumber
		END;
		CLOSE node_cursor;
		DEALLOCATE node_cursor;

		--find elements
		declare @Esw int, @Ese int, @Ene int, @Enw int, @element xml, @nodeNum int;

		declare element_cursor CURSOR FOR select element, nodeNumber from @elementList
		OPEN element_cursor;
		FETCH NEXT FROM element_cursor INTO @element, @nodeNum;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			select 
			@Esw = @element.value('(/parameters/sw)[1]','int'),
			@Ese = @element.value('(/parameters/se)[1]','int'),
			@Ene = @element.value('(/parameters/ne)[1]','int'),
			@Enw = @element.value('(/parameters/nw)[1]','int');
	
			insert into @elementTable (ElementNumber, nodeNum)
			select @Esw, @nodeNum
			union
			select @Ese, @nodeNum
			union
			select @Ene, @nodeNum
			union
			select @Enw, @nodeNum

			FETCH NEXT FROM element_cursor INTO @element, @nodeNum;
		END;
		CLOSE element_cursor;
		DEALLOCATE element_cursor;

		if not exists (select 1 from @elementTable)
		begin
			insert into @elementTable (ElementNumber, nodeNum)
			select dbo.udfRegionElementByLocation(@E,@N).value('(/parameters/elementNumber)[1]','int'), dbo.udfRegionElementByLocation(@E,@N).value('(/parameters/regionID)[1]','int');
			insert into @elementTable (ElementNumber, nodeNum)
			select dbo.udfRegionElementByLocation(@W,@S).value('(/parameters/elementNumber)[1]','int'), dbo.udfRegionElementByLocation(@E,@N).value('(/parameters/regionID)[1]','int');
		end;
	end;
	else
	begin
		insert into @elementTable (ElementNumber, nodeNum)
		select dbo.udfRegionElementByLocation(@E,@N).value('(/parameters/elementNumber)[1]','int'), dbo.udfRegionElementByLocation(@E,@N).value('(/parameters/regionID)[1]','int');
	end;

	--find suppliers
	select distinct u.* from [User] u
	join UserRegionElement ure on u.ID = ure.UserID
	join RegionElement re on ure.RegionElementID = re.ID 
	join @elementTable e on e.ElementNumber = re.ElementNumber
	where re.RegionID = @regionID;

end;


GO
