


--
--exec uspDeleteRequestByLogonID N'<parameters><LogonID>charles_cp</LogonID></parameters>'
--

CREATE procedure [dbo].[uspDeleteRequestByLogonID]
@xmlparm xml
as
BEGIN
	declare @logonID nvarchar(200), @orderID nvarchar(200);
	select 
	@logonID = tbl.users.value('LogonID[1]', 'nvarchar(200)'),
	@orderID = tbl.users.value('OrderID[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	delete ebtRequest 
	where OwnerID = (select ID from [User] where LogonID = @logonID)
	and OrderID = @orderID;
END;


GO
