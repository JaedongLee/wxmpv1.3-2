
--
-- uspAddCustomBusinessType N'<parameters><businessType>zcli.BlueRay1245678901234567890</businessType><location>No</location><type>CG</type><owner>cli.su</owner><parentID>-1</parentID></parameters>'
--
CREATE procedure [dbo].[uspAddCustomBusinessType]
@xmlparm xml
as
begin
	declare @UserID int, @parentID int, @businessType nvarchar(200), @location nvarchar(10), @owner nvarchar(200), @type nvarchar(3), @filename nvarchar(50), @custombiztypedetail nvarchar(max), @templateID int;
	
	select
	@businessType = tbl.users.value('businessType[1]', 'nvarchar(200)'), 
	@location = tbl.users.value('location[1]', 'nvarchar(10)'),
	@type = tbl.users.value('type[1]', 'nvarchar(3)'),
	@owner = tbl.users.value('owner[1]', 'nvarchar(200)'),
	@filename = tbl.users.value('filename[1]', 'nvarchar(50)'),
	@custombiztypedetail = tbl.users.value('custombiztypedetail[1]', 'nvarchar(max)'),
	@templateID = tbl.users.value('templateID[1]', 'int'),
	@parentID = tbl.users.value('parentID[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	set @custombiztypedetail = Replace(Replace(@custombiztypedetail,'%26','&'),'and','&');
	select @UserID = ID from [User] where logonID = @owner;

	begin tran
		insert into BusinessType
		(Name, ParentID, Type, TypeOwnerID, Location, HtmlFileName, BusinessTypeDetail)
		values
		(@businessType, @parentID, @type, @UserID, @location, @filename, @custombiztypedetail); 

		insert into BusinessTypeTemplate
		(BusinessTypeID, TemplateID)
		select max(ID), @templateID from BusinessType;

		insert into UserBusinessType
		(UserID, BusinessTypeID, Active)
		values
		(@UserID, (select max(ID) from BusinessType), 'A'); 
	commit tran
end;

GO
