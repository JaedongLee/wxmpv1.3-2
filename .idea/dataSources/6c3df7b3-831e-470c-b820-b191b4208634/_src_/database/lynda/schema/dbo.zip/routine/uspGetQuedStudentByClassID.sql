

--
--exec uspGetQuedStudentByClassID N'<parameters><ClassID>123</ClassID></parameters>'
--

CREATE procedure [dbo].[uspGetQuedStudentByClassID]
@xmlparm xml
as
BEGIN
	declare @classID int;

	select
	@classID = tbl.users.value('ClassID[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	select u.LogonID, u.FirstName, u.LastName, u.MiddleName
	from hxgnyUserClassQue ucq
	join [User] u on ucq.UserID = u.ID
	where ucq.ClassID = @classID;
END;
GO
