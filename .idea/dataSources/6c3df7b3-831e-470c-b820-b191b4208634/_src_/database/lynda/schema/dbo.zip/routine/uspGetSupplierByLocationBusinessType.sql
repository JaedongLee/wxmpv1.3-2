--
-- execute uspGetSupplierByLocationBusinessType N'<parameters><region>28673</region><sw><lo>116.475</lo><la>39.7664</la></sw><se><lo>116.485</lo><la>39.7664</la></se><ne><lo>116.485</lo><la>39.7736</la></ne><nw><lo>116.475</lo><la>39.7736</la></nw><BusinessType>Fashion_Clothing_Shoes_Women</BusinessType></parameters>'
-- execute uspGetSupplierByLocationBusinessType N'<parameters><region>22563</region><sw><lo>121.474</lo><la>31.2304</la></sw><se><lo>121.474</lo><la>31.2304</la></se><ne><lo>121.474</lo><la>31.2304</la></ne><nw><lo>121.474</lo><la>31.2304</la></nw></parameters>'
-- execute uspGetSupplierByLocationBusinessType N'<parameters><region>28673</region><sw><lo /><la /></sw><se><lo /><la /></se><ne><lo /><la /></ne><nw><lo /><la /></nw></parameters>'
--
CREATE procedure [dbo].[uspGetSupplierByLocationBusinessType]
@xmlparm xml
as
begin
	declare @regionNum int, @E float, @W float, @N float, @S float, @BusinessType nvarchar(100);
	select  @regionNum = @xmlparm.value('(/parameters/region)[1]','int'),
			@E = @xmlparm.value('(/parameters/ne/lo)[1]','float'), 
			@W = @xmlparm.value('(/parameters/sw/lo)[1]','float'),
			@N = @xmlparm.value('(/parameters/ne/la)[1]','float'),
			@S = @xmlparm.value('(/parameters/sw/la)[1]','float'),
			@BusinessType = @xmlparm.value('(/parameters/BusinessType)[1]','nvarchar(100)');

	--select @W, @E, @S, @N

	if (@N<>'')
	begin
		declare @nodeNum int, @regionID int, @NodesPerRow int, @NodesPerColumn int;
		select @regionID = ID, @NodesPerRow = ColumnNumber, @NodesPerColumn = RowNumber from Region2 where RegionNumber = @regionNum;

		declare @NodeList table (NodeNumber int)
		insert into @NodeList
		select rn.NodeNumber 
		from RegionNode rn
		join Node1 n on n.ID = rn.NodeID
		where n.latitude <= @N   
		and n.latitude >= @S
		and n.longtitude <= @E
		and n.longtitude >= @W
		and rn.RegionID = @regionID

		--select * from @NodeList

		declare @j int = 1;
		declare @elementNumList table (elementNumber int);
		declare node_cursor CURSOR FOR select NodeNumber from @NodeList
		OPEN node_cursor;
		FETCH NEXT FROM node_cursor INTO @nodeNum;
		WHILE @@FETCH_STATUS = 0
		BEGIN

		--SW corner
		if(@nodeNum = 1)
		begin
			print 'SW corner';
			insert into @elementNumList select @nodeNum;
		end;
		--SE corner
		else if (@nodeNum = @NodesPerRow)
		begin
			print 'SE corner';
			insert into @elementNumList select @nodeNum - 1;
		end;
		--NE corner
		else if (@nodeNum = @NodesPerRow * @NodesPerColumn)
		begin
			print 'NE corner';
			insert into @elementNumList select @nodeNum - @NodesPerRow - (@nodeNum - 1)/@NodesPerColumn;
		end;
		--NW corner
		else if (@nodeNum = @NodesPerRow * (@NodesPerColumn -1) + 1)
		begin
			print 'NW corner';
			insert into @elementNumList select @nodeNum + 1 - @NodesPerRow - @nodeNum/@NodesPerColumn;
		end;
		--E border
		else if (@nodeNum = @NodesPerRow * @j and @j > 1)
		begin
			print 'E border';
			insert into @elementNumList 
			select @nodeNum - @NodesPerRow - (@nodeNum - 1)/@NodesPerColumn
			union
			select @nodeNum - (@nodeNum - 1)/@NodesPerColumn - 1;
		end;
		--W border
		else if (@nodeNum = @NodesPerRow * @j + 1)
		begin
			print 'W border';
			insert into @elementNumList 
			select @nodeNum + 1 - @NodesPerRow - @nodeNum/@NodesPerColumn
			union
			select @nodeNum + 1 - @nodeNum/@NodesPerColumn - 1 ; 
		end;
		--S border
		else if (@nodeNum > 1 and @nodeNum < @NodesPerRow)
		begin
			print 'S border'
			insert into @elementNumList 
			select @nodeNum
			union
			select @nodeNum - 1;
		end;
		--N border
		else if (@nodeNum > @NodesPerRow * (@NodesPerColumn -1) + 1 and @nodeNum < @NodesPerRow * @NodesPerColumn)
		begin
			print 'N border'
			insert into @elementNumList 
			select @nodeNum - @NodesPerRow - (@nodeNum - 1)/@NodesPerColumn
			union
			select @nodeNum - @NodesPerRow - (@nodeNum - 1)/@NodesPerColumn + 1;
		end;
		--inner area
		else
		begin
			print 'inner area'
			insert into @elementNumList 
			select @nodeNum - @NodesPerRow - (@nodeNum - 1)/@NodesPerColumn
			union
			select @nodeNum - @NodesPerRow - (@nodeNum - 1)/@NodesPerColumn + 1
			union
			select @nodeNum - (@nodeNum - 1)/@NodesPerColumn - 1
			union
			select @nodeNum - (@nodeNum - 1)/@NodesPerColumn;
		end;
		set @j = @j + 1;	
		FETCH NEXT FROM node_cursor INTO @nodeNum;
		END;
		CLOSE node_cursor;
		DEALLOCATE node_cursor;

		--select distinct elementNumber from @elementNumList;

		--find suppliers
		select distinct u.*, r.Name into #supplier
		from [User] u
		join UserRegionElement ure on u.ID = ure.UserID
		join RegionElement re on ure.RegionElementID = re.ID 
		join @elementNumList e on e.ElementNumber = re.ElementNumber
		join Region2 r on r.ID = re.RegionID 
		where re.RegionID = @regionID;

		select u.LogonID as SupplierID, u.Latitude, u.Longtitude, c.Credit, u.Name as Region
		from #supplier u
		join UserBusinessType ubt on ubt.UserID = u.ID
		join BusinessType bt on bt.ID = ubt.BusinessTypeID
		left join UserCredit uc on uc.UserID = u.ID
		left join Credit c on c.ID = uc.CreditID
		where bt.Name = @BusinessType
		union
		select u.LogonID as SupplierID, u.Latitude, u.Longtitude, c.Credit, u.Name as Region
		from #supplier u
		join UserBusinessType ubt on ubt.UserID = u.ID
		join BusinessType bt on bt.ParentID = ubt.BusinessTypeID
		left join UserCredit uc on uc.UserID = u.ID
		left join Credit c on c.ID = uc.CreditID
		where bt.Name = @BusinessType;
	end;
	else
	begin

		--Special workaround for JDBC
		declare @NodeList1 table (NodeNumber int);
		insert into @NodeList1 select 1;
		--End of special workaround

		--only if within the region
		select u.LogonID as SupplierID, u.Latitude, u.Longtitude, c.Credit, r.Name as Region
		from [User] u
		join UserRegionElement ure on u.ID = ure.UserID
		join RegionElement re on ure.RegionElementID = re.ID 
		join Region2 r on r.ID = re.RegionID 
		join UserBusinessType ubt on ubt.UserID = u.ID
		join BusinessType bt on bt.ID = ubt.BusinessTypeID
		left join UserCredit uc on uc.UserID = u.ID
		left join Credit c on c.ID = uc.CreditID
		where bt.Name = @BusinessType and r.RegionNumber = @regionNum
		union
		select u.LogonID as SupplierID, u.Latitude, u.Longtitude, c.Credit, r.Name as Region
		from [User] u
		join UserRegionElement ure on u.ID = ure.UserID
		join RegionElement re on ure.RegionElementID = re.ID 
		join Region2 r on r.ID = re.RegionID 
		join UserBusinessType ubt on ubt.UserID = u.ID
		join BusinessType bt on bt.ParentID = ubt.BusinessTypeID
		left join UserCredit uc on uc.UserID = u.ID
		left join Credit c on c.ID = uc.CreditID
		where bt.Name = @BusinessType and r.RegionNumber = @regionNum;

	end;
end;


GO
