--
-- execute getSupplierByLocation '<parameters><long>121.949</long><lat>31.50</lat><distance>100</distance><businesstype>Clothing</businesstype></parameters>'
-- execute getSupplierByLocation '<parameters><long></long><lat></lat><distance>100</distance><businesstype>Clothing</businesstype></parameters>'
--

CREATE procedure [dbo].[getSupplierByLocation]
@xmlparm xml
as
begin
	declare @long float, @lat float, @distance float, @BusinessType varchar(100);
	select 
	@long = tbl.loc.value('long[1]', 'float'),
	@lat = tbl.loc.value('lat[1]', 'float'),
	@distance = tbl.loc.value('distance[1]', 'float'),
	@BusinessType = tbl.loc.value('businesstype[1]', 'varchar(100)')
	from @xmlparm.nodes('/parameters') as tbl(loc);

	if (@long ='' or @lat = '')
		select a.LogonID as SupplierID, a.Latitude, a.Longtitude, e.Credit, g.Name as Region
		from [User] a
		join UserBusinessType b on a.ID = b.UserID
		join BusinessType c on c.ID = b.BusinessTypeID
		left join UserCredit d on d.UserID = a.ID
		left join Credit e on e.ID = d.CreditID
		left join UserRegion f on f.UserID = a.ID
		left join Region2 g on g.ID = f.RegionID
		where a.UserType = 'supplier' 
		and c.Name = @BusinessType;
	else
		select a.LogonID as SupplierID, a.Latitude, a.Longtitude, e.Credit, g.Name as Region 
		from [User] a
		join UserBusinessType b on a.ID = b.UserID
		join BusinessType c on c.ID = b.BusinessTypeID
		left join UserCredit d on d.UserID = a.ID
		left join Credit e on e.ID = d.CreditID
		left join UserRegion f on f.UserID = a.ID
		left join Region2 g on g.ID = f.RegionID
		where a.UserType = 'supplier' and dbo.distance(a.Longtitude, a.Latitude, @long, @lat) <= @distance
		and c.Name = @BusinessType;
end;

GO
