
--
--exec uspGetCourseByCourseID N'<parameters><CourseID>123</CourseID></parameters>'
--

CREATE procedure [dbo].[uspGetCourseByCourseID]
@xmlparm xml
as
BEGIN
	declare @courseID int;

	select
	@courseID = tbl.users.value('CourseID[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	select ID CourseID, Name CourseName, Description, Type CourseType, OwnerID, Price, URL, GradeSize, MaterialPrice 
	from hxgnyCourse
	where ID = @courseID;
END;
GO
