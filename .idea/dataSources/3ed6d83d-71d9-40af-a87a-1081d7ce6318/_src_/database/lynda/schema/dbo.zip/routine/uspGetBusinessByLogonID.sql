--
-- execute uspGetBusinessByLogonID N'<parameters><logonID>cli</logonID></parameters>'
--
CREATE procedure [dbo].[uspGetBusinessByLogonID]
@xmlparm xml
as
begin
	select bt.Name BusinessType
	from BusinessType bt
	join UserBusinessType ubt on ubt.BusinessTypeID = bt.ID
	join [User] u on u.ID = ubt.UserID 
	where u.LogonID = @xmlparm.value('(/parameters/logonID)[1]', 'nvarchar(100)' )
	order by bt.Name;
end;


GO
