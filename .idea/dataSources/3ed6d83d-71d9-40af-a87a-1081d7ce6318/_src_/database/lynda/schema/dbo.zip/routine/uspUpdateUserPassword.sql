--
-- execute uspUpdateUserPassword N'<parameters><logonid>cli</logonid><password>clii</password></parameters>'
--
CREATE procedure [dbo].[uspUpdateUserPassword]
@xmlparm xml
as
begin
	declare @LogonID nvarchar(200), @Password nvarchar(100);

	select
    @LogonID = tbl.users.value('logonid[1]', 'nvarchar(200)'),
    @Password = tbl.users.value('password[1]', 'nvarchar(100)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	begin tran

	begin try
		--update user password
		update [User]
		set Password = @Password 
		where LogonID = @LogonID;
	end try
	begin catch
		declare @ErrorNumber int, @ErrorSeverity int, @ErrorState int, @ErrorProcedure nvarchar(100), @ErrorLine int, @ErrorMessage varchar(500);
		if @@TRANCOUNT > 0 rollback tran;
			SELECT @ErrorNumber = ERROR_NUMBER()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE()
			,@ErrorProcedure = ERROR_PROCEDURE()
			,@ErrorLine = ERROR_LINE()
			,@ErrorMessage = ERROR_MESSAGE();
		throw 500000, @ErrorMessage, @ErrorState;
	end catch;
	if @@TRANCOUNT > 0 commit tran;
end;


GO
