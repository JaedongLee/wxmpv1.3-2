
--
--exec uspDeleteSelectedClassByClassIDLogonID N'<parameters><ClassID>123</ClassID><LogonID>charles_cp</LogonID></parameters>'
--

CREATE procedure [dbo].[uspDeleteSelectedClassByClassIDLogonID]
@xmlparm xml
as
BEGIN
	declare @logonID nvarchar(200), @classID int;
	select 
	@logonID = tbl.users.value('LogonID[1]', 'nvarchar(200)'),
	@classID = tbl.users.value('ClassID[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	delete hxgnyUserSelectedClass 
	where UserID = (select ID from [User] where LogonID = @logonID)
	and ClassID = @classID;
END;
GO
