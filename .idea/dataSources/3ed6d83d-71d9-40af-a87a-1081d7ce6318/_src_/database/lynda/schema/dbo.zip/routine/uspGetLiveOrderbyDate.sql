--
-- execute uspGetLiveOrderbyDate '<parameters><asofdate>02/17/2015</asofdate></parameters>'
--
CREATE procedure [dbo].[uspGetLiveOrderbyDate]
@xmlparm xml
as
begin
	declare @asofdate varchar(10);
	select
    @asofdate = tbl.d.value('.', 'varchar(30)')
	from @xmlparm.nodes('/parameters/asofdate') AS tbl(d);
	
	select Content as LiveOrder from LiveOrder 
	--where ModificationTime > cast(@asofdate as datetime) 
	--and ModificationTime < dateadd(dd, 1, cast(@asofdate as datetime));
end;


GO
