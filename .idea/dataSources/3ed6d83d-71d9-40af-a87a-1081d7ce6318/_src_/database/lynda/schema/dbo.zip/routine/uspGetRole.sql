
CREATE procedure [dbo].[uspGetRole]
@appName nvarchar(50)
as
begin
	select Name as [RoleName]
	from [Role] 
	order by Name;
end;


GO
