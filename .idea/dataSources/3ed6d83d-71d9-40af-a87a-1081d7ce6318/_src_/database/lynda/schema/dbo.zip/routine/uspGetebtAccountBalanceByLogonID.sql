

--
-- execute uspGetebtAccountBalanceByLogonID N'<parameters><logonID>emember001</logonID></parameters>'
-- execute uspGetebtAccountBalanceByLogonID N'<parameters><logonID>ebo001@</logonID></parameters>'
--
CREATE procedure [dbo].[uspGetebtAccountBalanceByLogonID]
@xmlparm xml
as
begin
	declare @uid int
    select @uid = ID from [User] where LogonID = @xmlparm.value('(/parameters/logonID)[1]', 'nvarchar(100)' )

	declare @bal numeric(12,3)
	select @bal  = a.Balance
	from ebtAccount a
	join [User] u on u.ID = a.OwnerID 
	where a.Type = 'Member' and u.LogonID = @xmlparm.value('(/parameters/logonID)[1]', 'nvarchar(100)' )

	if @bal is null
	begin
		insert into ebtAccount (Name, Description, Type, OwnerID, Balance)
		select @xmlparm.value('(/parameters/logonID)[1]', 'nvarchar(100)' ),'Member Account','Member',@uid, 0.0

		insert into ebtAccount (Name, Description, Type, OwnerID, Balance)
		select @xmlparm.value('(/parameters/logonID)[1]', 'nvarchar(100)' ) + 'P','Member PayPal Account','MemberP',@uid, 0.0

		select 0 as Balance
	end
	else
	select @bal as Balance

end;

GO
