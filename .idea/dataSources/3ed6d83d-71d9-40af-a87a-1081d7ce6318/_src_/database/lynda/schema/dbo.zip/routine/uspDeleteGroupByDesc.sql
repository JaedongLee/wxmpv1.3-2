--
--exec uspDeleteGroupByDesc N'<parameters><Desc>charles_cp</Desc></parameters>'
--

create procedure uspDeleteGroupByDesc
@xmlparm xml
as
begin

	declare @desc nvarchar(200);
	
	select 
	@desc = tbl.users.value('Desc[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	delete [Group] where Description = @desc
end
GO
