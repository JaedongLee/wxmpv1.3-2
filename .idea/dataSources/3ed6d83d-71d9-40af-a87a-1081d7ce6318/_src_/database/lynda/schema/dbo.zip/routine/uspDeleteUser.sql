--
-- uspDeleteUser N'<parameters><logonid>cli</logonid></parameters>'
--
CREATE procedure [dbo].[uspDeleteUser]
@xmlparm xml
as
begin
	begin tran
		insert into UserHistory
		select u.* from [User] u
		join [UserDeleted] ud on ud.UserID = u.ID
		and DATEDIFF(dd, ud.CreationTimeStamp, getdate()) > 7;

		delete [User]  
		from [UserDeleted] ud
		where ud.UserID = [User].ID
		and DATEDIFF(dd, ud.CreationTimeStamp, getdate()) > 7;

		delete [UserDeleted]
		where DATEDIFF(dd, CreationTimeStamp, getdate()) > 7;
	commit tran

end;


GO
