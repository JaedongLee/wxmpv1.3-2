--
-- execute uspUpdateUserBusinessType N'<parameters><logonid>testpolluser</logonid><businessType>Appliance_Grocery</businessType><businessType>Baby_Kid_Stuff</businessType><poll>1</poll></parameters>'
-- execute uspUpdateUserBusinessType N'<parameters><logonid>A01001</logonid><businessType>Appliance_Grocery</businessType><businessType>Baby_Kid_Stuff</businessType><poll>1</poll><StoreName>高雄 - 杏福巷子1</StoreName><StoreDesc>Y杏福巷子寫 下了 一個不算長不算短十年紀錄歷史，憑著一步一腳印在巷子裡賣著純手工、不添加香精、香料、防腐劑的杏仁茶。一開始介紹杏仁給每一位顧客，顧客抱著懷疑的眼 神，直到現在經過了一次又一次的食安風暴，顧客不用我介紹就很清楚知道了純的風味。 杏福巷子感謝大家的支持！！ 我們將會更努力服務大家。</StoreDesc></parameters>'
--
CREATE procedure [dbo].[uspUpdateUserBusinessType]
@xmlparm xml
as
begin
	declare @LogonID nvarchar(200), @poll int, @storeName nvarchar(200), @storeDesc nvarchar(max);
	declare @businessTypeList table (businessType nvarchar(100));

	select
    @LogonID = tbl.users.value('logonid[1]', 'nvarchar(200)'),
    @storeName = tbl.users.value('StoreName[1]', 'nvarchar(200)'),
    @storeDesc = tbl.users.value('StoreDesc[1]', 'nvarchar(max)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	insert into @businessTypeList
	select tbl.users.value('.', 'nvarchar(100)') from @xmlparm.nodes('/parameters/businessType') AS tbl(users);
	--select * from @businessTypeList

	declare @loc int, @BusinessTypeDetail nvarchar(max);

	select @BusinessTypeDetail = BusinessTypeDetail from BusinessType where TypeOwnerID = 1163
	set @BusinessTypeDetail = SubString(@BusinessTypeDetail, CHARINDEX('|', @BusinessTypeDetail) + 1, Len(@BusinessTypeDetail));
	set @BusinessTypeDetail = SubString(@BusinessTypeDetail, CHARINDEX('|', @BusinessTypeDetail) + 1, Len(@BusinessTypeDetail));

	begin tran

	begin try
		declare @userID int = (select ID from [User] where LogonID = @LogonID);

		--update user business type info
		delete UserBusinessType where UserID = @userID;

		insert UserBusinessType (UserID, BusinessTypeID, Active) 
		select distinct @userID, ID, 'A' 
		from BusinessType bt
		join @businessTypeList btl on btl.businessType = bt.Name;

		select @poll = tbl.users.value('poll[1]', 'int') from @xmlparm.nodes('/parameters') AS tbl(users);
		if(1 = @poll)
		begin
			if (not exists (select 1 from UserPoll where UserID = @userID))
			insert into UserPoll 
			(UserID) 
			select @userID;
		end;
		else
		begin
			delete UserPoll where UserID = @userID;
		end;

		--Update custom business type detail info
		update BusinessType
		set BusinessTypeDetail = @storeName + '|' +  @storeDesc  + '|' + @BusinessTypeDetail
		where TypeOwnerID = @userID;

		--Update [User] time stamp
		update [User]
		set ModificationTime = GETDATE()
		where ID = @userID;

	end try
	begin catch
		declare @ErrorNumber int, @ErrorSeverity int, @ErrorState int, @ErrorProcedure nvarchar(100), @ErrorLine int, @ErrorMessage varchar(500);
		if @@TRANCOUNT > 0 rollback tran;
			SELECT @ErrorNumber = ERROR_NUMBER()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE()
			,@ErrorProcedure = ERROR_PROCEDURE()
			,@ErrorLine = ERROR_LINE()
			,@ErrorMessage = ERROR_MESSAGE();
		throw 500000, @ErrorMessage, @ErrorState;
	end catch;
	if @@TRANCOUNT > 0 commit tran;
end;


GO
