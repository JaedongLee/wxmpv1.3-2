


--
--exec uspGetRegisteredStudentByClassID N'<parameters><ClassID>36</ClassID></parameters>'
--

CREATE procedure [dbo].[uspGetRegisteredStudentByClassID]
@xmlparm xml
as
BEGIN
	declare @classID int;

	select
	@classID = tbl.users.value('ClassID[1]', 'int')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	select  u.LogonID, u.FirstName, u.LastName, u.MiddleName
	from hxgnyUserClass uc
	join [User] u on uc.UserID = u.ID
	join [UserRole] ur on ur.UserID = u.ID
	where ClassID = @classID
	and RoleID not in (select ID from [Role] where Name = 'hxgnyTeacher');
END;


GO
