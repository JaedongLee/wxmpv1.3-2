--
-- execute uspGetCustomBusinessTypeByLogonID N'<parameters><logonID>cli.su</logonID></parameters>'
--
CREATE procedure [dbo].[uspGetCustomBusinessTypeByLogonID]
@xmlparm xml
as
begin
	--select bt.Name as BusinessType, bt.Location, bt.Type, bt.HtmlFileName
	--from [BusinessType] bt
	--join [User] u on u.ID = bt.TypeOwnerID
	--where bt.Type like 'C%'
	--and bt.ID in (select BusinessTypeID from BusinessTypeTemplate) -- constraint with template
	--and u.LogonID = @xmlparm.value('(/parameters/logonID)[1]', 'nvarchar(100)' ) 
	--or bt.Type='SYS'
	--order by bt.Name;

	select bt.Name as BusinessType, bt.Location, bt.Type, bt.HtmlFileName, btt.TemplateID 
	from [BusinessType] bt
	join [User] u on u.ID = bt.TypeOwnerID
	join BusinessTypeTemplate btt on btt.BusinessTypeID = bt.ID
	where bt.Type like 'C%'
	and u.LogonID = @xmlparm.value('(/parameters/logonID)[1]', 'nvarchar(100)' ) 
	or bt.Type='SYS'
	order by bt.Name;

end;

GO
