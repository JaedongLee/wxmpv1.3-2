


--
--exec uspGetClassAll ''
--

CREATE procedure [dbo].[uspGetClassAll]
@appName nvarchar(200)
as
BEGIN
	select 
	max([Order]) - min([Order]) + 1 as TotalInQue, 
	ClassID
	into #ClassQue 
	from hxgnyUserClassQue
	group by ClassID

	select u.LogonID, u.ID  
	into #teacher
	from UserRole ur
	join [Role] r on r.ID = ur.RoleID
	join [User] u on u.ID = ur.UserID
	where r.Name = 'hxgnyTeacher';
	  
	select 
	cl.ID as ClassID, 
	cl.Name as ClassName, 
	cl.Description, 
	Location as ClassLocation, 
	StartTime, 
	EndTime, 
	ClassSize, 
	RegisteredSize, 
	Grade, 
	CourseID,  
	cr.Name as CourseName, 
	cr.Type 
	CourseType, 
	cr.GradeSize,
	isnull(TotalInQue, 0) as TotalInQue,
	cr.Price,
	cr.MaterialPrice,
	lc.LogonID as TeacherLogonID,
	cr.URL,
	cr.Description as CourseDescription
	from hxgnyClass cl
	join hxgnyCourse cr on cl.CourseID = cr.ID
	left outer join #ClassQue cq on cq.ClassID = cl.ID 
	left outer join (select t.LogonID, uc.ClassID 
					 from hxgnyUserClass uc 
					 join #Teacher t on t.ID = uc.UserID ) lc
	on lc.ClassID = cl.ID
END;
GO
