--
-- execute uspGetUserID N'<parameters><user><logonid>charles.nanjing</logonid><uid></uid></user></parameters>'
-- execute uspGetUserID N'<parameters><user><logonid></logonid><uid>24955</uid></user></parameters>'
--
CREATE procedure [dbo].[uspGetUserID]
@xmlparm xml
as
begin
	declare @LogonID nvarchar(200), @UID nvarchar(100)

	select
    @LogonID = tbl.users.value('logonid[1]', 'nvarchar(200)'),
    @UID = tbl.users.value('uid[1]', 'nvarchar(100)')
	from @xmlparm.nodes('/parameters/user') AS tbl(users);

	select
	ID as UID,
	LogonID 
	from [User] u
	where LogonID = @LogonID or ID = @UID;
end;

GO
