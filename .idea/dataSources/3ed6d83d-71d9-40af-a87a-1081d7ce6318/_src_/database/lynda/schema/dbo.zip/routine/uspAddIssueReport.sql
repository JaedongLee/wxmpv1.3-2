
--
-- uspAddIssueReport N"<parameters><reporter>cli</reporter><category>bug</category><description>severe bug</description></parameters>";
--
CREATE procedure [dbo].[uspAddIssueReport]
@xmlparm xml
as
begin
	declare @reporter nvarchar(200), @category nvarchar(200), @description nvarchar(1000), @reportedacct nvarchar(200);
	
	select
	@reporter = tbl.users.value('reporter[1]', 'nvarchar(200)'), 
	@category = tbl.users.value('category[1]', 'nvarchar(10)'),
	@description = tbl.users.value('description[1]', 'nvarchar(1000)'),
	@reportedacct = tbl.users.value('reportedAcct[1]', 'nvarchar(200)')

	from @xmlparm.nodes('/parameters') AS tbl(users)

	insert into UserIssueReport
	(UserID, Category, Description, TargetUserID)
	values
	((select ID from [User] where logonID = @reporter), @category, @description, (select ID from [User] where logonID = @reportedacct));
end;


GO
