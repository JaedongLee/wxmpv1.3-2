
--
-- uspAddUserRating N'<parameters><ratingAcct>cli</ratingAcct><rate>6</rate><ratedAcct>zous</ratedAcct><comment>Best service ever</comment></parameters>'
--
CREATE procedure [dbo].[uspAddUserRating]
@xmlparm xml
as
begin
	declare @ratingAcct nvarchar(200), @rate int, @ratedAcct nvarchar(200), @comment nvarchar(1000);
	
	select
	@ratingAcct = tbl.users.value('ratingAcct[1]', 'nvarchar(200)'), 
	@rate = tbl.users.value('rate[1]', 'int'),
	@ratedAcct = tbl.users.value('ratedAcct[1]', 'nvarchar(200)'),
	@comment = tbl.users.value('comment[1]', 'nvarchar(1000)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	insert into UserRating
	(UserID, RatedUserID, Rate, Comments)
	values
	((select ID from [User] where logonID = @ratingAcct), (select ID from [User] where logonID = @ratedAcct),@rate,	@comment);
end;


GO
