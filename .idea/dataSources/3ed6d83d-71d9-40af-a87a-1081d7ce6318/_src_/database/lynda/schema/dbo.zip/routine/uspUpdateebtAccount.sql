--
-- uspUpdateebtAccount N'<parameters><fromaccountid></fromaccountid><toaccountid>10</toaccountid><amount>150000.123</amount></parameters>'
--
CREATE procedure [dbo].[uspUpdateebtAccount]
@xmlparm xml
as
begin
	declare @fromaccountid int, @toaccountid int, @amount numeric(12,3), @deduct varchar(2), @increase varchar(2);
	
	select
	@fromaccountid = tbl.users.value('fromaccountID[1]', 'int'), 
	@toaccountid = tbl.users.value('toaccountID[1]', 'int'), 
	@deduct = tbl.users.value('deduct[1]', 'varchar(2)'), 
	@increase = tbl.users.value('increase[1]', 'varchar(2)'), 
	@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	if @deduct = 'no'
	begin
		print 'no deduct';
	end;
	else
	begin
		update ebtAccount
		set Balance = Balance - @amount
		where ID = @fromaccountid
	end;

	if @increase = 'no'
	begin
		print 'no increase'
	end;
	else
	begin
		update ebtAccount
		set Balance = Balance + @amount
		where ID = @toaccountid
	end;
end;


GO
