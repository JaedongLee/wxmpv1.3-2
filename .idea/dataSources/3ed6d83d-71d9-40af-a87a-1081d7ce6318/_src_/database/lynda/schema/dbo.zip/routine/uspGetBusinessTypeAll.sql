CREATE procedure [dbo].[uspGetBusinessTypeAll]
as
begin
	select Name as BusinessType, ParentID as ID 
	from [BusinessType] 
	order by Name;
end;


GO
