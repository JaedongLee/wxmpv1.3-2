--
-- execute uspGetUserAll
--
CREATE procedure [dbo].[uspGetUserAll]
as
begin
	select distinct u.UserType, r.Name as Region, u.LogonID
	from [User] u
	left join  UserRegion ur on u.ID = ur.UserID
	left join Region2 r on ur.RegionID = r.ID
	order by UserType, Region, LogonID
end;


GO
