--
-- select dbo.udfUserRating('zous')
--
 CREATE function [dbo].[udfUserRating](@logonID nvarchar(200))
  returns int
  as
  begin
	--determine region by region map and input location
	declare @rating int;
	
	select @rating = avg(cast(Rate as int)) 
	from UserRating ur
	join [User] u on u.ID = ur.RatedUserID
	where u.LogonID = @logonID;

	return @rating;
  end;


GO
