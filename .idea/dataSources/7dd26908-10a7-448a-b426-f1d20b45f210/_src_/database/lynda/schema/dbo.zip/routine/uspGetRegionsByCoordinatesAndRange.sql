--
-- execute uspGetRegionsByCoordinatesAndRange '<parameters><longtitude>121.473701</longtitude><latitude>31.230416</latitude><range>50000</range></parameters>'
-- execute uspGetRegionsByCoordinatesAndRange '<parameters><longtitude>121.473701</longtitude><latitude>31.230416</latitude><range>5</range></parameters>'
-- execute uspGetRegionsByCoordinatesAndRange '<parameters><longtitude>-73.614534</longtitude><latitude>41.262325</latitude><range>30000</range></parameters>'
--
CREATE procedure [dbo].[uspGetRegionsByCoordinatesAndRange]
@xmlparm xml
as
begin
	declare @areaID int, @long float, @lat float, @range float;

	select 
	@long = tbl.d.value('longtitude[1]', 'float'),
	@lat = tbl.d.value('latitude[1]', 'float'),
	@range = tbl.d.value('range[1]', 'float')
	from @xmlparm.nodes('/parameters') AS tbl(d);

	declare @fourCorners xml = dbo.[udfFourCorners] (@long, @lat, @range);
	declare @E float, @W float, @N float, @S float;
	select  @E = @fourCorners.value('(/parameters/ne/lo)[1]','float'), 
			@W = @fourCorners.value('(/parameters/sw/lo)[1]','float'),
			@N = @fourCorners.value('(/parameters/ne/la)[1]','float'),
			@S = @fourCorners.value('(/parameters/sw/la)[1]','float');

	if @long >= 0 and @lat >= 0 
		set @areaID = 1;
	else if @long < 0 and @lat > 0
		set @areaID = 2;
	else if @long > 0 and @lat < 0
		set @areaID = 3;
	else
		set @areaID = 4;

	--find regions for given location and radius
	declare @columnNumber int, @rowNumber int;
	select @columnNumber = ColumnNumber,  @rowNumber = RowNumber from Area where ID = @areaID;

	declare @nodeNumber int;
	declare @nodeList table(nodeNumber int);
	declare @regionList table (region xml, nodeNumber int);

	insert into @nodeList
	select an.NodeNumber 
	from AreaNode an
	join Node2 n on n.ID = an.NodeID
	where an.AreaID = @areaID
	and n.latitude <= @N and n.latitude >= @S
	and n.longtitude > = @W and n.longtitude <= @E;

	IF OBJECT_ID('tempdb..#regionPoints') IS NOT NULL DROP TABLE #regionPoints;
	create table #regionPoints (regionNum int, points xml);

	if exists (select 1 from @nodeList)
	begin
		declare node_cursor CURSOR FOR select nodeNumber from @nodeList

		OPEN node_cursor
		FETCH NEXT FROM node_cursor INTO @nodeNumber
		WHILE @@FETCH_STATUS = 0
		BEGIN
			insert into @regionList (region, nodeNumber) values (dbo.[udfFourRegionsPerNode] (@nodeNumber, @areaID), @nodeNumber);
			FETCH NEXT FROM node_cursor INTO @nodeNumber
		END;
		CLOSE node_cursor;
		DEALLOCATE node_cursor;

		declare @Rsw int, @Rse int, @Rne int, @Rnw int, @region xml, @nodeNum int;
		declare @regionTable table(region int, nodeNum int);

		declare region_cursor CURSOR FOR select region, nodeNumber from @regionList
		OPEN region_cursor;
		FETCH NEXT FROM region_cursor INTO @region, @nodeNum;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			select 
			@Rsw = @region.value('(/parameters/sw)[1]','int'),
			@Rse = @region.value('(/parameters/se)[1]','int'),
			@Rne = @region.value('(/parameters/ne)[1]','int'),
			@Rnw = @region.value('(/parameters/nw)[1]','int');
	
			insert into @regionTable (region, nodeNum)
			select @Rsw, @nodeNum
			union
			select @Rse, @nodeNum
			union
			select @Rne, @nodeNum
			union
			select @Rnw, @nodeNum

			FETCH NEXT FROM region_cursor INTO @region, @nodeNum;
		END;
		CLOSE region_cursor;
		DEALLOCATE region_cursor;

		declare @regionAndPoints varchar(2000);
		declare @neNodeNum int, @RneLo float, @RneLa float;
		declare @nwNodeNum int, @RnwLo float, @RnwLa float;
		declare @seNodeNum int, @RseLo float, @RseLa float;
		declare @swNodeNum int, @RswLo float, @RswLa float;

		declare @nodeCount int, @R int, @isCorner int = 1;
		declare nodeCount_cursor CURSOR FOR 
		select count(nodeNum) nodeCount, region 
		from @regionTable
		group by Region
		order by Region;

		OPEN nodeCount_cursor;
		FETCH NEXT FROM nodeCount_cursor INTO @nodeCount, @R;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			if (@nodeCount = 1 and @isCorner = 1) 
			begin
				--sw corner
				--Psw = Asw
				select @regionAndPoints = '<parameters><region>'+cast(@R as varchar)+'</region><sw><lo>'+cast(@W as varchar)+'</lo><la>'+cast(@S as varchar)+'</la></sw>';
				--Pne = Rne
				select @neNodeNum = @R + (@R - 1)/(@columnNumber - 1) + @columnNumber + 1;

				select @RneLo = n.longtitude, @RneLa = n.latitude
				from AreaNode an
				join Node2 n on n.ID = an.NodeID
				where an.NodeNumber = @neNodeNum
				and an.AreaID = @areaID;


				select @regionAndPoints = @regionAndPoints + '<ne><lo>' + cast(@RneLo as varchar) + '</lo><la>' + cast(@RneLa as varchar) + '</la></ne>';
				--Pnw
				select @regionAndPoints = @regionAndPoints + '<nw><lo>' + cast(@W as varchar) + '</lo><la>' + cast(@RneLa as varchar) + '</la></nw>'; 
				--Pse
				select @regionAndPoints = @regionAndPoints + '<se><lo>' + cast(@RneLo as varchar) + '</lo><la>' + cast(@S as varchar) + '</la></se></parameters>';  

				insert into #regionPoints (regionNum, points) values (@R, @regionAndPoints);
				print 'sw corner';

				set @isCorner = @isCorner + 1;
			end;
			else if (@nodeCount = 1 and @isCorner = 2)
			begin
				--se corner
				--Pse = Ase
				select @regionAndPoints = '<parameters><region>'+cast(@R as varchar)+'</region><se><lo>' + cast(@E as varchar) + '</lo><la>' + cast(@S as varchar) + '</la></se>';
				--Pnw = Rnw
				select @nwNodeNum = @R + (@R - 1)/(@columnNumber - 1) + @columnNumber;

				select @RnwLo = n.longtitude, @RnwLa = n.latitude
				from AreaNode an
				join Node2 n on n.ID = an.NodeID
				where an.NodeNumber = @nwNodeNum
				and an.AreaID = @areaID;


				select @regionAndPoints = @regionAndPoints + '<nw><lo>' + cast(@RnwLo as varchar) + '</lo><la>' + cast(@RnwLa as varchar) + '</la></nw>';
				--Pne
				select @regionAndPoints = @regionAndPoints + '<ne><lo>'  + cast(@E as varchar) +  '</lo><la>' + cast(@RnwLa as varchar) + '</la></ne>';
				--Psw
				select @regionAndPoints = @regionAndPoints + '<sw><lo>' + cast(@RnwLo as varchar) + '</lo><la>' + cast(@S as varchar) + '</la></sw></parameters>';

				insert into #regionPoints (regionNum, points) values (@R, @regionAndPoints);
				print 'se corner';

				set @isCorner = @isCorner + 1;
			end; 
			else if (@nodeCount = 1 and @isCorner = 3)
			begin
				--nw corner
				--Pnw = Anw
				select @regionAndPoints = '<parameters><region>'+cast(@R as varchar)+'</region><nw><lo>' + cast(@W as varchar) + '</lo><la>' + cast(@N as varchar) + '</la></nw>';
				--Pse = Rse
				select @seNodeNum = @R + (@R - 1)/(@columnNumber - 1) + 1;

				select @RseLo = n.longtitude, @RseLa = n.latitude
				from AreaNode an
				join Node2 n on n.ID = an.NodeID
				where an.NodeNumber = @seNodeNum
				and an.AreaID = @areaID;


				select @regionAndPoints = @regionAndPoints + '<se><lo>' + cast(@RseLo as varchar) + '</lo><la>' + cast(@RseLa as varchar) + '</la></se>';
				--Pne
				select @regionAndPoints = @regionAndPoints + '<ne><lo>' + cast(@RseLo as varchar) + '</lo><la>' + cast(@N as varchar) + '</la></ne>';
				--Psw
				select @regionAndPoints = @regionAndPoints + '<sw><lo>' + cast(@W as varchar) + '</lo><la>' + cast(@RseLa as varchar) + '</la></sw></parameters>';

				insert into #regionPoints (regionNum, points) values (@R, @regionAndPoints);
				print 'nw corner';
				set @isCorner = @isCorner + 1;
			end; 
			else if (@nodeCount = 1 and @isCorner = 4)
			begin
				--ne corner
				--Pne = Ane
				select @regionAndPoints = '<parameters><region>'+cast(@R as varchar)+'</region><ne><lo>' + cast(@E as varchar) + '</lo><la>' + cast(@N as varchar) + '</la></ne>';
				--Psw = Rsw
				select @swNodeNum = @R + (@R - 1)/(@columnNumber - 1);

				select @RswLo = n.longtitude, @RswLa = n.latitude
				from AreaNode an
				join Node2 n on n.ID = an.NodeID
				where an.NodeNumber = @swNodeNum
				and an.AreaID = @areaID;


				select @regionAndPoints = @regionAndPoints + '<sw><lo>' + cast(@RswLo as varchar) + '</lo><la>' + cast(@RswLa as varchar) + '</la></sw>';
				--Pnw
				select @regionAndPoints = @regionAndPoints + '<nw><lo>' + cast(@RswLo as varchar) + '</lo><la>' + cast(@N as varchar) + '</la></nw>';
				--Pse
				select @regionAndPoints = @regionAndPoints + '<se><lo>' + cast(@E as varchar) + '</lo><la>' + cast(@RswLa as varchar) + '</la></se></parameters>';

				insert into #regionPoints (regionNum, points) values (@R, @regionAndPoints);
				print 'ne corner';
			end;
			else if (@nodeCount = 2 and @isCorner = 2)
			begin
				--s border
				--Pnw = Rnw
				select @nwNodeNum = @R + (@R - 1)/(@columnNumber - 1) + @columnNumber;

				select @RnwLo = n.longtitude, @RnwLa = n.latitude
				from AreaNode an
				join Node2 n on n.ID = an.NodeID
				where an.NodeNumber = @nwNodeNum
				and an.AreaID = @areaID;


				select @regionAndPoints = '<parameters><region>'+cast(@R as varchar)+'</region><nw><lo>' + cast(@RnwLo as varchar) + '</lo><la>' + cast(@RnwLa as varchar) + '</la></nw>';
				--Pne = Rne
				select @neNodeNum = @R + (@R - 1)/(@columnNumber - 1) + @columnNumber + 1;

				select @RneLo = n.longtitude, @RneLa = n.latitude
				from AreaNode an
				join Node2 n on n.ID = an.NodeID
				where an.NodeNumber = @neNodeNum
				and an.AreaID = @areaID;


				select @regionAndPoints = @regionAndPoints + '<ne><lo>' + cast(@RneLo as varchar) + '</lo><la>' + cast(@RneLa as varchar) + '</la></ne>';
				--Pse
				select @regionAndPoints = @regionAndPoints + '<se><lo>' + cast(@RneLo as varchar) + '</lo><la>' + cast(@S as varchar) + '</la></se>';
				--Psw
				select @regionAndPoints = @regionAndPoints + '<sw><lo>' + cast(@RnwLo as varchar) + '</lo><la>' + cast(@S as varchar) + '</la></sw></parameters>';

				insert into #regionPoints (regionNum, points) values (@R, @regionAndPoints);
				print 's border';
			end;
			else if (@nodeCount = 2 and @isCorner = 3)
			begin
				--w or e border
				select @swNodeNum = @R + (@R - 1)/(@columnNumber - 1)

				if exists (select 1 from @regionTable where region = @R and nodeNum = @swNodeNum)
				begin
					--e border
					--Pnw = Rnw
					select @nwNodeNum = @R + (@R - 1)/(@columnNumber - 1) + @columnNumber;

					select @RnwLo = n.longtitude, @RnwLa = n.latitude
					from AreaNode an
					join Node2 n on n.ID = an.NodeID
					where an.NodeNumber = @nwNodeNum
					and an.AreaID = @areaID;


					select @regionAndPoints = '<parameters><region>'+cast(@R as varchar)+'</region><nw><lo>' + cast(@RnwLo as varchar) + '</lo><la>' + cast(@RnwLa as varchar) + '</la></nw>';
					--Psw = Rsw
					select @swNodeNum = @R + (@R - 1)/(@columnNumber - 1);

					select @RswLo = n.longtitude, @RswLa = n.latitude
					from AreaNode an
					join Node2 n on n.ID = an.NodeID
					where an.NodeNumber = @swNodeNum
					and an.AreaID = @areaID;


					select @regionAndPoints = @regionAndPoints + '<sw><lo>' + cast(@RswLo as varchar) + '</lo><la>' + cast(@RswLa as varchar) + '</la></sw>';
					--Pne
					select @regionAndPoints = @regionAndPoints + '<ne><lo>' + cast(@E as varchar) + '</lo><la>' + cast(@RnwLa as varchar) + '</la></ne>';
					--Pse
					select @regionAndPoints = @regionAndPoints + '<se><lo>' + cast(@E as varchar) + '</lo><la>' + cast(@RswLa as varchar) + '</la></se></parameters>';

					insert into #regionPoints (regionNum, points) values (@R, @regionAndPoints);
					print 'e border';
				end;
				else
				begin
					--w border
					--Pne = Rne
					select @neNodeNum = @R + (@R - 1)/(@columnNumber - 1) + @columnNumber + 1;

					select @RneLo = n.longtitude, @RneLa = n.latitude
					from AreaNode an
					join Node2 n on n.ID = an.NodeID
					where an.NodeNumber = @neNodeNum
					and an.AreaID = @areaID;

					select @regionAndPoints = '<parameters><region>'+cast(@R as varchar)+'</region><ne><lo>' + cast(@RneLo as varchar) + '</lo><la>' + cast(@RneLa as varchar) + '</la></ne>';
					--Pse = Rse
					select @seNodeNum = @R + (@R - 1)/(@columnNumber - 1) + 1;

					select @RseLo = n.longtitude, @RseLa = n.latitude
					from AreaNode an
					join Node2 n on n.ID = an.NodeID
					where an.NodeNumber = @seNodeNum
					and an.AreaID = @areaID;


					select @regionAndPoints = @regionAndPoints + '<se><lo>' + cast(@RseLo as varchar) + '</lo><la>' + cast(@RseLa as varchar) + '</la></se>';
					--Pnw
					select @regionAndPoints = @regionAndPoints + '<nw><lo>' + cast(@W as varchar) + '</lo><la>' + cast(@RneLa as varchar) + '</la></nw>';
					--Psw
					select @regionAndPoints = @regionAndPoints + '<sw><lo>' + cast(@W as varchar) + '</lo><la>' + cast(@RseLa as varchar) + '</la></sw></parameters>';

					insert into #regionPoints (regionNum, points) values (@R, @regionAndPoints);
					print 'w border';
				end;
			end;
			else if (@nodeCount = 2 and @isCorner = 4)
			begin
				--n border
				--Psw = Rsw
				select @swNodeNum = @R + (@R - 1)/(@columnNumber - 1);

				select @RswLo = n.longtitude, @RswLa = n.latitude
				from AreaNode an
				join Node2 n on n.ID = an.NodeID
				where an.NodeNumber = @swNodeNum
				and an.AreaID = @areaID;


				select @regionAndPoints = '<parameters><region>'+cast(@R as varchar)+'</region><sw><lo>' + cast(@RswLo as varchar) + '</lo><la>' + cast(@RswLa as varchar) + '</la></sw>';
				--Pse = Rse
				select @seNodeNum = @R + (@R - 1)/(@columnNumber - 1) + 1;

				select @RseLo = n.longtitude, @RseLa = n.latitude
				from AreaNode an
				join Node2 n on n.ID = an.NodeID
				where an.NodeNumber = @seNodeNum
				and an.AreaID = @areaID;

				select @regionAndPoints = @regionAndPoints + '<se><lo>' + cast(@RseLo as varchar) + '</lo><la>' + cast(@RseLa as varchar) + '</la></se>';
				--Pnw
				select @regionAndPoints = @regionAndPoints + '<nw><lo>' + cast(@RswLo as varchar) + '</lo><la>' + cast(@N as varchar) + '</la></nw>';
				--Pne
				select @regionAndPoints = @regionAndPoints + '<ne><lo>' + cast(@RseLo as varchar) + '</lo><la>' + cast(@N as varchar) + '</la></ne></parameters>';

				insert into #regionPoints (regionNum, points) values (@R, @regionAndPoints);
				print 'n border';
			end;
			else if (@nodeCount = 4)
			begin
				--inner region
				select @regionAndPoints = '<parameters><region>'+cast(@R as varchar)+'</region><sw><lo/><la/></sw><se><lo/><la/></se><ne><lo/><la/></ne><nw><lo/><la/></nw></parameters>';
				insert into #regionPoints (regionNum, points) values (@R, @regionAndPoints);
				print 'inner region';
			end;

			FETCH NEXT FROM nodeCount_cursor INTO @nodeCount, @R;
		END;
		CLOSE nodeCount_cursor;
		DEALLOCATE nodeCount_cursor;
	end;
	else
	begin
		--declare @regionNum int = dbo.[udfRegionNumber] (@long, @lat, @areaID);
		--declare @res xml = '<region>'+cast(@regionNum as varchar)+'</region>' 
		--SET @fourCorners.modify('insert sql:variable("@res") as first into (/parameters)[1]');
		--insert into #regionPoints (regionNum, points) values (@regionNum, @fourCorners);

		--Manage area that without nodes
		declare @res xml, @p float, @regionNum int;

		declare @longM table (p float);
		insert into @longM
		select distinct n.longtitude from Node2 n 
		where n.longtitude > = @W and n.longtitude <= @E;

		if exists (select 1 from @longM)
		begin
			select @p = p from @longM;

			set @regionNum = dbo.[udfRegionNumber] (@W, @S, @areaID);
			SET @res = '<region>'+cast(@regionNum as varchar)+'</region>' 
			set @fourCorners = '<parameters><sw><lo>' + cast(@W as varchar(10)) + '</lo><la>' + cast(@S as varchar(10)) + '</la></sw>' +
								'<se><lo>' + cast(@p as varchar(10)) + '</lo><la>' + cast(@S as varchar(10)) + '</la></se>' +
								'<ne><lo>' + cast(@p as varchar(10)) + '</lo><la>' + cast(@N as varchar(10)) + '</la></ne>' +
								'<nw><lo>' + cast(@W as varchar(10)) + '</lo><la>' + cast(@N as varchar(10)) + '</la></nw></parameters>';
			SET @fourCorners.modify('insert sql:variable("@res") as first into (/parameters)[1]');
			insert into #regionPoints (regionNum, points) values (@regionNum, @fourCorners);

			set @regionNum = dbo.[udfRegionNumber] (@E, @N, @areaID);
			SET @res = '<region>'+cast(@regionNum as varchar)+'</region>' 
			set @fourCorners = '<parameters><sw><lo>' + cast(@p as varchar(10)) + '</lo><la>' + cast(@S as varchar(10)) + '</la></sw>' +
								'<se><lo>' + cast(@E as varchar(10)) + '</lo><la>' + cast(@S as varchar(10)) + '</la></se>' +
								'<ne><lo>' + cast(@E as varchar(10)) + '</lo><la>' + cast(@N as varchar(10)) + '</la></ne>' +
								'<nw><lo>' + cast(@p as varchar(10)) + '</lo><la>' + cast(@N as varchar(10)) + '</la></nw></parameters>';
			SET @fourCorners.modify('insert sql:variable("@res") as first into (/parameters)[1]');
			insert into #regionPoints (regionNum, points) values (@regionNum, @fourCorners);
		end;
		else
		begin
			declare @latM table (p float);
			insert into @latM
			select distinct n.latitude from Node2 n
			where n.latitude <= @N and n.latitude >= @S;

			if exists (select 1 from @latM)
			begin
				select @p = p from @latM;

				set @regionNum = dbo.[udfRegionNumber] (@W, @N, @areaID);
				SET @res = '<region>'+cast(@regionNum as varchar)+'</region>' 
				set @fourCorners = '<parameters><sw><lo>' + cast(@W as varchar(10)) + '</lo><la>' + cast(@p as varchar(10)) + '</la></sw>' +
									'<se><lo>' + cast(@E as varchar(10)) + '</lo><la>' + cast(@p as varchar(10)) + '</la></se>' +
									'<ne><lo>' + cast(@E as varchar(10)) + '</lo><la>' + cast(@N as varchar(10)) + '</la></ne>' +
									'<nw><lo>' + cast(@W as varchar(10)) + '</lo><la>' + cast(@N as varchar(10)) + '</la></nw></parameters>';
				SET @fourCorners.modify('insert sql:variable("@res") as first into (/parameters)[1]');
				insert into #regionPoints (regionNum, points) values (@regionNum, @fourCorners);

				set @regionNum = dbo.[udfRegionNumber] (@E, @S, @areaID);
				SET @res = '<region>'+cast(@regionNum as varchar)+'</region>' 
				set @fourCorners = '<parameters><sw><lo>' + cast(@W as varchar(10)) + '</lo><la>' + cast(@S as varchar(10)) + '</la></sw>' +
									'<se><lo>' + cast(@E as varchar(10)) + '</lo><la>' + cast(@S as varchar(10)) + '</la></se>' +
									'<ne><lo>' + cast(@E as varchar(10)) + '</lo><la>' + cast(@p as varchar(10)) + '</la></ne>' +
									'<nw><lo>' + cast(@W as varchar(10)) + '</lo><la>' + cast(@p as varchar(10)) + '</la></nw></parameters>';
				SET @fourCorners.modify('insert sql:variable("@res") as first into (/parameters)[1]');
				insert into #regionPoints (regionNum, points) values (@regionNum, @fourCorners);
			end;
			else
			begin
				set @regionNum = dbo.[udfRegionNumber] (@long, @lat, @areaID);
				SET @res = '<region>'+cast(@regionNum as varchar)+'</region>' 
				SET @fourCorners.modify('insert sql:variable("@res") as first into (/parameters)[1]');
				insert into #regionPoints (regionNum, points) values (@regionNum, @fourCorners);
			end;
		end;

	end;

	select r.Name, rp.points 
	from #regionPoints rp
	join Region2 r on r.RegionNumber = rp.regionNum 
	order by r.Name;
end;


GO
