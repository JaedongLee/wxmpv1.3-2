--
-- execute uspGetUserDeletedbyLogonID N'<parameters><logonid>cli1</logonid></parameters>'
--

CREATE procedure [dbo].[uspGetUserDeletedbyLogonID]
@xmlparm xml
as
begin
	declare @LogonID nvarchar(200);
	
	select
    @LogonID = tbl.d.value('logonid[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(d);

	if exists (SELECT 1  FROM [dbo].[UserDeleted] ud
	join dbo.[User] u on ud.UserID = u.ID
	where u.LogonID = @LogonID
	and DATEDIFF(dd, ud.CreationTimeStamp, getdate()) < 8)
	select 1 as value;
	else
	select 0 as value;
end;


GO
