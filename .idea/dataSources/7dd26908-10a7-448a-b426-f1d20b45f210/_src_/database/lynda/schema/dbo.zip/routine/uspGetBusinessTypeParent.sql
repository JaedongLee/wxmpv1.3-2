CREATE procedure [dbo].[uspGetBusinessTypeParent]
as
begin
	select Name as BusinessTypeParent, ID
	from [BusinessType] where ParentID is null
	order by Name;
end;


GO
