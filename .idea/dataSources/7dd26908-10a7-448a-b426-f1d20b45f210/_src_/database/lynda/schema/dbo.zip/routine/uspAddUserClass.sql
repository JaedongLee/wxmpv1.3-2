--
-- uspAddUserClass N'<parameters><Class><ClassName>爷爷奶奶课班级1</ClassName><UserLogon>hxgnylb9</UserLogon></Class><Class><ClassName>爷爷奶奶课班级2</ClassName><UserLogon>hxgnylb8</UserLogon></Class></parameters>'
-- uspAddUserClass N'<parameters><Class><ClassName>dawudeban</ClassName><UserLogon>lbstudent4</UserLogon></Class><Class><ClassName>文体课班级1</ClassName><UserLogon>hxgnylb25Student4</UserLogon></Class></parameters>'
-- uspAddUserClass N'<parameters><Class><ClassName>dawudeban</ClassName><UserLogon>lbstudent6</UserLogon></Class></parameters>'
--
CREATE procedure [dbo].[uspAddUserClass]
@xmlparm xml
as
begin
	declare @UserID int, @ClassID int, @UserLogon nvarchar(200), @ClassName nvarchar(100);
	
	--select
	--@ClassName = tbl.users.value('ClassName[1]', 'nvarchar(100)'),
	--@UserLogon = tbl.users.value('UserLogon[1]', 'nvarchar(200)')
	--from @xmlparm.nodes('/parameters') AS tbl(users)

	select
	tbl.users.value('ClassName[1]', 'nvarchar(100)') as ClassName, 
	tbl.users.value('UserLogon[1]', 'nvarchar(200)') as UserLogon
	into #UserClass
	from @xmlparm.nodes('/parameters/Class') AS tbl(users);

	select c.ID ClassID, u.ID UserID
	into #UserClass1
	from #UserClass uc
	join [User] u on uc.UserLogon = u.LogonID
	join [hxgnyClass] c on c.Name = uc.ClassName

	begin tran
		insert into hxgnyUserClass
		(UserID, ClassID)
		select UserID, ClassID from #UserClass1

		--DECLARE Class_Cursor CURSOR FOR  
		--SELECT ClassID, UserID  
		--FROM #UserClass1 
		--where #UserClass1.UserID not in (select UserID from UserRole ur join Role r on r.ID = ur.RoleID where r.Name = 'hxgnyTeacher'); 

		--OPEN Class_Cursor;  

		--FETCH NEXT FROM Class_Cursor INTO @ClassID, @UserID;  
		--WHILE @@FETCH_STATUS = 0  
		--BEGIN  
		--	update hxgnyClass
		--	set RegisteredSize = RegisteredSize + 1
		--	where ID = @ClassID;

		--	FETCH NEXT FROM Class_Cursor INTO @ClassID, @UserID; 
		--END;  
		--CLOSE Class_Cursor;  
		--DEALLOCATE Class_Cursor;  

		delete hxgnyUserSelectedClass
		from #UserClass1 uc
		where hxgnyUserSelectedClass.UserID = uc.UserID and hxgnyUserSelectedClass.ClassID = uc.ClassID
	commit tran
end;


GO
