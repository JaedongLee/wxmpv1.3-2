--
-- execute uspGetRegionsByServerName N'<parameters><serverName>USAMidAtlantic</serverName></parameters>'
-- execute uspGetRegionsByServerName N'<parameters><serverName>USANewEngland</serverName></parameters>'
--
CREATE procedure [dbo].[uspGetRegionsByServerName]
@xmlparm xml
as
begin
	declare @serverName nvarchar(200);
	select @serverName = tbl.d.value('serverName[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(d);
	
	select r.Name RegionName
	from Region2 r
	join ServerRegion sr on sr.RegionID = r.ID
	join [Server] s on s.ID = sr.ServerID
	where s.Name = @serverName
	order by r.Name;
end;


GO
