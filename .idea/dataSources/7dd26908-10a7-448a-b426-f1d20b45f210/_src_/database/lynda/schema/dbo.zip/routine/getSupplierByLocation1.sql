--
-- execute getSupplierByLocation1 N'<parameters><long>116.475</long><lat>39.7736</lat><distance>50000</distance><businesstype>Fashion_Clothing_Shoes_Women</businesstype></parameters>'
-- execute getSupplierByLocation1 N'<parameters><long>116.475</long><lat>39.7736</lat><distance>500</distance><businesstype>Fashion_Clothing_Shoes_Women</businesstype></parameters>'
-- execute getSupplierByLocation1 N'<parameters><long>-73.627292</long><lat>41.300250</lat><distance>40000</distance><businesstype>Book</businesstype></parameters>'
-- execute getSupplierByLocation1 N'<parameters><long>-73.627292</long><lat>41.300250</lat><distance>120000</distance><businesstype>Book</businesstype></parameters>'
--

CREATE procedure [dbo].[getSupplierByLocation1]
@xmlparm xml
as
begin
	--insert into perf (ProcName, Step, rtime) values ('getSupplierByLocation1', 1, GETDATE());

	declare @areaID int, @long float, @lat float, @distance float, @BusinessType nvarchar(100);
	select 
	@long = tbl.loc.value('long[1]', 'float'),
	@lat = tbl.loc.value('lat[1]', 'float'),
	@distance = tbl.loc.value('distance[1]', 'float'),
	@BusinessType = tbl.loc.value('businesstype[1]', 'nvarchar(100)')
	from @xmlparm.nodes('/parameters') as tbl(loc);

	--set @distance = 31001;

	if @long >= 0 and @lat >= 0 
		set @areaID = 1;
	else if @long < 0 and @lat > 0
		set @areaID = 2;
	else if @long > 0 and @lat < 0
		set @areaID = 3;
	else
		set @areaID = 4;
	
	declare @parm varchar(1000) = '<parameters><areaID>' + cast(@areaID as varchar(10)) +'</areaID><longtitude>' + cast(@long as varchar(20)) +'</longtitude><latitude>'+cast(@lat as varchar(20))+'</latitude><range>'+cast(@distance as varchar(20))+'</range></parameters>'
	
	create table #Regions (Name nvarchar(100), points xml);
	insert into #Regions
	execute uspGetRegionsByCoordinatesAndRange @parm;

	create table #final (SupplierID nvarchar(100), Latitude float, Longtitude float, Credit nvarchar(10), Region nvarchar(100))

	declare @points xml, @res xml;
	declare region_coursor cursor for (select points from #Regions);
	OPEN region_coursor
	FETCH NEXT FROM region_coursor INTO @points
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @res = N'<BusinessType>'+@BusinessType+'</BusinessType>' 
		set @points.modify('insert sql:variable("@res") as last into (/parameters)[1]');

		insert into #final
		execute uspGetSupplierByLocationBusinessType @points;
		FETCH NEXT FROM region_coursor INTO @points;
	END;
	CLOSE region_coursor;
	DEALLOCATE region_coursor;

	--select @long SupplierID, @lat latitude, @long Longtitude,  @distance Credit, @BusinessType Region

	--insert into perf (ProcName, Step, rtime) values ('getSupplierByLocation1', 2, GETDATE());

	select * from #final;

--	select @long SupplierID, @lat latitude, @long Longtitude,  @distance Credit, @BusinessType Region
	--select '1' SupplierID, 2.0 latitude, 2.0 Longtitude, '3' Credit, '' Region
end;


GO
