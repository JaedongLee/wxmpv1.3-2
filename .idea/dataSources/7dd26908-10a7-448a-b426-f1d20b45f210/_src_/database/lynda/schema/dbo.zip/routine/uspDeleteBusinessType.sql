--
-- [uspDeleteBusinessType] N'<parameters><BusinessType>Changqing1</BusinessType></parameters>'
--
CREATE procedure [dbo].[uspDeleteBusinessType]
@xmlparm xml
as
begin
	declare @BusinessType nvarchar(100) = @xmlparm.value('(/parameters/BusinessType)[1]','nvarchar(100)');
	delete [BusinessType] 
	where Name = @BusinessType;
end;

GO
