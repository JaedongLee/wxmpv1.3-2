


--
-- uspGetFamilyClassesByLogonID N'<parameters><LogonID>hxgnylb51</LogonID></parameters>'
--
CREATE procedure [dbo].[uspGetFamilyClassesByLogonID]
@xmlparm xml
as
begin
	declare @logonID nvarchar(200), @userID int;
	
	select
	@logonID = tbl.users.value('LogonID[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	select @userID = ID from [User] where LogonID = @logonID;

	select uc.ClassID, c.Name as ClassName, u.LogonID, c.CourseID
	into #ClassInfo
	from hxgnyUserClass uc
	join hxgnyClass c on c.ID = uc.ClassID
	join [User] u on u.ID = uc.UserID
	where u.LogonID in (select LogonID 
						from [User] u
						join UserApp ua on ua.UserID = u.ID
						join App a on a.ID = ua.AppID 
						where ReferenceCode = cast(@userID as nvarchar(22))
						and a.Name = 'HXGNY')
	or u.LogonID = @logonID;


	select 
	ci.LogonID as Student, 
	ci.ClassID, 
	ci.ClassName, 
	ci.CourseID, 
	tc.LogonID as Teacher 
	from #ClassInfo ci
	left outer join (select u.LogonID, uc.ClassID 
	from hxgnyUserClass uc 
	left outer join [User] u on u.ID = uc.UserID
	left outer join UserRole ur on ur.UserID = uc.UserID
	left outer join [Role] r on r.ID = ur.RoleID
	where r.Name = 'hxgnyTeacher') tc 
	on tc.ClassID = ci.ClassID


	--select ci.LogonID as Student, ci.ClassID, ci.ClassName, ci.CourseID, u.LogonID as Teacher 
	--from #ClassInfo ci
	--join hxgnyUserClass uc on uc.ClassID = ci.ClassID
	--join [User] u on u.ID = uc.UserID
	--left outer join UserRole ur on ur.UserID = uc.UserID
	--left outer join [Role] r on r.ID = ur.RoleID
	--where r.Name = 'hxgnyTeacher'

end;


GO
