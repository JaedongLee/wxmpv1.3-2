--
-- select dbo.udfUserPoll('高雄超市')
--
 create function [dbo].[udfUserPoll](@logonID nvarchar(200))
  returns int
  as
  begin
	declare @poll int;
	if exists (select 1 from UserPoll up join [User] u on u.ID = up.UserID where u.LogonID = @logonID)
		select @poll = 1;
	else
		select @poll = 0;
	return @poll;
  end;


GO
