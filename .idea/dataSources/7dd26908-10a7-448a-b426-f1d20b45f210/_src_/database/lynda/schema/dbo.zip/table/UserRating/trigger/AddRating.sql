
--
--insert into UserRating
--(UserID, RatedUserID, Rate, Comments)
--values
--(21, 23, 6, 'Excellent Service');
--select * from UserRating order by UserID 
--
create TRIGGER [dbo].[AddRating] ON [dbo].[UserRating]
INSTEAD OF INSERT
AS
IF EXISTS (SELECT * FROM UserRating ur 
           JOIN inserted AS i ON ur.UserID = i.UserID and ur.RatedUserID = i.RatedUserID)
begin
	update UserRating
	set UserRating.Rate = i.Rate, UserRating.Comments = i.Comments, UserRating.ModificationTime = getdate()
	from inserted i
	where UserRating.UserID = i.UserID and UserRating.RatedUserID = i.RatedUserID;
	return; 
end
else
begin
	insert into UserRating
	(UserID, RatedUserID, Rate, Comments)
	select i.UserID, i.RatedUserID, i.Rate, i.Comments
	from inserted i;
	return;
end;

GO
