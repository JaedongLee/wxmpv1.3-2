CREATE procedure [dbo].[uspGetUserTypeRegion]
as
begin
	select distinct u.UserType, r.Name as Region
	from [User] u
	join  UserRegion ur on u.ID = ur.UserID
	join Region2 r on ur.RegionID = r.ID
	where u.UserType not in ('reroute')
	union
	select u.UserType, u.LogonID from [User] u where u.UserType in ('reroute')
	order by UserType, Region
end;


GO
