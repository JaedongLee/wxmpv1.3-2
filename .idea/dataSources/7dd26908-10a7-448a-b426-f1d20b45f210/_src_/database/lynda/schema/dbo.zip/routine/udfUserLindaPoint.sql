--
-- select dbo.udfUserLindaPoint('cli.lynda')
--
 create function [dbo].[udfUserLindaPoint](@logonID nvarchar(200))
  returns float
  as
  begin
  	declare @lindaPoint float = 0;
	return @lindaPoint;
  end;


GO
