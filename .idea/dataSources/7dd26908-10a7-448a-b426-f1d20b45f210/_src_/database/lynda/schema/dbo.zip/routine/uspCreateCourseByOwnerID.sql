

--
--exec uspCreateCourseByOwnerID N'<parameters><OwnerID>123</OwnerID><Name></Name><Description>1</Description><Type></Type><Price></Price><URL></URL><GradeSize>1</GradeSize><MaterialPrice></MaterialPrice></parameters>'
--exec uspCreateCourseByOwnerID N'<parameters><OwnerID>25638</OwnerID><Name>courseTest15</Name><Description>courseTest1Description%23_1</Description><Type>courseTest1</Type><Price>90</Price><URL>www.baidu.com</URL><GradeSize>3</GradeSize><MaterialPrice>60</MaterialPrice></parameters>'
--
CREATE procedure [dbo].[uspCreateCourseByOwnerID]
@xmlparm xml
as
BEGIN
	declare @ownerID nvarchar(200), @name nvarchar(100), @description nvarchar(500), @type nvarchar(50), @price numeric(12,3), @URL nvarchar(max), @gradeSize int, @materialPrice numeric(12,3);
	select
	@ownerID = tbl.users.value('OwnerID[1]', 'int'), 
	@name = tbl.users.value('Name[1]', 'nvarchar(100)'), 
	@description = tbl.users.value('Description[1]', 'nvarchar(500)'), 
	@type = tbl.users.value('Type[1]', 'nvarchar(50)'),
	@price= tbl.users.value('Price[1]', 'numeric(12,3)'),
	@URL = tbl.users.value('URL[1]', 'nvarchar(max)'),
	@gradeSize = tbl.users.value('GradeSize[1]', 'int'),
	@materialPrice= tbl.users.value('MaterialPrice[1]', 'numeric(12,3)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	--select @materialPrice

	insert into hxgnyCourse 
	(Name, Description, Type, Price, URL, OwnerID, GradeSize, MaterialPrice) 
	values 
	(@name, @description, @type, @price, @URL, @ownerID, @gradeSize, @materialPrice);
END;


GO
