--
-- execute uspGetUserPositionbyLogonID N'<parameters><logonid>cli.su</logonid></parameters>'
--
create procedure [dbo].[uspGetUserPositionbyLogonID]
@xmlparm xml
as
begin
	declare @LogonID nvarchar(200);
	
	select
    @LogonID = tbl.d.value('logonid[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(d);

SELECT [Longtitude]
      ,[Latitude]
  FROM [dbo].[User]
  where LogonID = @LogonID;
end;


GO
