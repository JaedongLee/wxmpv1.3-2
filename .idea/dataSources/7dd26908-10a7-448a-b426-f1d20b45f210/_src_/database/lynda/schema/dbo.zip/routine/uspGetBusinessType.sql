CREATE procedure [dbo].[uspGetBusinessType]
as
begin
	select Name as BusinessType, ParentID as ID 
	from [BusinessType] 
	where ParentID is not null
	order by Name;
end;


GO
