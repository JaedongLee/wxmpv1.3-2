--
--execute [uspGetUserIssueReport] ''
--
CREATE procedure [dbo].[uspGetUserIssueReport]
@xmlparm xml
as
begin
	select u.LogonID as Issuer, tu.LogonID as ReferTo, uir.Category, uir.Description, uir.CreationTime 
	from UserIssueReport uir
	join [User] u on uir.UserID=u.ID
	join [User] tu on uir.TargetUserID = tu.ID
	where uir.Category<>'Bug' 
	order by uir.CreationTime desc;
end;


GO
