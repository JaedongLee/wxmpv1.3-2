
--
-- uspAddUserSelectedClass N'<parameters><Class><ClassName>语言课班级1</ClassName><UserLogon>hxgnylb25Student3</UserLogon></Class><Class><ClassName>文体课班级1</ClassName><UserLogon>hxgnylb25Student4</UserLogon></Class></parameters>'
--
CREATE procedure [dbo].[uspAddUserSelectedClass]
@xmlparm xml
as
begin
	declare @ErrorNumber int, @ErrorSeverity int, @ErrorState int, @ErrorProcedure nvarchar(100), @ErrorLine int, @ErrorMessage varchar(500), @Message varchar(500);
	declare @UserID int, @ClassID int, @className nvarchar(100);

	select
	tbl.users.value('ClassName[1]', 'nvarchar(100)') as ClassName, 
	tbl.users.value('UserLogon[1]', 'nvarchar(200)') as UserLogon
	into #UserClass
	from @xmlparm.nodes('/parameters/Class') AS tbl(users);

	select c.ID ClassID, u.ID UserID
	into #UserClass1
	from #UserClass uc
	join [User] u on uc.UserLogon = u.LogonID
	join [hxgnyClass] c on c.Name = uc.ClassName

	begin tran
	BEGIN TRY 
		insert into hxgnyUserSelectedClass
		(UserID, ClassID)
		select UserID, ClassID from #UserClass1

		DECLARE Class_Cursor CURSOR FOR  
		SELECT ClassID, UserID  
		FROM #UserClass1 
		where #UserClass1.UserID not in (select UserID from UserRole ur join Role r on r.ID = ur.RoleID where r.Name = 'hxgnyTeacher'); 

		OPEN Class_Cursor;  

		FETCH NEXT FROM Class_Cursor INTO @ClassID, @UserID;  
		WHILE @@FETCH_STATUS = 0  
		BEGIN  

			select @className = Name from hxgnyClass where ID = @ClassID;

			set @Message =  @className + ' Reached ClassSize';
			if not exists (select 1 from hxgnyClass where ID = @ClassID and RegisteredSize < ClassSize)
			begin
				RAISERROR (@Message, 16, 1);  
			end

			update hxgnyClass
			set RegisteredSize = RegisteredSize + 1
			where ID = @ClassID;

			FETCH NEXT FROM Class_Cursor INTO @ClassID, @UserID; 
		END;  
		CLOSE Class_Cursor;  
		DEALLOCATE Class_Cursor;
	END TRY
	begin catch
		SELECT   
			@ErrorMessage = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState = ERROR_STATE();  
		RAISERROR (@ErrorMessage, -- Message text.  
				   @ErrorSeverity, -- Severity.  
				   @ErrorState -- State.  
				   );  
		if @@TRANCOUNT > 0 rollback tran;
	end catch;
	if @@TRANCOUNT > 0 commit tran;
	  
end;
GO
