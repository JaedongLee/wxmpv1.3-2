

--
--exec uspCanUserQueByLogonID N'<parameters><UserLogonID>hxgnylb25</UserLogonID></parameters>'
--

CREATE procedure [dbo].[uspCanUserQueByLogonID]
@xmlparm xml
as
BEGIN
	declare @logonID nvarchar(200), @qued int, @totalClass int, @userID int;

	select @logonID = tbl.users.value('UserLogonID[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(users);

	select @userID = ID from [User] where LogonID = @logonID;
	select @qued = Qued from hxgnyUserQued where UserID = @userID;
	select @totalClass = count(*) from hxgnyUserClass where UserID = @userID

	if  isnull(@qued, 0) < @totalClass
		select 0 as Mode;
	else
		select -1 as Mode;		
END;
GO
