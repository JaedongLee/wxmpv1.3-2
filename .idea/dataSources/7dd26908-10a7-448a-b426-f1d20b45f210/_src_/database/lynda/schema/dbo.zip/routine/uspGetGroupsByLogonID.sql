--
-- execute uspGetGroupsByLogonID N'<parameters><logonID>charles.su</logonID></parameters>'
--
CREATE procedure [dbo].[uspGetGroupsByLogonID]
@xmlparm xml
as
begin
	select g.Name GroupName, g.ID GroupID, u.LogonID, u.ID UID
	from [Group] g
	join UserGroup ug on ug.GroupID = g.ID
	join [User] u on u.ID = ug.UserID 
	where u.LogonID = @xmlparm.value('(/parameters/logonID)[1]', 'nvarchar(100)' )
	order by g.Name;
end;
GO
