
--
--uspebtRechargebyDates '<parameters><StartDate>01/01/2017</StartDate><EndDate>04/01/2017</EndDate></parameters>'  
--
CREATE procedure [dbo].[uspebtRechargebyDates] 
@xmlparm xml
as
begin
	declare @balanceIn numeric(12,3), @balanceOut numeric(12,3), @balance numeric(12,3), @startDate datetime, @endDate datetime;

	select
	@startDate = tbl.users.value('StartDate[1]', 'datetime'), 
	@endDate = tbl.users.value('EndDate[1]', 'datetime') 
	from @xmlparm.nodes('/parameters') AS tbl(users);

	--Total Amount in Recharge account before certain date
	select @balanceIn = sum(j.Amount)
	from ebtJournal j
	join ebtAccount a on j.ToAccountID = a.ID
	join [User] u on u.ID = a.OwnerID
	where FromAccountID = 5 -- Recharge
	and ToAccountID <> 3 -- TransientP
	and j.CreationTime < @startDate;

	--Total Amount in CashOut account before certain date
	select @balanceOut = sum(j.Amount)
	from ebtJournal j
	join ebtAccount a on j.ToAccountID = a.ID
	join [User] u on u.ID = a.OwnerID
	where FromAccountID = 5 -- Recharge
	and ToAccountID = 3 -- TransientP
	and j.CreationTime < @startDate;

	set @balance = isnull(@balanceIn, 0) - isnull(@balanceOut,0);

	--Individual account Recharge journal
	declare @Recharge table (CreationTime datetime, AccountType nvarchar(50), Amount numeric(12,3), Balance numeric(12,3), LogonID nvarchar(200) );
	insert into @Recharge
	(CreationTime, AccountType, Amount, Balance, LogonID)
	(select j.CreationTime, 'Recharge' as Type, j.Amount, @balance + j.Amount, u.LogonID  
	from ebtJournal j
	join ebtAccount a on j.ToAccountID = a.ID
	join [User] u on u.ID = a.OwnerID
	where FromAccountID = 5 -- Recharge
	and ToAccountID <> 3 -- TransientP
	and j.CreationTime > @startDate
	and j.CreationTime <= @endDate
	union
	select j.CreationTime, 'CashOut' as Type, j.Amount, @balance - j.Amount, u.LogonID  
	from ebtJournal j
	join ebtAccount a on j.ToAccountID = a.ID
	join [User] u on u.ID = a.OwnerID
	where FromAccountID = 5 -- Recharge
	and ToAccountID = 3 -- TransientP
	and j.CreationTime < @startDate  
	and j.CreationTime <= @endDate);

	select CreationTime, AccountType, Amount, Balance, LogonID from @Recharge order by CreationTime

	--select * from ebtAccount where OwnerID = 25215
end;

GO
