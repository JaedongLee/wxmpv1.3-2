--
-- execute uspGetSupplierByBusinessTypeLocation N'<parameters><BusinessType>Blue Ginger</BusinessType></parameters>'
--
CREATE procedure [dbo].[uspGetSupplierByBusinessTypeLocation]
@xmlparm xml
as
begin
	declare @BusinessType nvarchar(100) = @xmlparm.value('(/parameters/BusinessType)[1]','nvarchar(100)');

	--find supplier customized business type type
	select Location, ID from BusinessType
	where Name = @BusinessType;
end;
GO
