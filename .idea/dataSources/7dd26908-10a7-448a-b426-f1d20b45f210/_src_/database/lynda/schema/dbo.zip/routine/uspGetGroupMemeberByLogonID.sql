
--
-- execute uspGetGroupMemeberByLogonID N'<parameters><user><logonid>wk001</logonid></user></parameters>'
-- execute uspGetGroupMemeberByLogonID N'<parameters><user><logonid>dw202</logonid></user></parameters>'
-- execute uspGetGroupMemeberByLogonID N'<parameters><user><logonid>wkq001</logonid></user></parameters>'
-- execute uspGetGroupMemeberByLogonID N'<parameters><user><logonid>wkq002</logonid></user></parameters>'
-- execute uspGetGroupMemeberByLogonID N'<parameters><user><logonid>dw101</logonid></user></parameters>'
--
CREATE procedure [dbo].[uspGetGroupMemeberByLogonID]
@xmlparm xml
as
begin
	declare @logonID nvarchar(200);
	select @logonID = tbl.d.value('logonid[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters/user') AS tbl(d);

	with groupmemberlist as
	(	select 
		ID, 
		LogonID, 
		ReferenceCode, 
		case when YearsOfBusiness < 0 then 'broker' else 'member' end as UserType, 
		case when YearsOfBusiness < 0 then YearsOfBusiness else 0 end as hLevel
		from [User] 
		where LogonID = @logonID 
		and UserType = 'supplier'
	
		union all

		select 
		u.ID, 
		u.LogonID, 
		u.ReferenceCode, 
		case when u.YearsOfBusiness < 0 then 'broker' else 'member' end as UserType,
		case when YearsOfBusiness < 0 then YearsOfBusiness else 0 end as hLevel
		from [User] u 
		inner join groupmemberlist gl on u.ReferenceCode = cast(gl.ID as nvarchar(11)) where u.UserType = 'supplier'
	)
	select * into #t from groupmemberlist order by ID
	if exists (select 1 from #t where LogonID = @logonID and UserType = 'broker')
	begin
		select *  from #t
	end
	else 
	begin
		--find parent and its group member	
		select 
		u.ID, 
		u.LogonID, 
		u.ReferenceCode, 
		case when u.YearsOfBusiness < 0 then 'broker' else 'member' end as UserType,
		case when u.YearsOfBusiness < 0 then u.YearsOfBusiness else 0 end as hLevel
		from [User] u 
		inner join [User] gl on cast(u.ID as nvarchar(11)) = gl.ReferenceCode 
		where u.UserType = 'supplier'
		and gl.LogonID = @logonID
	
		union all

		select 
		u.ID, 
		u.LogonID, 
		u.ReferenceCode, 
		case when u.YearsOfBusiness < 0 then 'broker' else 'member' end as UserType,
		case when u.YearsOfBusiness < 0 then u.YearsOfBusiness else 0 end as hLevel
		from [User] u 
		inner join [User] gl on u.ReferenceCode = gl.ReferenceCode 
		where u.UserType = 'supplier'
		and gl.LogonID = @logonID
		and u.YearsOfBusiness > 0
	end;
end;

GO
