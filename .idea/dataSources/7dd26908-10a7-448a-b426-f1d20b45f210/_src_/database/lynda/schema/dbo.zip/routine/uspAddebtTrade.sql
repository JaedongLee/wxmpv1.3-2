

--
-- uspAddebtTrade N'<parameters><tradename>Regular</tradename><description>Regular Trade</description><fromOwnerID>10</fromOwnerID><toOwnerID>20</toOwnerID><amount>50000.123</amount></parameters>'
--
CREATE procedure [dbo].[uspAddebtTrade]
@xmlparm xml
as
begin
	declare @tradename nvarchar(100), @description nvarchar(300), @fromOwnerID int, @toOwnerID int, @amount numeric(12,3), @orderid nvarchar(100);
	
	select
	@orderid = tbl.users.value('orderid[1]', 'nvarchar(100)'), 
	@tradename = tbl.users.value('tradename[1]', 'nvarchar(100)'), 
	@description = tbl.users.value('description[1]', 'nvarchar(300)'),
	@fromOwnerID = tbl.users.value('fromOwnerID[1]', 'int'), 
	@toOwnerID = tbl.users.value('toOwnerID[1]', 'int'),
	@amount = tbl.users.value('amount[1]', 'numeric(12,3)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	insert into ebtTrade
	(Name, Description, FromOwnerID, ToOwnerID, Amount, OrderID)
	select @tradename, @description, @fromOwnerID, @toOwnerID, @amount, @orderid 
end;


GO
