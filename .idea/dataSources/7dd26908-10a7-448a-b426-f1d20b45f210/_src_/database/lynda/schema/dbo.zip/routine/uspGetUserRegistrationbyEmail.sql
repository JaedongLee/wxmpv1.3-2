--
-- execute uspGetUserRegistrationbyEmail N'<parameters><email>jsong88@gmail.com</email><accttype>supplier</accttype></parameters>'
-- execute uspGetUserRegistrationbyEmail N'<parameters><email>happylane520@gmail.com</email><accttype>supplier</accttype></parameters>'
--
CREATE procedure [dbo].[uspGetUserRegistrationbyEmail]
@xmlparm xml
as
begin
	declare @email nvarchar(200), @accttype nvarchar(20), @UserID int, @LogonID nvarchar(200), @BusinessTypeDetial nvarchar(max);
	declare @final nvarchar(max);
	declare @ErrorNumber int, @ErrorSeverity int, @ErrorState int, @ErrorProcedure nvarchar(100), @ErrorLine int, @ErrorMessage varchar(500);

	select
    @email = tbl.d.value('email[1]', 'nvarchar(200)'),
	@accttype = lower(tbl.d.value('accttype[1]', 'nvarchar(20)'))
	from @xmlparm.nodes('/parameters') AS tbl(d);
	--select @LogonID 

	select @UserID = ID, @LogonID = LogonID from [User] where Email = @email and UserType = @accttype;

	--Update UserPasscodeCheck if PasscodeCheck is 1
	begin try
		begin tran
		update UserPasscodeCheck set PasscodeCheck = 1 where UserID =  @UserID;
		if @@TRANCOUNT > 0 commit tran;
	end try
	begin catch
	if @@TRANCOUNT > 0 rollback tran;
		SELECT @ErrorNumber = ERROR_NUMBER()
		,@ErrorSeverity = ERROR_SEVERITY()
		,@ErrorState = ERROR_STATE()
		,@ErrorProcedure = ERROR_PROCEDURE()
		,@ErrorLine = ERROR_LINE()
		,@ErrorMessage = ERROR_MESSAGE();
		throw 500000, @ErrorMessage, @ErrorState;
	end catch;

	SELECT @final = N'<parameters><LogonID>' + [LogonID] + '</LogonID>' + 
      '<Password>' + [Password] + '</Password>' + 
      '<FirstName>' + isnull([FirstName],'') + '</FirstName>' +
      '<MiddleName>' + isnull([MiddleName],'') + '</MiddleName>' + 
      '<LastName>' + isnull([LastName],'') + '</LastName>' +
      '<Longtitude>' + cast(isnull([Longtitude], 0) as varchar(10)) + '</Longtitude>' +
      '<Latitude>' + cast(isnull([Latitude],0) as varchar(10)) + '</Latitude>' + 
      '<Street>' + isnull([Street],'') + '</Street>' + 
      '<City>' + isnull([City],'') + '</City>' +  
      '<State>' + isnull([State],'') + '</State>' +  
      '<Country>' + isnull([Country],'') + '</Country>' + 
      '<Zipcode>' + isnull([Zipcode],'') + '</Zipcode>' + 
      '<UserType>' + isnull([UserType],'') + '</UserType>' + 
      '<Email>' + isnull([Email],'') + '</Email>' + 
      '<WeChat>' + isnull([WeChat],'') + '</WeChat>' + 
      '<ReferenceCode>' + isnull([ReferenceCode],'') + '</ReferenceCode>' + 
	  '<Credit>' + cast(isnull(dbo.udfUserRating(@logonID),0) as varchar(2)) + '</Credit>' +
	  '<Fee>' + cast(isnull(dbo.udfUserFee(@logonID),0) as varchar(10)) + '</Fee>' +
	  '<yearsOfBusiness>' + cast(isnull(YearsOfBusiness,0) as varchar(10)) + '</yearsOfBusiness>' +
	  '<Region>' + isnull(dbo.udfUserRegion(@logonID),'') + '</Region>' +
	  '<Poll>' + cast(isnull(dbo.udfUserPoll(@logonID),'') as varchar(100)) + '</Poll>' +
	  '<LindaPoint>' + cast(isnull(dbo.udfUserLindaPoint(@logonID),0) as varchar(10)) + '</LindaPoint>' +
	  '<LastMTime>' + cast( cast(Datediff(s, '1970-01-01', DATEADD(dd, 0, DATEDIFF(dd, 0, ModificationTime))) AS bigint)*1000 + cast(Datediff(MS, DATEADD(dd, 0, DATEDIFF(dd, 0, ModificationTime)), ModificationTime) AS bigint) as varchar(30)) + '</LastMTime>'
	FROM [dbo].[User]
	where Email = @email and UserType = @accttype;

	--select @final

	select @BusinessTypeDetial = BusinessTypeDetail 
	from [BusinessType]
	where TypeOwnerID = @UserID;
	set @BusinessTypeDetial = N'<BusinessTypeDetial>'+ @BusinessTypeDetial + '</BusinessTypeDetial>';

	declare @BusenessTypeAll NVARCHAR(max)
	select @BusenessTypeAll = COALESCE(@BusenessTypeAll + N'</BusinessType><BusinessType>', '') + a.Name 
	from
	(select distinct bt.Name
	from BusinessType bt
	join UserBusinessType ubt on ubt.BusinessTypeID = bt.ID
	join [User] u on u.ID = ubt.UserID 
	where u.Email = @email and UserType = @accttype and bt.type is null) a;

	set @BusenessTypeAll = N'<BusinessType>' + @BusenessTypeAll + N'</BusinessType>'; 
	--select @BusenessTypeAll

	declare @cBusenessTypeAll NVARCHAR(max)
	select @cBusenessTypeAll = COALESCE(@cBusenessTypeAll + N'</cBusinessType><cBusinessType>', '') + a.Name 
	from
	(select distinct bt.Name
	from BusinessType bt
	join UserBusinessType ubt on ubt.BusinessTypeID = bt.ID
	join [User] u on u.ID = ubt.UserID 
	where u.Email = @email and UserType = @accttype and bt.type like 'C%') a;

	set @cBusenessTypeAll = N'<cBusinessType>' + @cBusenessTypeAll + N'</cBusinessType>'; 
	--select @cBusenessTypeAll

	declare @SpecialCategoryAll NVARCHAR(max)
	select @SpecialCategoryAll = COALESCE(@SpecialCategoryAll + N'</SpecialCategory><SpecialCategory>', '') + a.Name 
	from
	(select distinct bt.Name
	from BusinessType bt
	join UserBusinessType ubt on ubt.BusinessTypeID = bt.ID
	join [User] u on u.ID = ubt.UserID 
	where u.LogonID = @LogonID and bt.Type like 'SCT') a

	set @SpecialCategoryAll = N'<SpecialCategory>' + @SpecialCategoryAll + N'</SpecialCategory>'; 
	--select @SpecialCategoryAll

	declare @PhoneAll NVARCHAR(max), @ExtAll NVARCHAR(max); 
	select @PhoneAll = COALESCE(@PhoneAll + N'</Phone><Phone>', '') + p.Phone 
	from Phone p
	join UserPhone up on up.PhoneID = p.ID
	join [User] u on u.ID = up.UserID
	where u.Email = @email and UserType = @accttype and p.Phone <> ''
	order by up.FirstPhone desc;
	--select @PhoneAll

	select @ExtAll = COALESCE(@ExtAll + N'</Ext><Ext>', '') + p.Ext  
	from Phone p
	join UserPhone up on up.PhoneID = p.ID
	join [User] u on u.ID = up.UserID
	where u.Email = @email and UserType = @accttype and p.Ext <>''
	order by up.FirstPhone desc;

	set @PhoneAll = N'<Phone>' + @PhoneAll + N'</Phone><Ext>' + isnull(@ExtAll,'') + N'</Ext>'; 
	--select @phoneAll;

	set @final = @final + isNull(@BusenessTypeAll,'') + isNull(@cBusenessTypeAll,'') + isnull(@phoneAll,'')  + isnull(@SpecialCategoryAll,'') + isnull(@BusinessTypeDetial,'') + N'</parameters>'; 
	select @final as Registration;
end;


GO
