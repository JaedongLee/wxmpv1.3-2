--
-- execute uspUpdateUserProfile N'<parameters><logonid>A01001</logonid><password>e10adc3949ba59abbe56e057f20f883e</password><gps>1</gps><firstname>Charles</firstname><lastname>高雄 - 杏福巷子</lastname><long>120.293585</long><lat>22.6199275</lat><street>高雄市前金區成功一路274巷2號</street><city>cross river</city><state>ny</state><country>usa</country><zipcode>10518</zipcode><email>happylane520@gmail.com</email><wechat></wechat><yearsofbusiness>2</yearsofbusiness><phone>07-2412205</phone><ext></ext><businessType>吃</businessType><businessType>喝</businessType><businessType>w</businessType><businessType>t</businessType><businessType>p</businessType><businessType>StoreDiscount</businessType><businessType>高雄-杏福巷子</businessType><poll>0</poll><StoreName>高雄 - 杏福巷子</StoreName><StoreDesc>杏福巷子寫 下了 一個不算長不算短十年紀錄歷史，憑著一步一腳印在巷子裡賣著純手工、不添加香精、香料、防腐劑的杏仁茶。一開始介紹杏仁給每一位顧客，顧客抱著懷疑的眼 神，直到現在經過了一次又一次的食安風暴，顧客不用我介紹就很清楚知道了純的風味。 杏福巷子感謝大家的支持！！ 我們將會更努力服務大家。</StoreDesc></parameters>'
--
CREATE procedure [dbo].[uspUpdateUserProfile]
@xmlparm xml
as
begin
	begin tran
		execute uspUpdateUserPassword @xmlparm;
		execute uspUpdateUserBusinessType @xmlparm;
		execute uspUpdateUserAddress @xmlparm;
		execute uspUpdateUserYearsOfBusiness @xmlparm;
	commit tran
end;

GO
