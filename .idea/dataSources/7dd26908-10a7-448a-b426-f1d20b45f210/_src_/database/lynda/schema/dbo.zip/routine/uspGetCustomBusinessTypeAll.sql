CREATE procedure [dbo].[uspGetCustomBusinessTypeAll]
as
begin
	select Name as BusinessType, Location 
	from [BusinessType] 
	where Type like 'C%' 
	and ID in (select BusinessTypeID from BusinessTypeTemplate) -- constraint with template
	order by Name;
end;

GO
