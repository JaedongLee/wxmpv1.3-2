


--
--exec uspGetUserAllByRole N'<parameters><RoleName>hxgnyTeacher</RoleName></parameters>'
--

CREATE procedure [dbo].[uspGetUserAllByRole]
@xmlparm xml
as
BEGIN
	declare @roleName nvarchar(200);
	
	select
	@roleName = tbl.users.value('RoleName[1]', 'nvarchar(200)')
	from @xmlparm.nodes('/parameters') AS tbl(users)

	select ur.UserID, u.LogonID, u.FirstName, u.LastName, u.Description
	from UserRole ur
	join [Role] r on r.ID = ur.RoleID
	join [User] u on u.ID = ur.UserID
	where r.Name =  @roleName
END;

GO
