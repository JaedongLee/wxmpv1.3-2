--
--execute uspGetRegionUserByUserType
--
CREATE procedure [dbo].[uspGetRegionUserByUserType]
as
begin
	select distinct r.Name as Region, u.LogonID
	from [User] u
	left join  UserRegion ur on u.ID = ur.UserID
	left join Region2 r on ur.RegionID = r.ID
	where u.UserType =N'buyer'
	order by Region, LogonID
end;


GO
