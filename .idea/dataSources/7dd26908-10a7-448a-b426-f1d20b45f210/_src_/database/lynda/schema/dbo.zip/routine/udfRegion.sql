--
-- select dbo.udfRegion(120.949,31.5)
--
 CREATE function [dbo].[udfRegion](@longtitude float, @latitude float)
  returns varchar(100)
  as
  begin
	--determine region by region map and input location
	declare @region nvarchar(100);

	select @region = Name from Region2 
	where Coordinate.value('(/parameters/ne/lo)[1]','float') >= @longtitude
	and Coordinate.value('(/parameters/sw/lo)[1]','float') < @longtitude
	and Coordinate.value('(/parameters/ne/la)[1]','float') >= @latitude
	and Coordinate.value('(/parameters/sw/la)[1]','float') < @latitude

	--if @region is null set @region = N'Shanghai'

	return @region;
  end;


GO
