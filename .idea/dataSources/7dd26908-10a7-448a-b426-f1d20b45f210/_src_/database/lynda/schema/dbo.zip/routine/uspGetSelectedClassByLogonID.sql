

--
--exec uspGetSelectedClassByLogonID N'<parameters><user><logonID>cli01</logonID></user><user><logonID>cli02</logonID></user><user><logonID>cli03</logonID></user></parameters>'
--

CREATE procedure [dbo].[uspGetSelectedClassByLogonID]
@xmlparm xml
as
BEGIN

	select
	tbl.users.value('logonID[1]', 'nvarchar(100)') as LogonID 
	into #UserLogon
	from @xmlparm.nodes('/parameters/user') AS tbl(users);

--	select LogonID from #UserLogon;

	select 
	cl.ID ClassID, 
	cl.Name ClassName, 
	cl.Description, 
	Location ClassLocation, 
	StartTime, 
	EndTime, 
	ClassSize, 
	RegisteredSize, 
	Grade, 
	CourseID,  
	cr.Name CourseName, 
	cr.Type CourseType, 
	cr.GradeSize,
	u.LogonID,
	cr.MaterialPrice,
	cr.Price
	from hxgnyUserSelectedClass usc
	join hxgnyClass cl on cl.ID = usc.ClassID
	join hxgnyCourse cr on cl.CourseID = cr.ID
	join [User] u on u.ID = usc.UserID
	where u.LogonID in (select LogonID from #UserLogon );
END;

GO
