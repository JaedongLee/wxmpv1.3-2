
CREATE TRIGGER [dbo].[UpdateUser] ON [dbo].[User]
AFTER UPDATE
AS
begin
	update [User] set ModificationTime = getdate() where ID = (select ID from inserted);
	if (update(Password))
	begin
		update lyndaadmin.dbo.AspNetUsers
		set PasswordHash = (select Password from inserted)
		where id = (select cast(ID as nvarchar(20)) from inserted);
	end;
end;
GO
