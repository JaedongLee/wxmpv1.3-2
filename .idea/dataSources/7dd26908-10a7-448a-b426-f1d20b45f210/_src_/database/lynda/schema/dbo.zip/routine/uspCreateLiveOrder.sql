CREATE procedure [dbo].[uspCreateLiveOrder]
@xmlparm nvarchar(max)
as
BEGIN
	insert into LiveOrder (Content) values (@xmlparm);
END;
GO
