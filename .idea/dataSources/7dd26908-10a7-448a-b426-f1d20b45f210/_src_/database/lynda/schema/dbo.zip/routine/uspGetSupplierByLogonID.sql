--
-- execute [uspGetSupplierByLogonID] N'<parameters><logonID>cli</logonID></parameters>'
--
CREATE procedure [dbo].[uspGetSupplierByLogonID]
@xmlparm xml
as
begin
	declare @logonID nvarchar(100);
	select  @logonID = @xmlparm.value('(/parameters/logonID)[1]','nvarchar(100)');

	--find suppliers
	select 
	u.LogonID SupplierID,
	u.Latitude,
	u.Longtitude,
	isnull(c.Credit,'') as Credit,
	r.Name as Region,
	dbo.udfUserRating(@logonID) as Rating
	from [User] u
	join UserRegion ur on u.ID = ur.UserID
	join Region2 r on r.ID = ur.RegionID
	left join UserCredit uc on uc.UserID = u.ID
	left join Credit c on c.ID = uc.CreditID
	where u.LogonID = @logonID;
end;


GO
